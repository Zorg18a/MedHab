"""Движок манги для mangabuff.ru: разбор страниц тайтла и главы из HTML. Без сети и без app.py, поэтому проверяется на сохранённых образцах.

Что известно о сайте (по сохранённым страницам, tests/fixtures/mangabuff):
  тайтл   https://mangabuff.ru/manga/{slug}              все главы сразу в разметке: <a class="chapters__item" href=".../{том}/{глава}">
  глава   https://mangabuff.ru/manga/{slug}/{том}/{глава}  все страницы сразу в разметке: <div class="reader__item" data-page="N"><img src|data-src>
  картинки https://c3.mangabuff.ru/chapters/{slug}/{том}/{глава}/{N}-{хэш}.jpeg  (ленивые картинки держат адрес в data-src)
В читалке есть переключатель серверов картинок («Сервер 1», «Сервер 3»); его кнопки разбираются, но адреса другого сервера не угадываются."""
import re
from urllib.parse import urljoin, urlparse

from enginekit import VOID, EngineError, _Collector, _cls, _meta, looks_blocked   # общее для разборщиков


def slug_of(url: str) -> str:
    m = re.match(r"^/manga/([a-z0-9_-]+)", urlparse(url).path)
    return m.group(1) if m else ""


def parse_title(html: str, base: str) -> dict:
    """Страница тайтла -> {slug, title, cover, description, genres, chapters}; главы в порядке сайта (новые первыми)."""
    c = _Collector({"h1": ("h1", "manga__name"), "desc": ("div", "manga__description"), "tag": ("a", "tags__item"),
                    "ch": ("a", "chapters__item"), "vol": ("div", "chapters__volume"), "val": ("div", "chapters__value"),
                    "name": ("div", "chapters__name"), "date": ("div", "chapters__add-date")})
    c.feed(html)
    slug = slug_of(_meta(c, "og:url") or base)
    title = (c.found["h1"][0]["text"] if c.found["h1"] else "") or re.sub(r"\s*[-/|].*$", "", _meta(c, "og:title")).strip() or slug
    cover = urljoin(base, _meta(c, "og:image")) if _meta(c, "og:image") else ""
    chapters = []
    for a in c.found["ch"]:
        href = urljoin(base, a["attrs"].get("href") or "")
        m = re.match(r"^/manga/([a-z0-9_-]+)/(\d+)/([\d.]+)/?$", urlparse(href).path)
        if not m or (slug and m.group(1) != slug):
            continue
        vol, num = m.group(2), m.group(3)
        name = (a["kids"].get("name") or [""])[0]   # у некоторых глав есть своё название
        chapters.append({"cid": f"{vol}-{num}", "vol": vol, "num": num, "url": href, "date": a["attrs"].get("data-chapter-date") or "",
                         "label": f"Том {vol} Глава {num}" + (f" {name}" if name else "")})
    seen, uniq = set(), []
    for ch in chapters:
        if ch["cid"] not in seen:
            seen.add(ch["cid"]); uniq.append(ch)
    return {"slug": slug, "title": title, "cover": cover, "description": c.found["desc"][0]["text"] if c.found["desc"] else "",
            "genres": [t["text"] for t in c.found["tag"] if t["text"]], "chapters": uniq}


def parse_chapter(html: str, base: str) -> dict:
    """Страница главы -> {pages: [адреса по порядку], servers: [номера], slug}."""
    c = _Collector({"item": ("div", "reader__item"), "srv": ("button", "change-server-img-btn")})
    c.feed(html)
    pages = []
    for i, it in enumerate(c.found["item"]):
        n = it["attrs"].get("data-page") or ""
        for im in it["imgs"][:1]:
            u = im.get("data-src") or im.get("src") or ""
            if u and not u.startswith("data:"):
                pages.append((int(n) if n.isdigit() else i + 1, i, urljoin(base, u.strip())))
    pages.sort()
    out, seen = [], set()
    for _, _, u in pages:
        if u not in seen:
            seen.add(u); out.append(u)
    servers = [int(s["attrs"]["data-server"]) for s in c.found["srv"] if (s["attrs"].get("data-server") or "").isdigit()]
    return {"slug": slug_of(_meta(c, "og:url") or base), "pages": out, "servers": servers}


def load_title(get_html, site: str, slug: str) -> dict:
    """Скачать и разобрать страницу тайтла. get_html(url) -> строка HTML (через расширение или напрямую)."""
    url = f"{site}/manga/{slug}"
    html = get_html(url)
    if looks_blocked(html):
        raise EngineError("сайт отдал страницу проверки браузера вместо тайтла: откройте его в браузере с расширением MediaHub и повторите")
    t = parse_title(html, url)
    if not t["chapters"]:
        raise EngineError("на странице тайтла не нашлось глав (изменилась разметка сайта или тайтл закрыт)")
    return t


def load_pages(get_html, ch: dict) -> list:
    """Адреса страниц главы по порядку; EngineError с причиной, если их нет."""
    html = get_html(ch["url"])
    if looks_blocked(html):
        raise EngineError("страница главы не открылась (проверка браузера или блокировка)")
    pages = parse_chapter(html, ch["url"])["pages"]
    if not pages:
        raise EngineError("в главе нет страниц (глава закрыта, нужен вход или изменилась разметка)")
    return pages
