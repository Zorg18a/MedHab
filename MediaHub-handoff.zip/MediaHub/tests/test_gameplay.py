# Кнопка «Играть»: поиск файлов запуска, проверка пути, команда запуска, API.
import json, os, subprocess
import pytest
import gameplay as gp
import lan
from test_game_find import jget, jpost, make_root, game


def tree(base, files):
    for rel in files:
        p = base / rel; p.parent.mkdir(parents=True, exist_ok=True); p.write_bytes(b"x" * 10)


def test_find_skips_service_and_sorts_near_root(tmp_path):
    tree(tmp_path, ["Game.exe", "unins000.exe", "bin/deep.bat", "vc_redist.x64.exe", "a/b/c/d/too_deep.exe", "readme.txt", "UnityCrashHandler64.exe"])
    got = [e["rel"] for e in gp.find_executables(str(tmp_path))]
    assert got == ["Game.exe", "bin/deep.bat"]


def test_pick_default():
    assert gp.pick_default([{"rel": "a.exe", "name": "a.exe"}, {"rel": "b.bat", "name": "b.bat"}]) == "a.exe"
    assert gp.pick_default([{"rel": "a.exe", "name": "a.exe"}, {"rel": "b.exe", "name": "b.exe"}]) == ""
    assert gp.pick_default([{"rel": "b.bat", "name": "b.bat"}]) == "b.bat"
    assert gp.pick_default([]) == ""


@pytest.mark.parametrize("rel", ["", "../x.exe", "a/../../x.exe", "a/../y.exe", "/etc/x.exe", "C:\\x.exe", "\\x.exe", "notes.txt", "Game.exe.txt", "missing.exe"])
def test_resolve_rejects(tmp_path, rel):
    root = tmp_path / "root"; tree(root, ["G/Game.exe", "x.exe", "G/a/y.exe"]); tree(tmp_path, ["x.exe"])   # x.exe реально лежит рядом с папкой игры
    with pytest.raises(gp.PlayError):
        gp.resolve(str(root / "G"), rel, str(root))


def test_resolve_ok_and_folder_must_be_inside_root(tmp_path):
    root = tmp_path / "root"; tree(root, ["G/sub/Game.exe"]); tree(tmp_path, ["Other/Game.exe"])
    assert gp.resolve(str(root / "G"), "sub/Game.exe", str(root)) == os.path.abspath(root / "G" / "sub" / "Game.exe")
    with pytest.raises(gp.PlayError):
        gp.resolve(str(tmp_path / "Other"), "Game.exe", str(root))


@pytest.mark.skipif(not hasattr(os, "symlink"), reason="нет символических ссылок")
def test_resolve_rejects_symlink_out(tmp_path):
    root = tmp_path / "root"; tree(root, ["G/a.txt"]); tree(tmp_path, ["out/evil.exe"])
    try: os.symlink(tmp_path / "out" / "evil.exe", root / "G" / "evil.exe")
    except OSError: pytest.skip("ссылки недоступны")
    with pytest.raises(gp.PlayError):
        gp.resolve(str(root / "G"), "evil.exe", str(root))


def test_command_exe_and_bat(tmp_path):
    assert gp.command(str(tmp_path / "A.exe")) == ([str(tmp_path / "A.exe")], str(tmp_path))
    assert gp.command(str(tmp_path / "run.BAT")) == (["cmd", "/c", str(tmp_path / "run.BAT")], str(tmp_path))


def test_launch_uses_popen_only_on_windows(tmp_path):
    root = tmp_path / "root"; tree(root, ["G/Game.exe"]); calls = []
    name = gp.launch(str(root / "G"), "Game.exe", str(root), popen=lambda a, **k: calls.append((a, k)), windows=True)
    assert name == "Game.exe" and calls and calls[0][1]["cwd"] == str(root / "G")
    calls.clear()
    with pytest.raises(gp.PlayError):
        gp.launch(str(root / "G"), "Game.exe", str(root), popen=lambda a, **k: calls.append(a), windows=False)
    assert not calls


def test_launch_oserror_becomes_playerror(tmp_path):
    root = tmp_path / "root"; tree(root, ["G/Game.exe"])
    def boom(*a, **k): raise OSError(13, "Отказано в доступе")
    with pytest.raises(gp.PlayError):
        gp.launch(str(root / "G"), "Game.exe", str(root), popen=boom, windows=True)


def test_guest_cannot_use_play_routes():
    for p in ("/api/game/play", "/api/game/exe", "/api/game/exes"):
        assert not lan.guest_allowed("POST", p)


def test_api_list_choose_and_play(server):
    root = make_root(server, ["Cool Game/Cool.exe", "Cool Game/unins000.exe", "Cool Game/bin/run.bat"])
    x = game(server, "Cool Game"); assert x["g"]["downloaded"]
    r = jpost(server, "/api/game/exes", {"id": x["id"]})
    assert [e["rel"] for e in r["found"]] == ["Cool.exe", "bin/run.bat"] and r["exe"] == "Cool.exe" and not r["saved"]
    assert "error" in jpost(server, "/api/game/exe", {"id": x["id"], "exe": "../x.exe"})
    assert "error" in jpost(server, "/api/game/exe", {"id": x["id"], "exe": "unknown.exe"})
    assert jpost(server, "/api/game/exe", {"id": x["id"], "exe": "bin/run.bat"})["exe"] == "bin/run.bat"
    assert game(server, "Cool Game")["g"]["exe"] == "bin/run.bat"
    r = jpost(server, "/api/game/exes", {"id": x["id"]}); assert r["exe"] == "bin/run.bat" and r["saved"]
    r = jpost(server, "/api/game/play", {"id": x["id"]})
    assert ("ok" in r) if os.name == "nt" else ("Windows" in r["error"])
    assert jpost(server, "/api/game/exe", {"id": x["id"], "exe": ""})["exe"] == ""


def test_api_play_not_downloaded(server):
    assert "error" in jpost(server, "/api/game/play", {"id": 999999})


def test_ui_play_button_chooser_saves_choice(server, page):
    make_root(server, ["Cool Game/Cool.exe", "Cool Game/bin/run.bat"])
    page.goto(server.url + "/#games")
    page.locator("#ggrid [data-card]").first.wait_for(); page.locator("#ggrid [data-card]").first.click()
    panel = page.locator("#gpanel")
    panel.get_by_role("button", name="Играть", exact=True).click()
    sel = panel.get_by_label("Файл запуска"); sel.wait_for()
    assert sel.evaluate("e=>e===document.activeElement")                      # фокус перенесён на выбор
    sel.select_option("bin/run.bat")
    panel.get_by_role("button", name="Запомнить и играть").click()
    page.wait_for_function("()=>[...document.querySelectorAll('#gpanel button')].some(b=>b.textContent==='Сменить файл запуска')")
    assert game(server, "Cool Game")["g"]["exe"] == "bin/run.bat"
    assert page.get_by_role("button", name="Играть", exact=True).count() >= 1
