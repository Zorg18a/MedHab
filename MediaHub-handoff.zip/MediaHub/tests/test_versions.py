# «Версии и чистка» и «Вкладки браузера» как родной раздел (раньше GameSweep в iframe со своим сервером).
import json, os, subprocess, sys, time
from pathlib import Path
ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
import pytest
import lan
from test_game_find import jget, jpost, wait_scan

LIB = ["new6/ADeckOfHex-v1.15.zip", "new6/ADeckOfHex-v1.21.zip", "RPG v1.0/www/save/file1.rpgsave", "RPG v1.1/www/save/file2.rpgsave", "Solo v1.0/a.txt"]


def build(server, files=LIB, saves=True):
    root = server.base / f"VL{time.time_ns()}"
    for rel in files:
        p = root / rel; p.parent.mkdir(parents=True, exist_ok=True); p.write_bytes(b"OLD1" if "v1.0/www" in rel else b"NEW2" if "v1.1/www" in rel else b"x")
    return root


def scan(server, root, layout="auto"):
    wait_scan(server)
    for _ in range(100):
        if not jget(server, "/api/versions/state")["running"]: break
        time.sleep(0.05)
    r = jpost(server, "/api/versions/scan", {"root": str(root), "layout": layout}); assert r.get("started") is True, r
    time.sleep(0.2)
    for _ in range(200):
        st = jget(server, "/api/versions/state")
        if st["scanned"] and not st["running"] and st["root"] == str(root): return st
        time.sleep(0.05)
    raise AssertionError("scan did not finish")


# ---------- сервер ----------
def test_scan_validates_folder_and_remembers_it(server):
    try:
        jpost(server, "/api/settings", {"games_root": ""})
        assert "Укажите папку" in jpost(server, "/api/versions/scan", {})["error"]
        r = server.post("/api/versions/scan", {"root": str(server.base / "нет-такой")}); assert r[0] == 400 and "Папка не найдена" in json.loads(r[2])["error"]
        root = build(server); st = scan(server, root)
        assert jget(server, "/api/settings")["games_root"] == str(root)                      # одна папка игр на всё приложение
        assert sorted(g["title"] for g in st["groups"]) == ["ADeckOfHex", "RPG"]
        assert (st["summary"]["games"], st["summary"]["groups"], st["summary"]["old"]) == (5, 2, 2)
    finally: jpost(server, "/api/settings", {"games_root": ""})


def test_trash_is_decided_by_the_server_and_saves_are_kept(server):
    try:
        root = build(server); scan(server, root)
        deck_old, deck_keep, rpg_old = (str(root / "new6" / "ADeckOfHex-v1.15.zip"), str(root / "new6" / "ADeckOfHex-v1.21.zip"), str(root / "RPG v1.0"))
        r = jpost(server, "/api/versions/trash", {"paths": [deck_keep, "/etc/passwd", str(root / "нет")], "saves": "ignore"})
        assert not any(x["ok"] for x in r["results"]) and os.path.exists(deck_keep)           # новейшая версия и чужие пути не трогаются
        assert list(jpost(server, "/api/versions/saves", {"paths": [deck_old, rpg_old]})) == [rpg_old]
        assert jpost(server, "/api/versions/reveal", {"path": "/etc/passwd"}) == {"ok": False}   # в проводнике открываются только найденные папки
        r = jpost(server, "/api/versions/trash", {"paths": [rpg_old], "saves": "skip"})["results"][0]
        assert not r["ok"] and os.path.exists(rpg_old)                                        # с сохранениями и «пропустить»
        r = jpost(server, "/api/versions/trash", {"paths": [rpg_old, deck_old], "saves": "copy"})
        assert all(x["ok"] for x in r["results"]) and not os.path.exists(rpg_old) and not os.path.exists(deck_old)
        assert (root / "RPG v1.1/www/save/file1.rpgsave").read_bytes() == b"OLD1" and (root / "RPG v1.1/www/save/file2.rpgsave").read_bytes() == b"NEW2"
        assert any((root / "_GameSweep_Trash").rglob("ADeckOfHex-v1.15.zip")) and r["state"]["summary"]["groups"] == 0   # восстановимо, групп не осталось
    finally: jpost(server, "/api/settings", {"games_root": ""})


def test_current_version_is_removed_only_with_explicit_force(server):
    try:
        root = build(server); scan(server, root); keep = str(root / "new6" / "ADeckOfHex-v1.21.zip")
        r = jpost(server, "/api/versions/trash", {"paths": [keep], "saves": "ignore"})["results"][0]
        assert not r["ok"] and "подтверждение" in r["msg"] and os.path.exists(keep)
        r = jpost(server, "/api/versions/trash", {"paths": [keep], "saves": "ignore", "force": True})["results"][0]
        assert r["ok"] and not os.path.exists(keep) and any((root / "_GameSweep_Trash").rglob("ADeckOfHex-v1.21.zip"))     # восстановимо
    finally: jpost(server, "/api/settings", {"games_root": ""})


def test_tabs_are_compared_with_games_on_pc(server):
    try:
        root = build(server); scan(server, root)
        text = "[RPG](https://f95zone.to/threads/rpg-v1-3-someone.11/)\nhttps://f95zone.to/threads/solo-v1-0-dev.12/\nhttps://f95zone.to/threads/never-seen-v0-1-x.13/\nhttps://example.org/page\nhttps://f95zone.to/threads/never-seen-v0-1-x.13/"
        r = jpost(server, "/api/versions/tabs", {"text": text}); by = {t["name"].lower(): t for t in r["tabs"] if t["kind"] == "game"}
        assert r["summary"]["total"] == 4 and r["summary"]["dups"] == 1 and r["summary"]["games"] == 3, r["summary"]      # дубль убран, прочая страница не игра
        assert by["rpg"]["verdict"] == "update" and by["rpg"]["local"]["path"].endswith("RPG v1.1")                          # на ПК новейшая v1.1, в теме 1.3
        assert by["solo"]["verdict"] == "same" and by["never seen"]["verdict"] == "missing" and by["never seen"]["local"] is None
    finally: jpost(server, "/api/settings", {"games_root": ""})


def test_old_iframe_server_is_gone_and_guests_cannot_reach_new_routes(server):
    import gamesweep
    assert not any(hasattr(gamesweep, n) for n in ("Handler", "make_server", "PAGE"))
    assert server.get("/api/games")[0] == 404 and "gsf" not in server.get("/")[2].decode() and b"<iframe" not in server.get("/")[2]
    for p in ("/api/versions/state",): assert not lan.guest_allowed("GET", p)
    for p in ("scan", "saves", "tabs", "trash", "reveal"): assert not lan.guest_allowed("POST", f"/api/versions/{p}"), p


def test_gamesweep_logic_selftest_passes():
    p = subprocess.run([sys.executable, "gamesweep.py", "--selftest"], cwd=ROOT, capture_output=True, text=True, timeout=300, env=dict(os.environ, PYTHONUTF8="1"))
    assert "ошибок 0" in p.stdout and p.returncode == 0, p.stdout[-1500:]


# ---------- в браузере ----------
def open_versions(page, server):
    errors = []; page.on("pageerror", lambda e: errors.append(str(e)))
    page.goto(server.url + "/#games"); page.get_by_role("tab", name="Версии и чистка").click()
    page.wait_for_selector("#gtab-ver:not(.hide)"); return errors


def test_ui_scan_search_filter_and_send_to_trash(server, page):
    try:
        root = build(server); jpost(server, "/api/settings", {"games_root": str(root)}); wait_scan(server)
        errors = open_versions(page, server)
        assert page.locator("iframe").count() == 0
        page.wait_for_function("document.getElementById('v-root').value !== ''"); assert page.input_value("#v-root") == str(root)
        page.click("#v-scan"); page.wait_for_selector("#v-list .vgrp")
        assert page.locator("#v-list .vgrp").count() == 2 and page.inner_text("#v-c3") == "2" and page.inner_text("#v-c1") == "5"
        for cb in page.locator("#v-list input[type=checkbox]").all(): assert (cb.get_attribute("aria-label") or "").startswith("Выбрать для Корзины:")      # у каждого флажка есть имя
        fold = page.locator("#v-list [data-action=fold]").first; assert fold.get_attribute("aria-expanded") == "true"
        fold.click(); assert page.locator("#v-list [data-action=fold]").first.get_attribute("aria-expanded") == "false"
        page.locator("#v-list [data-action=fold]").first.click()
        page.fill("#v-q", "rpg"); page.wait_for_function("document.querySelectorAll('#v-list .vgrp').length === 1"); assert "Групп: 1 из 2" in page.inner_text("#v-count")
        assert page.locator("#v-list mark").count() >= 1                                             # подсветка найденного
        page.fill("#v-q", "ыдфму"); page.wait_for_function("document.querySelectorAll('#v-list .vgrp').length >= 0")
        page.fill("#v-q", "")
        chip = page.get_by_role("button", name="Только старые"); chip.click(); assert chip.get_attribute("aria-pressed") == "true"
        assert page.locator("#v-list .vrow").count() == 2; chip.click(); assert chip.get_attribute("aria-pressed") == "false"
        page.click("#v-list [data-action=open] >> nth=0"); assert "Подробности" in (page.get_attribute("#v-detail", "aria-label") or "") and page.locator("#v-detail h3").count() == 1
        assert page.locator("#v-list [aria-current=true]").count() == 1
        page.click("#v-selold"); assert "Выбрано 2" in page.inner_text("#v-selinfo") and page.is_enabled("#v-trash")
        page.click("#v-trash"); page.wait_for_selector("#vTrashDlg[open]")
        assert page.get_by_role("dialog", name="В Корзину").count() == 1 and page.locator("input[name=vsv]").count() == 3 and page.locator("input[name=vsv]:checked").get_attribute("value") == "copy"
        page.click("#vTrashYes"); page.wait_for_function("!document.getElementById('vTrashDlg').open")
        page.wait_for_function("document.getElementById('v-c3').textContent === '0'")
        assert not (root / "RPG v1.0").exists() and not (root / "new6/ADeckOfHex-v1.15.zip").exists() and (root / "new6/ADeckOfHex-v1.21.zip").exists()
        assert (root / "RPG v1.1/www/save/file1.rpgsave").read_bytes() == b"OLD1"                    # сохранения переехали
        assert page.evaluate("document.activeElement.id") == "v-selinfo"                             # фокус не потерялся на отключённой кнопке
        assert not errors, errors
    finally: jpost(server, "/api/settings", {"games_root": ""})


def test_ui_current_version_needs_explicit_confirmation(server, page):
    try:
        root = build(server); jpost(server, "/api/settings", {"games_root": str(root)}); wait_scan(server); open_versions(page, server)
        page.click("#v-scan"); page.wait_for_selector("#v-list .vgrp")
        page.locator("#v-list .vrow", has_text="v1.21").locator("input").check(); page.click("#v-trash"); page.wait_for_selector("#vTrashDlg[open]")
        assert page.is_disabled("#vTrashYes") and "актуальные" in page.inner_text("#vTrashBody")
        page.check("#vForce"); assert page.is_enabled("#vTrashYes"); page.uncheck("#vForce"); assert page.is_disabled("#vTrashYes")
        page.keyboard.press("Escape"); page.wait_for_function("!document.getElementById('vTrashDlg').open")
        assert (root / "new6/ADeckOfHex-v1.21.zip").exists()
        assert page.evaluate("document.activeElement.id") == "v-trash"                               # фокус вернулся на кнопку
    finally: jpost(server, "/api/settings", {"games_root": ""})


def test_ui_slash_focuses_search_and_errors_are_announced(server, page):
    try:
        jpost(server, "/api/settings", {"games_root": ""}); open_versions(page, server)
        page.locator("#gt-ver").focus(); page.keyboard.press("/"); assert page.evaluate("document.activeElement.id") == "v-q"
        page.fill("#v-root", str(server.base / "нет-такой")); page.click("#v-scan")
        page.wait_for_selector("#v-err:not([hidden])"); assert page.get_attribute("#v-err", "role") == "alert" and "Папка не найдена" in page.inner_text("#v-err")
        assert page.evaluate("document.activeElement.id") == "v-root"
    finally: jpost(server, "/api/settings", {"games_root": ""})


def test_ui_tabs_mode_compares_pasted_links(server, page):
    try:
        root = build(server); jpost(server, "/api/settings", {"games_root": str(root)}); wait_scan(server); open_versions(page, server)
        page.click("#v-scan"); page.wait_for_selector("#v-list .vgrp")
        page.get_by_role("tab", name="Вкладки браузера").click(); assert page.locator("#vp-v").evaluate("e=>e.classList.contains('hide')") and page.locator("#vp-t").evaluate("e=>!e.classList.contains('hide')")
        page.click("#v-tpaste"); page.wait_for_selector("#vPasteDlg[open]")
        page.fill("#v-ptext", "[RPG](https://f95zone.to/threads/rpg-v1-3-someone.11/)\nhttps://f95zone.to/threads/never-seen-v0-1-x.13/\nhttps://example.org/page")
        page.click("#vPasteYes"); page.wait_for_selector("#v-tlist .vtrow")
        assert page.inner_text("#v-t1") == "3" and page.inner_text("#v-t2") == "2" and page.inner_text("#v-t4") == "1" and "вкладок" in page.inner_text("#v-tname")
        assert page.locator("#v-tlist .vtrow", has_text="обновить").count() == 1 and page.locator("#v-tlist .vtrow", has_text="нет на ПК").count() >= 1
        assert page.is_enabled("#v-eupd") and "(1)" in page.inner_text("#v-eupd")
        page.click("#v-tlist .vtrow >> nth=0"); assert "Версия в теме" in page.inner_text("#v-tdetail") and page.locator("#v-tdetail a[rel*=noopener]").count() == 1
        chip = page.get_by_role("button", name="Нет на ПК", exact=True); chip.click(); assert chip.get_attribute("aria-pressed") == "true" and page.locator("#v-tlist .vtrow").count() == 1
    finally: jpost(server, "/api/settings", {"games_root": ""})
