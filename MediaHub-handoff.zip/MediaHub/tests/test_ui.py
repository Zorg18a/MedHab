import pytest


def imp(page, mod, expr):
    return page.evaluate(f"import('/js/ui/{mod}.js').then(m=>{expr})")


def test_chip_html_has_pressed_and_escapes(server, page):
    page.goto(server.url)
    h = imp(page, "chip", "m.chipHtml('<b>Видео</b>',{pressed:true,count:3,action:'kind',value:'video'})")
    assert 'aria-pressed="true"' in h and "<b>Видео" not in h and "&lt;b&gt;" in h
    assert 'data-action="kind"' in h and 'data-value="video"' in h
    assert 'data-b="3"' in imp(page, "chip", "m.chipHtml('X',{pressed:false,action:'f',value:'v',data:{b:3}})")
    off = imp(page, "chip", "m.chipHtml('Аудио',{pressed:false,action:'kind',value:'audio'})")
    assert 'aria-pressed="false"' in off and " on" not in off


def test_switch_html_is_switch_role_with_name(server, page):
    page.goto(server.url)
    h = imp(page, "switch", "m.switchHtml('x1','Режим \"а\"',true)")
    assert 'role="switch"' in h and "checked" in h and 'aria-label="Режим &quot;а&quot;"' in h


@pytest.mark.parametrize("a,b,want", [(0, 24, None), (20, 30, 25), (24, 100, 100), (30, 40, None)])
def test_milestone(server, page, a, b, want):
    page.goto(server.url)
    assert imp(page, "progress", f"m.milestone({a},{b})") == want


def test_progress_html_attrs(server, page):
    page.goto(server.url)
    h = imp(page, "progress", "m.progressHtml(42.4,'Видео')")
    assert 'role="progressbar"' in h and 'aria-valuenow="42"' in h and 'aria-label="Видео"' in h
    assert 'aria-valuenow="100"' in imp(page, "progress", "m.progressHtml(180,'x')")


def test_field_error_sets_aria_and_focuses(server, page):
    page.goto(server.url)
    page.evaluate("document.body.insertAdjacentHTML('beforeend','<textarea id=\"t\" aria-label=\"Ссылки\"></textarea>')")
    imp(page, "field", "m.fieldError(document.getElementById('t'),'Вставьте ссылку')")
    assert page.get_attribute("#t", "aria-invalid") == "true"
    assert page.evaluate("document.activeElement.id") == "t"
    desc = page.get_attribute("#t", "aria-describedby")
    assert "Вставьте ссылку" in page.locator("#" + desc).inner_text()
    assert "Вставьте ссылку" in page.locator("#mh-live-assertive").inner_text()
    imp(page, "field", "m.clearFieldError(document.getElementById('t'))")
    assert page.get_attribute("#t", "aria-invalid") is None and page.locator("#t-err").count() == 0


def test_tabs_arrow_keys_move_selection(server, page):
    page.goto(server.url)
    page.evaluate("""document.body.insertAdjacentHTML('beforeend','<div id="tl" role="tablist"><button role="tab" id="ta" data-panel="pa" data-tab="a" aria-selected="true">A</button><button role="tab" id="tb" data-panel="pb" data-tab="b" aria-selected="false">B</button><button role="tab" id="tc" data-panel="pc" data-tab="c" aria-selected="false">C</button></div>');
      window.__sel=[]; import('/js/ui/tabs.js').then(m=>m.initTabs(document.getElementById('tl'),id=>window.__sel.push(id)))""")
    page.wait_for_function("document.getElementById('ta').getAttribute('aria-controls')==='pa'")
    assert page.evaluate("[...document.querySelectorAll('#tl [role=tab]')].map(t=>t.tabIndex)") == [0, -1, -1]
    page.focus("#ta")
    page.keyboard.press("ArrowRight")
    assert page.get_attribute("#tb", "aria-selected") == "true" and page.evaluate("document.activeElement.id") == "tb"
    page.keyboard.press("End")
    assert page.evaluate("document.activeElement.id") == "tc"
    page.keyboard.press("ArrowRight")
    assert page.evaluate("document.activeElement.id") == "ta"
    assert page.evaluate("window.__sel") == ["b", "c", "a"]
    assert page.evaluate("[...document.querySelectorAll('#tl [role=tab]')].map(t=>t.tabIndex)") == [0, -1, -1]


def test_dialog_returns_focus_to_opener(server, page):
    page.goto(server.url)
    page.evaluate("document.body.insertAdjacentHTML('beforeend','<button id=\"op\">o</button><dialog id=\"d\"><button id=\"in\">x</button></dialog>')")
    page.focus("#op")
    page.evaluate("import('/js/ui/dialog.js').then(m=>m.openDialog(document.getElementById('d'), document.getElementById('op')))")
    assert page.evaluate("document.getElementById('d').open")
    page.keyboard.press("Escape")
    assert page.evaluate("document.activeElement.id") == "op"
    page.evaluate("import('/js/ui/dialog.js').then(m=>m.openDialog(document.getElementById('d'), document.getElementById('op')))")
    page.evaluate("import('/js/ui/dialog.js').then(m=>m.closeDialog(document.getElementById('d')))")
    assert page.evaluate("document.activeElement.id") == "op"


def test_card_button_role_escape_and_keys(server, page):
    page.goto(server.url)
    h = imp(page, "cardbtn", "m.cardButtonHtml({id:7,label:'Игра \"X\"',inner:'<i></i>'})")
    assert 'role="button"' in h and 'tabindex="0"' in h and "data-card" in h and 'aria-label="Игра &quot;X&quot;"' in h
    page.evaluate(f"""document.body.insertAdjacentHTML('beforeend','<div id="cr">'+{h!r}+'</div>');
      window.__c=0; document.querySelector('#cr [data-card]').addEventListener('click',()=>window.__c++);
      import('/js/ui/cardbtn.js').then(m=>m.bindCardKeys(document.getElementById('cr')))""")
    page.wait_for_timeout(200)
    page.focus("#cr [data-card]")
    page.keyboard.press("Enter")
    page.keyboard.press("Space")
    assert page.evaluate("window.__c") == 2
