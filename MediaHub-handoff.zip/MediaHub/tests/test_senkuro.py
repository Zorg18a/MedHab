# Движок Senkuro: разбор данных страницы (window.__SENKURO__) по урезанным настоящим образцам.
import json
from pathlib import Path
import pytest
import engine_senkuro as E
import enginekit

FX = Path(__file__).parent / "fixtures" / "senkuro"
BASE = "https://senkuro.me/manga/copy-skills-with-affinity"
read = lambda n: (FX / n).read_text("utf-8")


def test_slug_of():
    assert E.slug_of(BASE + "/chapters") == "copy-skills-with-affinity" and E.slug_of("https://senkuro.me/") == ""


def test_parse_title():
    t = E.parse_title(read("chapters.html"), BASE + "/chapters")
    assert t["slug"] == "copy-skills-with-affinity" and t["title"] == "Копирование навыков через симпатию!"      # русское название
    assert t["cover"].startswith("https://mirai.senkuro.net/") and "Драма" in t["genres"] and len(t["genres"]) == 18
    assert t["description"].startswith("Эйден")
    assert len(t["chapters"]) == 14 and t["total"] == 14 and not t["partial"]
    assert [c["cid"] for c in t["chapters"]][:2] == ["1-14", "1-13"] and t["chapters"][-1]["cid"] == "1-1"           # новые первыми
    c = t["chapters"][-1]
    assert c["label"] == "Том 1 Глава 1" and c["url"] == BASE + "/chapters/252092121941558802/pages/1"


def test_parse_chapter_both_script_forms():
    p = E.parse_chapter(read("chapter.html"), BASE + "/chapters/1/pages/1")
    assert len(p["pages"]) == 15 and all(u.startswith("https://mirai.senkuro.net/manga-chapters/") for u in p["pages"])   # оригиналы, по порядку
    assert len(set(p["pages"])) == 15
    # первая форма (data:"...") и вторая (let a="...") дают одно и то же состояние
    assert set(E._states(read("chapters.html"))) == {"manga", "mangaChapters"} and set(E._states(read("chapter.html"))) == {"mangaChapter"}


def test_viewer_block_never_read():
    secret = json.dumps(json.dumps({"viewer": {"login": "SECRET-NICK"}, "manga": {"slug": "x"}}))
    st = E._states(f"<script>window.__SENKURO__=({{graphql:{{a:{{data:{secret}}}}}}})</script>")
    assert "viewer" not in st and "SECRET-NICK" not in json.dumps(st)


def test_partial_list_is_flagged():
    html = read("chapters.html").replace('\\"hasNextPage\\":false', '\\"hasNextPage\\":true')
    assert E._states(html)["mangaChapters"]["pageInfo"]["hasNextPage"] is True and E.parse_title(html, BASE)["partial"]
    assert E.parse_title(read("chapters.html").replace('\\"chapters\\":14', '\\"chapters\\":40'), BASE)["partial"]


def test_chapters_sorted_numerically():
    html = read("chapters.html")
    t = E.parse_title(html, BASE); nums = [float(c["num"]) for c in t["chapters"]]
    assert nums == sorted(nums, reverse=True)


def test_empty_and_blocked():
    assert E.parse_title("<html></html>", BASE)["chapters"] == [] and E.parse_chapter("<html></html>", BASE)["pages"] == []
    with pytest.raises(enginekit.EngineError):
        E.load_title(lambda u: "<html></html>", "https://senkuro.me", "copy-skills-with-affinity")
    with pytest.raises(enginekit.EngineError):
        E.load_pages(lambda u: "<html></html>", {"url": BASE})
    seen = []
    t = E.load_title(lambda u: (seen.append(u), read("chapters.html"))[1], "https://senkuro.me", "copy-skills-with-affinity")
    assert seen == [BASE + "/chapters"] and t["chapters"]


def test_foreign_image_hosts_are_dropped():
    c = json.dumps(json.dumps({"mangaChapter": {"pages": [
        {"number": 2, "image": {"original": {"url": "https://mirai.senkuro.net/a.jpg"}}},
        {"number": 1, "image": {"original": {"url": "https://evil.example/x.jpg"}}},
        {"number": 3, "image": {"compress": {"url": "http://mirai.senkuro.net/plain.jpg"}}}]}}))
    assert E.parse_chapter(f"<script>window.__SENKURO__=({{d:{c}}})</script>", BASE)["pages"] == ["https://mirai.senkuro.net/a.jpg"]
