# Видео: настройки качества и формата по сайтам, плейлисты.
import json
import pytest
import videolib as v


@pytest.mark.parametrize("raw,want", [
    ("https://www.youtube.com/watch?v=1", "youtube.com"), ("https://youtu.be/abc", "youtube.com"), ("https://music.youtube.com/x", "youtube.com"),
    ("HTTPS://M.Vimeo.com/1", "vimeo.com"), ("rutube.ru", "rutube.ru"), ("www.RuTube.ru/video/", "rutube.ru"),
    ("", ""), ("not a host", ""), ("http://localhost/x", ""), ("javascript:alert(1)", "")])
def test_site_key(raw, want):
    assert v.site_key(raw) == want


def test_clean_profiles_drops_bad_values():
    got = v.clean_profiles({"www.YouTube.com": {"res": "1080", "vfmt": "mkv", "afmt": "flac", "evil": 1}, "x.org": {"res": "999", "vfmt": "avi"},
                            "bad host": {"res": "720"}, "vimeo.com": {"res": 720}, "rutube.ru": "no"})
    assert got == {"youtube.com": {"res": "1080", "vfmt": "mkv", "afmt": "flac"}, "vimeo.com": {"res": "720"}}
    assert v.clean_profiles(None) == {} and v.clean_profiles([1]) == {}
    assert len(v.clean_profiles({f"s{i}.com": {"res": "720"} for i in range(80)})) == v.MAX_SITES


def test_job_options_priority():
    cfg = {"res": "best", "afmt": "mp3", "site_media": {"youtube.com": {"res": "720", "vfmt": "mkv"}}}
    assert v.job_options("https://youtu.be/x", cfg) == {"res": "720", "afmt": "mp3", "vfmt": "mkv"}                 # настройка сайта
    assert v.job_options("https://youtu.be/x", cfg, {"res": "1080"})["res"] == "1080"                              # явный выбор сильнее
    assert v.job_options("https://vimeo.com/1", cfg) == {"res": "best", "afmt": "mp3", "vfmt": "mp4"}              # сайта нет: общие
    assert v.job_options("https://a.com/1", {"res": "bogus", "afmt": "wav"}) == {"res": "best", "afmt": "mp3", "vfmt": "mp4"}


def test_format_string():
    assert v.format_string("audio", "720") == "bestaudio/best"
    assert v.format_string("video", "best") == "bv*+ba/b"
    assert v.format_string("video", "720") == "bv*[height<=720]+ba/b[height<=720]"


def test_playlist_map_and_info():
    t = {"_type": "playlist", "title": " Уроки ", "entries": [{"url": "https://y/1"}, None, {"webpage_url": "https://y/2"}, {"url": "id-only"}]}
    assert v.playlist_map(t) == ("Уроки", {"https://y/1": "Уроки", "https://y/2": "Уроки"})
    assert v.playlist_map({"_type": "video"}) == ("", {}) and v.playlist_map(None) == ("", {})
    j = v.with_playlist('{"a": 1}', "Уроки")
    assert json.loads(j) == {"a": 1, "playlist": "Уроки"} and v.playlist_of(j) == "Уроки"
    assert v.with_playlist("битый", "") == "{}" and v.with_playlist(None, "X") == '{"playlist": "X"}'
    assert v.playlist_of("") == "" and v.playlist_of("[1]") == ""


# ---------- API и интерфейс ----------
def _jget(server, path): return json.loads(server.get(path)[2])
def _jpost(server, path, body): return json.loads(server.post(path, body)[2])


def test_api_site_media_roundtrip_and_validation(server):
    try:
        r = _jpost(server, "/api/settings", {"site_media": {"www.YouTube.com": {"res": "720", "vfmt": "mkv", "bad": 1}}})
        assert r["site_media"] == {"youtube.com": {"res": "720", "vfmt": "mkv"}}
        assert _jget(server, "/api/settings")["site_media"] == r["site_media"]
        e = _jpost(server, "/api/settings", {"site_media": {"youtube.com": {"res": "720"}, "не сайт": {"res": "480"}}})
        assert "error" in e and "не сайт" in e["error"]
        assert _jget(server, "/api/settings")["site_media"] == r["site_media"]           # при ошибке ничего не изменилось
    finally:
        _jpost(server, "/api/settings", {"site_media": {}})


def test_api_library_exposes_playlist_for_video(server):
    server.add_item(title="Урок 1", kind="video"); server.add_item(title="Одиночное", kind="video")
    server._sql("update items set info=? where title=?", (json.dumps({"playlist": "Курс Python"}), "Урок 1"))
    lib = {x["title"]: x for x in _jget(server, "/api/library?q=")}
    assert lib["Урок 1"]["playlist"] == "Курс Python" and lib["Одиночное"]["playlist"] == ""


def test_ui_site_settings_add_remove(server, page):
    try:
        page.goto(server.url + "/#settings")
        page.get_by_label("Сайт", exact=True).fill("https://www.youtube.com/watch?v=1")
        page.get_by_label("Качество", exact=True).select_option("720")
        page.get_by_role("button", name="Добавить сайт").click()
        page.get_by_role("button", name="Убрать youtube.com").wait_for()
        assert "качество 720" in page.locator("#sm_list").inner_text()
        assert page.get_by_label("Сайт", exact=True).evaluate("e=>e===document.activeElement")          # фокус вернулся в поле
        page.get_by_label("Сайт", exact=True).fill("не сайт")
        page.get_by_role("button", name="Добавить сайт").click()
        page.wait_for_function("()=>document.getElementById('sm_err').textContent.length>0")
        assert page.get_by_label("Сайт", exact=True).get_attribute("aria-invalid") == "true"
        page.get_by_role("button", name="Убрать youtube.com").click()
        page.get_by_text("Пока нет: везде общие настройки.").wait_for()
        assert page.get_by_label("Сайт", exact=True).evaluate("e=>e===document.activeElement")          # список пуст: фокус в поле
    finally:
        _jpost(server, "/api/settings", {"site_media": {}})


def test_ui_group_by_playlist_and_sort(server, page):
    server.add_item(title="Урок 1", kind="video"); server.add_item(title="Одиночное", kind="video")
    server._sql("update items set info=? where title=?", (json.dumps({"playlist": "Курс Python"}), "Урок 1"))
    page.goto(server.url + "/#library")
    page.locator("#gb").select_option("playlist")
    page.get_by_role("heading", name="Курс Python").wait_for()
    assert page.get_by_role("heading", name="Без плейлиста").count() == 1
    page.locator("#gb").select_option("")
    page.locator("#so").select_option("old")
    titles = page.locator("#lib h3.t").all_inner_texts()
    assert titles == ["Урок 1", "Одиночное"]                                                          # старые первыми


# ---------- сквозной: media() с подставной yt_dlp ----------
DRIVER = r'''
import json, os, sys, types
sys.path.insert(0, ".")
seen = []
class DC(Exception): pass
class FakeYDL:
    def __init__(self, o): self.o = o
    def __enter__(self): return self
    def __exit__(self, *a): return False
    def extract_info(self, url, download=False):
        if url.endswith("/list"): return {"_type": "playlist", "title": "Курс Python", "entries": [{"url": "https://y.example/1"}, {"url": "https://y.example/2"}]}
        return {"_type": "video"}
    def download(self, urls):
        u = urls[0]; seen.append({"format": self.o["format"], "merge": self.o.get("merge_output_format")})
        p = os.path.join(os.environ["OUTDIR"], u.rsplit("/", 1)[1] + ".mp4"); open(p, "wb").write(b"x" * 5)
        for h in self.o["postprocessor_hooks"]: h({"postprocessor": "MoveFiles", "status": "finished", "info_dict": {"title": "V" + u[-1], "uploader": "Chan", "filepath": p, "webpage_url": u}})
m = types.ModuleType("yt_dlp"); m.YoutubeDL = FakeYDL; m.utils = types.SimpleNamespace(DownloadCancelled=DC); sys.modules["yt_dlp"] = m
import app, videolib
app.backfill = lambda: None; app.scan = lambda: None
app.cfg["site_media"] = {"y.example": {"res": "720", "vfmt": "mkv"}}; app.cfg["workers"] = 1
def run(url):
    job = dict(kind="video", url=url, topic="", subs="", thumbs=False, cancel=False, title="", speed=0, eta=0, pct=0, **videolib.job_options(url, app.cfg))
    app.media(job); return job
j1 = run("https://y.example/list"); j2 = run("https://y.example/solo")
rows = {r["title"]: r["info"] for r in app.sql("select title, info from items")}
print("RESULT" + json.dumps({"seen": seen, "rows": rows, "j1": [j1["res"], j1["vfmt"]]}, ensure_ascii=False))
'''


def test_media_uses_site_profile_and_remembers_playlist():
    import os, shutil, subprocess, sys, tempfile
    from pathlib import Path
    root = Path(__file__).resolve().parent.parent
    tmp = Path(tempfile.mkdtemp(prefix="mh-vid-"))
    try:
        for e in root.iterdir():
            if e.name in {"tests", "ffmpeg", "library.db", "settings.json", ".git", "docs", "__pycache__"} or e.suffix == ".zip": continue
            shutil.copytree(e, tmp / e.name, ignore=shutil.ignore_patterns("__pycache__")) if e.is_dir() else shutil.copy2(e, tmp / e.name)
        (tmp / "out").mkdir(); (tmp / "settings.json").write_text(json.dumps({"folder": str(tmp / "dl"), "games_root": ""}), "utf-8"); (tmp / "driver.py").write_text(DRIVER, "utf-8")
        p = subprocess.run([sys.executable, "driver.py"], cwd=tmp, capture_output=True, text=True, timeout=120,
                           env=dict(os.environ, MEDIAHUB_NO_BROWSER="1", PYTHONUTF8="1", OUTDIR=str(tmp / "out")))
        line = next((l for l in p.stdout.splitlines() if l.startswith("RESULT")), None); assert line, p.stdout[-800:] + p.stderr[-2000:]
        r = json.loads(line[6:])
    finally:
        shutil.rmtree(tmp, ignore_errors=True)
    assert r["j1"] == ["720", "mkv"]
    assert len(r["seen"]) == 3 and all(s == {"format": "bv*[height<=720]+ba/b[height<=720]", "merge": "mkv"} for s in r["seen"])   # настройка сайта дошла до загрузчика
    assert v.playlist_of(r["rows"]["V1"]) == "Курс Python" and v.playlist_of(r["rows"]["V2"]) == "Курс Python"
    assert v.playlist_of(r["rows"]["Vo"]) == ""                                                                                  # одиночное видео без плейлиста
