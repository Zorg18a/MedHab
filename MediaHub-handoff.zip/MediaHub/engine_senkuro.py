"""Движок манги для Senkuro: разбор страниц тайтла и главы. Без сети и без app.py, проверяется на сохранённых образцах (tests/fixtures/senkuro).

Что известно о сайте (по сохранённым страницам):
  сайт отдаёт страницу вместе с данными в скрипте `window.__SENKURO__`: внутри JSON-строки с ключами manga, mangaChapters, mangaChapter.
  вкладка глав  {site}/manga/{slug}/chapters                          manga (название, обложка, жанры) и mangaChapters (до одной «страницы» списка)
  глава         {site}/manga/{slug}/chapters/{номер-главы}/pages/1     mangaChapter.pages: [{number, image: {original: {url}}}]
  картинки      https://mirai.senkuro.net/manga-chapters/...jpeg       оригиналы; рядом ужатая копия на shiro.senkuro.net
В тех же данных есть блок `viewer` (сведения об аккаунте): он не читается и нигде не сохраняется."""
import json
import re
from urllib.parse import urlparse

from enginekit import EngineError, looks_blocked

WANT = ("manga", "mangaChapters", "mangaChapter")
LITERAL = re.compile(r'"((?:[^"\\]|\\.)*)"')


def slug_of(url: str) -> str:
    m = re.match(r"^/manga/([a-z0-9_-]+)", urlparse(url).path)
    return m.group(1) if m else ""


def _states(html: str) -> dict:
    """Нужные блоки данных страницы {manga|mangaChapters|mangaChapter: объект}. Остальное (в том числе viewer) отбрасывается."""
    out = {}
    for sc in re.findall(r"<script[^>]*>(window\.__SENKURO__.*?)</script>", html or "", re.S):
        for m in LITERAL.finditer(sc):
            raw = m.group(1)
            if not raw.startswith('{\\"'):
                continue
            try:
                d = json.loads(json.loads('"' + raw + '"'))
            except ValueError:
                continue
            if isinstance(d, dict):
                for k in WANT:
                    if isinstance(d.get(k), dict):
                        out.setdefault(k, d[k])
    return out


def _title_of(titles, lang):
    for t in titles or []:
        if isinstance(t, dict) and t.get("lang") == lang and t.get("content"):
            return str(t["content"]).strip()
    return ""


def _text(node) -> str:
    """Текст описания (редактор Tiptap): абзацы через перевод строки."""
    if isinstance(node, list):
        parts = [_text(x) for x in node]
        return "\n".join(p for p in parts if p)
    if isinstance(node, dict):
        if isinstance(node.get("text"), str):
            return node["text"]
        inner = _text(node.get("content") or [])
        return inner
    return ""


def _num(x) -> float:
    try:
        return float(x)
    except (TypeError, ValueError):
        return 0.0


def _fmt(x) -> str:
    s = str(x if x is not None else "")
    return s[:-2] if s.endswith(".0") else s


def parse_title(html: str, base: str) -> dict:
    """Вкладка глав -> {slug, title, cover, description, genres, chapters, total, partial}; главы новые первыми."""
    st = _states(html)
    m = st.get("manga") or {}
    site = f"{urlparse(base).scheme}://{urlparse(base).netloc}"
    slug = str(m.get("slug") or slug_of(base))
    title = _title_of(m.get("titles"), "RU") or (m.get("originalName") or {}).get("content") or _title_of(m.get("titles"), "EN") or slug
    ru = next((x for x in m.get("localizations") or [] if isinstance(x, dict) and x.get("lang") == "RU"), {})
    cover = ((m.get("cover") or {}).get("original") or {}).get("url") or ""
    genres = [t for t in (_title_of(l.get("titles"), "RU") for l in m.get("labels") or [] if isinstance(l, dict)) if t]
    conn = st.get("mangaChapters") or {}
    chapters, seen = [], set()
    for e in conn.get("edges") or []:
        n = (e or {}).get("node") or {}
        cs = str(n.get("slug") or "")
        if not cs or not re.fullmatch(r"[0-9A-Za-z_-]+", cs):
            continue
        vol, num = _fmt(n.get("volume")), _fmt(n.get("number"))
        cid = f"{vol}-{num}"
        if cid in seen:
            continue
        seen.add(cid)
        name = str(n.get("name") or "").strip()
        name = "" if name == "None" else name
        chapters.append({"cid": cid, "vol": vol, "num": num, "url": f"{site}/manga/{slug}/chapters/{cs}/pages/1", "date": str(n.get("createdAt") or ""),
                         "label": f"Том {vol} Глава {num}" + (f" {name}" if name else "")})
    chapters.sort(key=lambda c: (_num(c["vol"]), _num(c["num"])), reverse=True)
    total = int(_num(m.get("chapters")))
    return {"slug": slug, "title": str(title).strip(), "cover": cover, "description": _text(ru.get("description")).strip(), "genres": genres,
            "chapters": chapters, "total": total, "partial": bool((conn.get("pageInfo") or {}).get("hasNextPage")) or (total > len(chapters) > 0)}


def parse_chapter(html: str, base: str) -> dict:
    """Страница главы -> {pages: [адреса по порядку], slug}; берутся оригиналы, при их отсутствии ужатая копия."""
    c = _states(html).get("mangaChapter") or {}
    items = []
    for i, p in enumerate(c.get("pages") or []):
        img = (p or {}).get("image") or {}
        u = ((img.get("original") or {}).get("url") or (img.get("compress") or {}).get("url") or "").strip()
        if u.startswith("https://") and (urlparse(u).hostname or "").endswith("senkuro.net"):
            items.append((int(_num((p or {}).get("number"))) or i + 1, i, u))
    items.sort()
    out, seen = [], set()
    for _, _, u in items:
        if u not in seen:
            seen.add(u)
            out.append(u)
    return {"slug": slug_of(base), "pages": out}


def load_title(get_html, site: str, slug: str) -> dict:
    """Скачать и разобрать вкладку глав. get_html(url) -> строка HTML (через расширение под вашим входом)."""
    url = f"{site}/manga/{slug}/chapters"
    html = get_html(url)
    if looks_blocked(html):
        raise EngineError("сайт отдал страницу проверки браузера вместо тайтла: откройте его в браузере с расширением MediaHub и повторите")
    t = parse_title(html, url)
    if not t["chapters"]:
        raise EngineError("на странице тайтла не нашлось глав (нужен вход на сайт, тайтл закрыт или изменилась страница)")
    return t


def load_pages(get_html, ch: dict) -> list:
    """Адреса страниц главы по порядку; EngineError с причиной, если их нет."""
    html = get_html(ch["url"])
    if looks_blocked(html):
        raise EngineError("страница главы не открылась (проверка браузера или блокировка)")
    pages = parse_chapter(html, ch["url"])["pages"]
    if not pages:
        raise EngineError("в главе нет страниц (глава закрыта, нужен вход или изменилась страница)")
    return pages
