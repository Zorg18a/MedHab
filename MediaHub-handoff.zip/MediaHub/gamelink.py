"""Связь «карточка игры ↔ папка»: маркер `.mediahub.json` внутри папки игры и объяснение, почему игра не нашлась.

Маркер нужен, чтобы игра узнавалась после переименования или переноса папки и после переустановки программы:
в нём адрес темы и ключ названия карточки (не номер записи: SQLite использует номера удалённых записей повторно).
Маркер маленький и ничего не меняет в самой игре. GameSweep считает «новизну» папки по самому свежему файлу внутри,
поэтому у маркера всегда стоит время не новее остального содержимого, иначе любая помеченная папка стала бы «самой новой»."""
import json
import os
import time

import gamesweep as gs

MARKER = ".mediahub.json"
MAX_BYTES = 4096
FIELDS = ("thread", "key", "title", "version")
OLD = 946684800.0                      # 2000-01-01


def read_marker(folder: str) -> dict | None:
    """Маркер папки или None (нет файла, не наш, битый, слишком большой)."""
    p = os.path.join(folder, MARKER)
    try:
        if os.path.getsize(p) > MAX_BYTES:
            return None
        with open(p, "rb") as f:
            d = json.loads(f.read().decode("utf-8"))
    except (OSError, ValueError):
        return None
    if not isinstance(d, dict) or d.get("app") != "MediaHub":
        return None
    out = {k: (d[k] if isinstance(d.get(k), str) else "") for k in FIELDS}
    out["linked"] = d["linked"] if isinstance(d.get("linked"), str) else ""
    return out if out["thread"] or out["key"] else None


def write_marker(folder: str, card: dict, linked: str = "auto", mtime: float = 0.0) -> bool:
    """Записать маркер. True — файл записан; False — не нужно (уже такой же) или не вышло (нет прав, диск только для чтения).
    mtime — самый свежий mtime файлов игры из сканирования: маркер получает не больше него, а время папки не меняется."""
    if not os.path.isdir(folder):
        return False
    want = {k: str(card.get(k) or "") for k in FIELDS}
    want["linked"] = linked
    have = read_marker(folder)
    if have == want:
        return False
    p = os.path.join(folder, MARKER)
    tmp = p + ".tmp"
    try:
        st = os.stat(folder)
        data = dict(want, app="MediaHub", v=1, at=time.strftime("%Y-%m-%dT%H:%M:%S"))
        with open(tmp, "wb") as f:
            f.write(json.dumps(data, ensure_ascii=False, indent=1).encode("utf-8"))
        os.replace(tmp, p)
    except OSError:
        try:
            os.remove(tmp)
        except OSError:
            pass
        return False
    t = min(mtime, time.time()) if mtime and mtime > 0 else OLD    # неизвестно — ставим давнее время: так маркер точно не станет «самым свежим» файлом
    for target, times in ((p, (t, t)), (folder, (st.st_atime, st.st_mtime))):
        try:
            os.utime(target, times)
        except OSError:
            pass
    return True


def remove_marker(folder: str) -> bool:
    """Убрать наш маркер (чужие файлы с таким именем не трогаем)."""
    if not read_marker(folder):
        return False
    try:
        os.remove(os.path.join(folder, MARKER))
        return True
    except OSError:
        return False


def _cyr(s: str) -> bool:
    return any("а" <= ch <= "я" or ch == "ё" for ch in s.casefold())


def explain(title: str, games: list[dict], floor: float = 0.9, low: float = 0.55) -> dict:
    """Почему карточка не нашла папку: короткие причины по-русски (раздел 3 PLAN.md) и ближайшая папка.
    games — список из gs.list_games. Ничего не меняет и не читает с диска."""
    import gameupdate
    if not games:
        return {"best": None, "lines": ["В каталоге игр нет ни одной папки или архива. Если игры лежат на другом диске, "
                                       "проверьте, что диск подключён и путь в «Настройках» указан верно."]}
    tk = gs.parse_name(title)["key"] or "".join(ch for ch in title.casefold() if ch.isalnum())
    near = gameupdate.candidates(title, games, limit=1, floor=0.0)
    if not near:
        return {"best": None, "lines": ["Названия папок в каталоге не удалось разобрать: в них нет букв или цифр."]}
    b = near[0]
    pct = round(b["score"] * 100)
    bk = gs.parse_name(b["name"])["key"]
    lines = []
    if b["score"] >= floor and b["type"] == "archive":
        lines.append(f"Нашёл только архив «{b['name']}»: распакуйте его в папку, тогда игра будет считаться скачанной.")
    elif b["score"] >= floor:
        lines.append(f"Папка «{b['name']}» подходит ({pct} %), связь запишется при ближайшем сканировании.")
    elif b["score"] >= low:
        lines.append(f"Ближайшая папка «{b['name']}» совпала на {pct} %. Для автоматической привязки нужно {round(floor * 100)} %: "
                     f"так разные игры («2» и без номера) не склеиваются. Если это она, нажмите «Это она». "
                     f"Сравнивалось: «{tk}» и «{bk}».")
    else:
        lines.append(f"Ни одна папка не похожа на «{title}»: ближайшая «{b['name']}» ({pct} %). "
                     f"Игра лежит вне указанного каталога, ещё не скачана или называется иначе: привяжите папку вручную.")
    if b["score"] < floor and _cyr(tk) != _cyr(bk) and tk and bk:
        lines.append("Название карточки и папки записаны разными алфавитами (кириллица и латиница): по звучанию я их не сопоставляю.")
    return {"best": b, "lines": lines}
