"""Общее для разборщиков сайтов (engine_*.py): сборщик HTML по правилам, ошибка с понятной причиной, проверка заглушки, декодирование страниц."""
import re
from html.parser import HTMLParser

VOID = {"img", "br", "meta", "link", "input", "hr", "source"}


class EngineError(Exception):
    """Понятная человеку причина, по которой страницу не удалось разобрать."""


def _cls(attrs) -> set:
    return set((dict(attrs).get("class") or "").split())


class _Collector(HTMLParser):
    """Собирает текст и атрибуты элементов по правилам: name -> (тег, класс). Вложенные одноимённые теги считаются."""

    def __init__(self, rules: dict):
        super().__init__(convert_charrefs=True)
        self.rules, self.found, self.active, self.imgs, self.metas = rules, {k: [] for k in rules}, [], [], []

    def handle_starttag(self, tag, attrs):
        a = dict(attrs)
        if tag == "meta" and a.get("property"):
            self.metas.append((a["property"], a.get("content") or ""))
        for act in self.active:
            if act["tag"] == tag and tag not in VOID:
                act["depth"] += 1
        if tag == "img":
            for act in self.active:
                act["imgs"].append(a)
            self.imgs.append(a)
        if tag == "br":
            for act in self.active:
                act["text"].append("\n")
        for name, (rtag, rcls) in self.rules.items():
            if tag == rtag and (rcls is None or rcls in _cls(attrs)) and tag not in VOID:
                self.active.append({"name": name, "tag": tag, "depth": 1, "attrs": a, "text": [], "imgs": [], "kids": {}})

    def handle_endtag(self, tag):
        for act in list(self.active):
            if act["tag"] == tag:
                act["depth"] -= 1
                if act["depth"] == 0:
                    self.active.remove(act)
                    text = re.sub(r"[ \t\r\f\v]+", " ", "".join(act["text"])).strip()
                    for outer in self.active:   # вложенный элемент сообщает о себе тому, внутри которого лежит
                        outer["kids"].setdefault(act["name"], []).append(text)
                    self.found[act["name"]].append({"attrs": act["attrs"], "imgs": act["imgs"], "text": text, "kids": act["kids"]})

    def handle_data(self, data):
        for act in self.active:
            act["text"].append(data)


def _meta(c: _Collector, prop: str) -> str:
    return next((v for k, v in c.metas if k == prop and v), "")


def looks_blocked(html: str) -> bool:
    """Страница-заглушка проверки браузера или пустой ответ вместо настоящей страницы сайта."""
    return not html or bool(re.search(r"Just a moment|cf-chl|challenge-platform|DDoS-Guard", html[:20000])) or "og:title" not in html


def decode_html(raw: bytes, header_charset: str = "") -> str:
    """Байты страницы -> текст. Кодировка из заголовка ответа главнее разметки (старые сайты отдают windows-1251 с <meta charset=utf-8>);
    без заголовка пробуем UTF-8 и, если не вышло, windows-1251."""
    if header_charset:
        try:
            return raw.decode(header_charset, "replace")
        except LookupError:
            pass
    try:
        return raw.decode("utf-8")
    except UnicodeDecodeError:
        return raw.decode("cp1251", "replace")
