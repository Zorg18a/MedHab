"""Замена старых версий игр новыми прямо в каталоге игр (папка update не нужна): скачали новую версию в любую
подпапку → программа видит, что у игры несколько версий → сохранения и русский перевод переносятся в новую,
старые уходят в Корзину после подтверждения. Удалённое восстановимо (Корзина Windows или _GameSweep_Trash)."""
import difflib
import os
import shutil
import zipfile

import gamesweep as gs

LANG = {"russian", "ru", "rus"}
ARCH_UNPACK = (".zip",)          # распаковываем сами только ZIP; RAR и 7z нужно распаковать вручную


def inside(path: str, base: str) -> bool:
    try:
        a, b = os.path.abspath(path), os.path.abspath(base)
        return a != b and os.path.commonpath([a, b]) == b
    except ValueError:
        return False


def find_translation(path: str) -> list[str]:
    """Папки перевода внутри игры: Ren'Py (game/tl/russian) и XUnity (BepInEx/Translation/ru). Пути относительные."""
    top, out = gs.game_root(path), []
    for cur, dirs, _files in os.walk(top):
        rel = os.path.relpath(cur, top)
        if rel != "." and len(rel.split(os.sep)) > 6:
            dirs[:] = []
            continue
        base, parent = os.path.basename(cur).lower(), os.path.basename(os.path.dirname(cur)).lower()
        if base in LANG and (parent == "tl" or (parent == "translation" and "bepinex" in rel.lower())):
            out.append(rel)
            dirs[:] = []
    return out


def save_files(path: str) -> list[str]:
    """Файлы сохранений (без дублей «папка + файл внутри»), пути относительно корня игры."""
    top, rels = gs.game_root(path), gs.find_saves(path, limit=100000)
    dirs = [r for r in rels if r.endswith(os.sep)]
    out = []
    for r in (r for r in rels if r.endswith(os.sep) or not any(r.startswith(d) for d in dirs)):
        if r.endswith(os.sep):
            for cur, _d, fs in os.walk(os.path.join(top, r)):
                out += [os.path.relpath(os.path.join(cur, f), top) for f in fs]
        else:
            out.append(r)
    return out


def _has_files(path: str) -> bool:
    return os.path.isdir(path) and any(f for _c, _d, fs in os.walk(path) for f in fs)


def copy_translation(old: str, new: str) -> tuple[int, list[str]]:
    """Перевод старой версии → новая, если в новой его нет; существующие файлы не перезаписываем."""
    o_root, n_root, copied, errs = gs.game_root(old), gs.game_root(new), 0, []
    for rel in find_translation(old):
        src, dst = os.path.join(o_root, rel), os.path.join(n_root, rel)
        if _has_files(dst):
            continue
        for cur, _d, files in os.walk(src):
            for f in files:
                sf = os.path.join(cur, f)
                df = os.path.join(n_root, os.path.relpath(sf, o_root))
                if os.path.exists(df):
                    continue
                try:
                    os.makedirs(os.path.dirname(df), exist_ok=True)
                    shutil.copy2(sf, df)
                    copied += 1
                except OSError as e:
                    errs.append(f"{f}: {e}")
    return copied, errs


def extract_zip(zpath: str, dest: str) -> None:
    base = os.path.abspath(dest)
    with zipfile.ZipFile(zpath) as z:
        for m in z.infolist():
            t = os.path.abspath(os.path.join(base, m.filename))
            if t != base and not t.startswith(base + os.sep):
                raise ValueError("в архиве есть недопустимый путь")
        os.makedirs(base, exist_ok=True)
        z.extractall(base)


def plan(group: dict) -> dict:
    """Что будет сделано для одной группы версий из GameSweep (ничего не меняет на диске)."""
    ms = group["members"]
    keeper = next((m for m in ms if m["status"] == "оставить"), None)
    olds = [m for m in ms if m["status"] in ("старая", "дубль")]
    out = {"key": group["key"], "title": group["title"], "sure": bool(group.get("sure")), "notes": list(group.get("notes") or []),
           "keeper": None, "olds": [], "can": False, "why": "", "tl_in_keeper": False}
    if not keeper or not olds:
        out["why"] = "у игры нет старых версий"
        return out
    ext = os.path.splitext(keeper["path"])[1].lower()
    out["keeper"] = {"path": keeper["path"], "name": keeper["name"], "type": keeper["type"], "version": keeper["version"]}
    for o in sorted(olds, key=lambda m: m["mtime"], reverse=True):
        row = {"path": o["path"], "name": o["name"], "type": o["type"], "version": o["version"], "status": o["status"], "size": o["size"], "saves": 0, "tl": []}
        if o["type"] == "folder" and os.path.isdir(o["path"]):
            row["saves"], row["tl"] = len(save_files(o["path"])), find_translation(o["path"])
        out["olds"].append(row)
    if keeper["type"] == "folder" and os.path.isdir(keeper["path"]):
        k_root = gs.game_root(keeper["path"])
        out["tl_in_keeper"] = any(_has_files(os.path.join(k_root, t)) for o in out["olds"] for t in o["tl"])
    if keeper["type"] != "folder" and ext not in ARCH_UNPACK:
        out["why"] = f"Новая версия в архиве {ext[1:].upper()}: распакуйте её, сам я распаковываю только ZIP"
    elif not out["sure"]:
        out["why"] = "порядок версий определён не уверенно: проверьте в «Версии и чистка»"
        out["can"] = True
    else:
        out["can"] = True
    return out


def replace(keeper_path: str, old_paths: list[str], root: str, delete_old: bool = True) -> dict:
    """Одна замена: (ZIP → папка) → сохранения и перевод старых → новая → старые (и ZIP) в Корзину."""
    res = {"ok": False, "dest": keeper_path, "saves": 0, "tl": 0, "trashed": 0, "msg": ""}
    if not inside(keeper_path, root) or not os.path.exists(keeper_path):
        res["msg"] = "новая версия не найдена в папке игр"
        return res
    olds = [o for o in old_paths if inside(o, root) and os.path.exists(o) and os.path.abspath(o) != os.path.abspath(keeper_path)]
    if not olds:
        res["msg"] = "старых версий на диске уже нет"
        return res
    zip_made = ""
    if os.path.isfile(keeper_path):                                        # новая версия — ZIP: ставим рядом папкой
        if not keeper_path.lower().endswith(ARCH_UNPACK):
            res["msg"] = "этот тип архива нужно распаковать вручную"
            return res
        dest = os.path.join(os.path.dirname(keeper_path), os.path.splitext(os.path.basename(keeper_path))[0])
        if not os.path.isdir(dest):
            try:
                extract_zip(keeper_path, dest)
            except Exception as e:
                shutil.rmtree(dest, ignore_errors=True)
                res["msg"] = f"не удалось распаковать новую версию: {str(e)[:120]}"
                return res
        zip_made, res["dest"] = keeper_path, dest
    problems = []
    for o in olds:                                                         # от новых к старым: у более новой приоритет
        if os.path.isdir(o):
            n, errs = gs.copy_saves({"type": "folder", "path": o}, {"type": "folder", "path": res["dest"]})
            res["saves"] += n
            problems += errs
            n, errs = copy_translation(o, res["dest"])
            res["tl"] += n
            problems += errs
    if problems:
        res["msg"] = "старые версии оставлены: не всё перенеслось (" + problems[0] + ")"
        res["ok"] = True
        return res
    if delete_old:
        bad = []
        for o in olds:
            ok, msg = gs.to_trash(o, root)
            res["trashed"] += 1 if ok else 0
            if not ok:
                bad.append(msg)
        if zip_made and not bad:
            gs.to_trash(zip_made, root)
        if bad:
            res["msg"] = "новая версия готова, но не всё старое удалилось: " + bad[0]
    res["ok"] = True
    return res


def candidates(title: str, games: list[dict], limit: int = 6, floor: float = 0.55) -> list[dict]:
    """Папки и архивы каталога, похожие на название карточки: для «Проверить, скачана ли игра». games — из gs.list_games."""
    tk = gs.parse_name(title)["key"] or "".join(ch for ch in title.casefold() if ch.isalnum())
    out = []
    for g in games:
        pn = gs.parse_name(g["name"])
        k = pn["key"]
        if not k or not tk:
            continue
        r = 1.0 if k == tk else difflib.SequenceMatcher(None, k, tk).ratio()
        if min(len(k), len(tk)) >= 6 and (k.startswith(tk) or tk.startswith(k)):
            r = max(r, 0.9)                                        # «Hidden Badge» и «Hidden Badge Chapter 1»
        if r >= floor:
            out.append({"name": g["name"], "path": g["path"], "type": g["type"], "version": pn["text"], "score": round(r, 2)})
    out.sort(key=lambda c: (-c["score"], c["name"].casefold()))
    return out[:limit]
