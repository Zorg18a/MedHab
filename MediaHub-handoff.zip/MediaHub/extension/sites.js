// Сгенерировано tools/gen_sites.py из sites.json. Не правьте вручную.
globalThis.MH_SITES = [
 {
  "id": "senkuro",
  "kind": "manga",
  "hosts": [
   "senkuro.me",
   "ne.senkognito.com"
  ],
  "path": "^/manga/([a-z0-9-]+)"
 },
 {
  "id": "nudemoon",
  "kind": "manga",
  "hosts": [
   "nude-moon.skin"
  ],
  "suffixes": [
   ".nude-moon.skin"
  ],
  "path": "^/(view/\\d+|\\d+)-"
 },
 {
  "id": "mangabuff",
  "kind": "manga",
  "hosts": [
   "mangabuff.ru"
  ],
  "path": "^/manga/([a-z0-9_-]+)"
 },
 {
  "id": "video-sites",
  "kind": "video",
  "hosts": [
   "vimeo.com",
   "rutube.ru",
   "dailymotion.com",
   "twitch.tv",
   "bilibili.com",
   "ok.ru",
   "vkvideo.ru",
   "tiktok.com"
  ]
 },
 {
  "id": "audio-sites",
  "kind": "audio",
  "hosts": [
   "soundcloud.com",
   "bandcamp.com"
  ],
  "suffixes": [
   ".bandcamp.com"
  ]
 },
 {
  "id": "f95zone",
  "kind": "game",
  "hosts": [
   "f95zone.to"
  ],
  "path": "^/threads/"
 },
 {
  "id": "pornolab",
  "kind": "game",
  "hosts": [
   "pornolab.net"
  ],
  "path": "^/forum/viewtopic\\.php"
 },
 {
  "id": "byrutor",
  "kind": "game",
  "hosts": [
   "byrutgame.org"
  ],
  "path": "^/\\d+-[a-z0-9-]+\\.html"
 },
 {
  "id": "game-stores",
  "kind": "game",
  "hosts": [
   "store.steampowered.com",
   "steamcommunity.com",
   "gog.com",
   "itch.io",
   "store.epicgames.com"
  ],
  "suffixes": [
   ".itch.io"
  ]
 }
];
