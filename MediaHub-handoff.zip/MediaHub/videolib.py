"""Видео и аудио: настройки качества и формата по сайтам, запоминание плейлиста. Чистые функции, сеть и БД не нужны."""
import json
import re
from urllib.parse import urlsplit

RES = ("best", "2160", "1440", "1080", "720", "480", "360")
VFMT = ("mp4", "mkv", "webm")
AFMT = ("mp3", "m4a", "opus", "flac")
MAX_SITES = 50
ALIAS = {"youtu.be": "youtube.com", "music.youtube.com": "youtube.com", "m.youtube.com": "youtube.com"}


def site_key(url_or_host: str) -> str:
    """Ключ сайта для настроек: хост в нижнем регистре без `www.`/`m.`; youtu.be и music.youtube.com = youtube.com. Пусто, если хоста нет."""
    s = str(url_or_host or "").strip().lower()
    if "://" in s:
        try:
            s = urlsplit(s).hostname or ""
        except ValueError:
            return ""
    s = s.split("/")[0].split(":")[0].strip(".")
    s = re.sub(r"^(www|m)\.", "", s)
    s = ALIAS.get(s, s)
    return s if re.fullmatch(r"[a-z0-9]([a-z0-9.-]*[a-z0-9])?\.[a-z0-9-]{2,}", s) else ""


def clean_profiles(raw) -> dict:
    """Проверенный словарь {сайт: {res, vfmt, afmt}}; всё лишнее и неверное отбрасывается, пустые поля = «как в общих настройках»."""
    out = {}
    if not isinstance(raw, dict):
        return out
    for host, p in raw.items():
        k = site_key(host)
        if not k or not isinstance(p, dict) or len(out) >= MAX_SITES:
            continue
        e = {}
        if str(p.get("res")) in RES:
            e["res"] = str(p["res"])
        if p.get("vfmt") in VFMT:
            e["vfmt"] = p["vfmt"]
        if p.get("afmt") in AFMT:
            e["afmt"] = p["afmt"]
        if e:
            out[k] = e
    return out


def job_options(url: str, cfg: dict, explicit: dict | None = None) -> dict:
    """Качество и форматы для задания: явный выбор в окне «Добавить» > настройка сайта > общие настройки."""
    explicit = explicit or {}
    site = clean_profiles({site_key(url): (cfg.get("site_media") or {}).get(site_key(url), {})}).get(site_key(url), {})
    pick = lambda name, allowed, default: next((v for v in (explicit.get(name), site.get(name), cfg.get(name), default) if v and str(v) in allowed), default)
    return {"res": str(pick("res", RES, "best")), "afmt": pick("afmt", AFMT, "mp3"), "vfmt": pick("vfmt", VFMT, "mp4")}


def format_string(kind: str, res: str) -> str:
    if kind == "audio":
        return "bestaudio/best"
    return "bv*+ba/b" if res == "best" else f"bv*[height<={res}]+ba/b[height<={res}]"


def playlist_map(tree: dict) -> tuple:
    """Из плоского разбора плейлиста/канала: (название, {адрес видео: название}). Для одиночного видео название пустое."""
    if not isinstance(tree, dict) or tree.get("_type") != "playlist":
        return "", {}
    title = str(tree.get("title") or "").strip()[:200]
    urls = {}
    for e in tree.get("entries") or []:
        if isinstance(e, dict):
            for u in (e.get("url"), e.get("webpage_url")):
                if u and str(u).startswith("http"):
                    urls[str(u)] = title
    return title, urls


def with_playlist(info_json: str, title: str) -> str:
    """JSON поля info записи с добавленным `playlist` (остальное сохраняется). Пустое название ничего не меняет."""
    try:
        d = json.loads(info_json or "{}")
    except ValueError:
        d = {}
    if not isinstance(d, dict):
        d = {}
    if title:
        d["playlist"] = str(title)[:200]
    return json.dumps(d, ensure_ascii=False)


def playlist_of(info_json: str) -> str:
    try:
        d = json.loads(info_json or "{}")
    except ValueError:
        return ""
    return str(d.get("playlist") or "") if isinstance(d, dict) else ""
