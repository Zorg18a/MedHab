"""Доступ к MediaHub с других устройств в одной сети (Wi-Fi). Выключен по умолчанию.

Как это устроено:
  * Сервер слушает все адреса компьютера только если режим включён в настройках и задан PIN; иначе, как раньше, только 127.0.0.1.
  * С самого компьютера (127.0.0.1) всё работает без PIN и без ограничений. Любой другой адрес сначала вводит PIN и получает сессию (cookie).
  * Гость (устройство с PIN) может смотреть, читать, слушать и сохранять место, где остановился. Загрузки, настройки, удаление, правка,
    «показать в папке», запуск игр, расширение и всё остальное доступны только на компьютере с приложением.
  * Пути на диске гостям не отдаются, игры им не показываются.
  * Подбор PIN ограничен: 5 ошибок с одного адреса и пауза 5 минут.
Важно: в домашней сети соединение идёт по обычному HTTP без шифрования. Это нормально для своего Wi-Fi с паролем, но не для чужих сетей (кафе, отели):
там PIN и содержимое видны другим. Для доступа из интернета используйте VPN (Tailscale, WireGuard), а не открытие порта."""
import hashlib
import hmac
import ipaddress
import re
import secrets
import socket
import threading
import time

SESSION_TTL = 30 * 86400
PIN_MIN = 6
MAX_FAILS, LOCK_SECONDS = 5, 300
COOKIE = "mh_s"

GUEST_GET = [re.compile(x) for x in (
    r"^/$", r"^/(?:js|css)/[\w./-]+\.(?:js|css)$", r"^/api/(?:library|continue)$", r"^/api/play/\d+$", r"^/sub/\d+/\d+\.vtt$",
    r"^/m/\d+$", r"^/p/\d+$", r"^/api/manga/\d+$", r"^/mi/\d+/\d+/\d{3}\.\w+$", r"^/c/\d+$", r"^/[fst]/\d+(?:/.*)?$")]
GUEST_POST = {"/api/progress", "/api/play/pos", "/api/play/forget"}
ITEM_ROUTES = [re.compile(x) for x in (r"^/api/play/(\d+)$", r"^/sub/(\d+)/", r"^/m/(\d+)$", r"^/p/(\d+)$", r"^/api/manga/(\d+)$", r"^/mi/(\d+)/", r"^/c/(\d+)$", r"^/[fst]/(\d+)")]
PRIVATE_KEYS = {"path", "root"}
LAN_NETS = [ipaddress.ip_network(n) for n in ("10.0.0.0/8", "172.16.0.0/12", "192.168.0.0/16", "100.64.0.0/10")]   # домашняя сеть и VPN Tailscale; не документационные и не служебные адреса


def valid_pin(pin: str) -> str:
    """Текст ошибки или пустая строка, если PIN подходит."""
    pin = pin or ""
    if len(pin) < PIN_MIN:
        return f"PIN должен быть не короче {PIN_MIN} символов"
    if len(set(pin)) < 3:
        return "PIN слишком простой: используйте больше разных символов"
    if pin.lower() in {"123456", "1234567", "12345678", "password", "qwerty", "000000", "111111"}:
        return "этот PIN слишком известный"
    return ""


def hash_pin(pin: str, salt: str = "") -> tuple:
    salt = salt or secrets.token_hex(16)
    return salt, hashlib.pbkdf2_hmac("sha256", pin.encode("utf-8"), bytes.fromhex(salt), 200_000).hex()


def check_pin(pin: str, salt: str, digest: str) -> bool:
    if not (pin and salt and digest):
        return False
    return hmac.compare_digest(hash_pin(pin, salt)[1], digest)


class Sessions:
    """Выданные сессии (в памяти: после перезапуска приложения входить заново)."""

    def __init__(self):
        self.d, self.lock = {}, threading.Lock()

    def new(self) -> str:
        t = secrets.token_urlsafe(32)
        with self.lock:
            now = time.time()
            self.d = {k: v for k, v in self.d.items() if v > now}
            self.d[t] = now + SESSION_TTL
        return t

    def ok(self, token: str) -> bool:
        with self.lock:
            exp = self.d.get(token or "")
            return bool(exp and exp > time.time())

    def clear(self) -> int:
        with self.lock:
            n = len(self.d); self.d = {}
        return n

    def count(self) -> int:
        with self.lock:
            return sum(1 for v in self.d.values() if v > time.time())


class Throttle:
    """Не даёт перебирать PIN: после MAX_FAILS ошибок адрес блокируется на LOCK_SECONDS."""

    def __init__(self, clock=time.time):
        self.d, self.lock, self.clock = {}, threading.Lock(), clock

    def wait(self, ip: str) -> int:
        with self.lock:
            n, until = self.d.get(ip, (0, 0))
            return max(0, int(until - self.clock())) if until > self.clock() else 0

    def fail(self, ip: str):
        with self.lock:
            n, until = self.d.get(ip, (0, 0))
            if until and until <= self.clock():
                n = 0
            n += 1
            self.d[ip] = (n, self.clock() + LOCK_SECONDS if n >= MAX_FAILS else 0)

    def ok(self, ip: str):
        with self.lock:
            self.d.pop(ip, None)


def host_allowed(host_header: str, own_name: str = "") -> bool:
    """Заголовок Host гостя: IP-адрес или имя этого компьютера. Чужие имена отклоняем (защита от подмены DNS)."""
    h = (host_header or "").rsplit(":", 1)[0] if not (host_header or "").startswith("[") else ""
    h = h.strip().lower()
    if not h:
        return False
    try:
        ipaddress.IPv4Address(h)
        return True
    except ValueError:
        pass
    own = (own_name or socket.gethostname()).lower()
    return h == own or h in (own + ".local", own + ".lan", own + ".home", own + ".fritz.box")


def same_origin(origin: str, host_header: str) -> bool:
    """У запроса с Origin он должен совпадать с адресом, по которому открыта страница (защита от запросов с чужих сайтов)."""
    if not origin:
        return True
    m = re.match(r"^https?://([^/]+)$", origin)
    return bool(m and m.group(1).lower() == (host_header or "").lower())


def guest_allowed(method: str, path: str) -> bool:
    if method == "POST":
        return path in GUEST_POST
    return any(r.match(path) for r in GUEST_GET)


def item_id_of(path: str):
    for r in ITEM_ROUTES:
        m = r.match(path)
        if m:
            return int(m.group(1))
    return None


def scrub(obj, drop_games: bool = False):
    """Копия ответа без путей на диске; в списках по желанию без игр."""
    if isinstance(obj, dict):
        return {k: scrub(v, drop_games) for k, v in obj.items() if k not in PRIVATE_KEYS}
    if isinstance(obj, list):
        return [scrub(x, drop_games) for x in obj if not (drop_games and isinstance(x, dict) and x.get("kind") == "game")]
    return obj


def local_addresses() -> list:
    """Адреса этого компьютера в локальной сети (для подсказки «откройте на телефоне»)."""
    found = []
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("10.255.255.255", 1)); found.append(s.getsockname()[0]); s.close()      # пакет не отправляется: так узнаётся адрес основного интерфейса
    except OSError:
        pass
    try:
        found += socket.gethostbyname_ex(socket.gethostname())[2]
    except OSError:
        pass
    out = []
    for a in found:
        try:
            ip = ipaddress.IPv4Address(a)
        except ValueError:
            continue
        if any(ip in n for n in LAN_NETS) and a not in out:
            out.append(a)
    return out


LOGIN_PAGE = """<!doctype html><html lang="ru"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>MediaHub: вход</title>
<style>:root{color-scheme:light dark;--bg:#fff;--fg:#1a1a1a;--mu:#555;--ac:#0b57d0;--er:#b3261e}@media(prefers-color-scheme:dark){:root{--bg:#141414;--fg:#eee;--mu:#aaa;--ac:#8ab4f8;--er:#f2b8b5}}
body{margin:0;background:var(--bg);color:var(--fg);font:16px/1.5 system-ui,sans-serif;display:grid;min-height:100vh;place-items:center;padding:16px}
main{width:min(380px,100%)}h1{font-size:1.4rem;margin:0 0 6px}p{color:var(--mu);margin:0 0 16px}label{display:block;font-weight:600;margin-bottom:6px}
input{width:100%;box-sizing:border-box;font:inherit;padding:12px;border:2px solid var(--mu);border-radius:10px;background:transparent;color:inherit}input:focus-visible,button:focus-visible{outline:3px solid var(--ac);outline-offset:2px}
button{margin-top:14px;width:100%;font:inherit;font-weight:600;padding:12px;border:0;border-radius:10px;background:var(--ac);color:var(--bg);cursor:pointer}.err{color:var(--er);font-weight:600;margin:0 0 12px}</style></head>
<body><main><h1>MediaHub</h1><p>Введите PIN, который задан на компьютере с приложением.</p>@@ERR@@
<form method="post" action="/login"><label for="pin">PIN</label><input id="pin" name="pin" type="password" autocomplete="current-password" required autofocus@@DESCR@@><button type="submit">Войти</button></form></main></body></html>"""


def login_page(error: str = "") -> bytes:
    import html
    err = f'<p class="err" role="alert" id="e">{html.escape(error)}</p>' if error else ""
    return LOGIN_PAGE.replace("@@ERR@@", err).replace("@@DESCR@@", ' aria-describedby="e" aria-invalid="true"' if error else "").encode("utf-8")
