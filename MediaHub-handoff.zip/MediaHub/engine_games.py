"""Источники игр помимо F95zone: тема на pornolab.net и страница на Byrutor. Разбор HTML без сети и без app.py.
Результат совместим с карточкой игры (name, version, genres, developer, desc, cover, links, language, thread…) и добавляет сведения о сборке:
  site, site_name  откуда сборка            size, size_bytes  размер раздачи        torrent, magnet  ссылки (на pornolab нужен вход на сайт)
  russian          yes | voice | sub | no | ?  — есть ли русский язык в этой сборке (yes: интерфейс или текст, voice: только озвучка, sub: только субтитры)
  languages        {story, interface, voice, subtitles}, censor, release_type, seeds, updated, latest (самая новая версия, если она отличается от раздачи), alt
У каждого сайта своя версия, размер и язык, поэтому карточка хранит сборки отдельно (info['sources'])."""
import html as _html
import re
from urllib.parse import urljoin, urlparse

from enginekit import _Collector, _meta

PLATFORMS = {"win": "Windows", "mac": "macOS", "linux": "Linux", "android": "Android"}
ENGINES = ("Unity", "Ren'Py", "RPGM", "RPG Maker", "Unreal Engine", "HTML", "Java", "Flash", "Godot", "Wolf RPG", "TyranoBuilder", "Others", "Construct", "GameMaker")
UNITS = {"kb": 1024, "кб": 1024, "mb": 1024 ** 2, "мб": 1024 ** 2, "gb": 1024 ** 3, "гб": 1024 ** 3, "tb": 1024 ** 4, "тб": 1024 ** 4}


def size_bytes(text: str) -> int:
    m = re.search(r"([\d.,]+)\s*([A-Za-zА-Яа-я]+)", (text or "").replace("\xa0", " "))
    if not m:
        return 0
    try:
        return int(float(m.group(1).replace(",", ".")) * UNITS.get(m.group(2).lower(), 0))
    except ValueError:
        return 0


def _t(s: str) -> str:
    return re.sub(r"\s+", " ", _html.unescape(s or "").replace("\xa0", " ")).strip()


def russian_of(interface="", story="", voice="", subtitles="", codes="") -> str:
    ru = lambda s: bool(re.search(r"рус|rus\b|russian", s or "", re.I))
    if ru(interface) or ru(story) or re.search(r"\brus\b", codes or "", re.I):
        return "yes"
    if ru(voice):
        return "voice"
    if ru(subtitles):
        return "sub"
    return "no" if any((interface, story, voice, subtitles, codes)) else "?"


def source_key(engine: str, url: str) -> str:
    """Нормальный адрес источника (без якорей, страниц и лишних параметров): по нему карточка узнаёт свою сборку при повторном чтении."""
    u = urlparse(url)
    if engine == "pornolab":
        m = re.search(r"(?:^|&)t=(\d+)", u.query)
        return f"{u.scheme}://{u.netloc}/forum/viewtopic.php?t={m.group(1)}" if m else url.split("#")[0]
    return f"{u.scheme}://{u.netloc}{u.path}"


# ---------- pornolab ----------
TITLE = re.compile(r"^(?P<names>.+?)\s*\[(?P<ver>[^\]]+)\]\s*\((?P<dev>[^)]*)\)\s*\[(?P<cens>[^\]]*)\]\s*\[(?P<year>\d{4})(?:,\s*(?P<tags>[^\]]*))?\]\s*(?:\[(?P<langs>[^\]]*)\])?")
CENSOR = {"cen": "Есть", "uncen": "Отсутствует", "ptcen": "Частичная"}


def _text_of(fragment: str) -> str:
    s = re.sub(r"<script.*?</script>|<style.*?</style>", "", fragment, flags=re.S)
    s = re.sub(r"<br\s*/?>|</(?:div|p|tr|li)>", "\n", s)
    return _html.unescape(re.sub(r"<[^>]+>", "", s)).replace("\xa0", " ")


def _field(text: str, *labels) -> str:
    for lb in labels:
        m = re.search(r"^[ \t]*" + lb + r"[^:\n]*:[ \t]*(.+)$", text, re.M | re.I)
        if m and m.group(1).strip():
            return m.group(1).strip()
    return ""


def parse_pornolab(html: str, url: str = "") -> dict:
    """Тема раздачи на pornolab.net -> сведения об игре и сборке."""
    m = re.search(r'<a id="topic-title"[^>]*href="[^"]*t=(\d+)"[^>]*>(.*?)</a>', html, re.S)
    raw = _t(re.sub(r"<wbr\s*/?>", "", m.group(2))) if m else _t((re.search(r"<title>(.*?)</title>", html, re.S) or [None, ""])[1]).replace(":: PornoLab.Net", "")
    tid = m.group(1) if m else (re.search(r"dl\.php\?t=(\d+)", html) or [None, ""])[1]
    base = urljoin(url or "https://pornolab.net/forum/", "viewtopic.php") if "viewtopic" not in (url or "") else url
    tm = TITLE.match(raw.strip())
    names = [x.strip() for x in (tm.group("names") if tm else raw).split(" / ")]
    ps = html.find('<div class="post_body"')
    body = _text_of(html[ps:]) if ps >= 0 else ""
    tags = [x.strip() for x in (tm.group("tags") or "").split(",") if x.strip()] if tm else [x.strip() for x in _field(body, "Теги").split(",") if x.strip()]
    os_, eng, genres = "", "", []
    for t in tags:
        if t.lower() in PLATFORMS:
            os_ = os_ or PLATFORMS[t.lower()]
        elif t in ENGINES:
            eng = eng or t
        else:
            genres.append(t)
    codes = tm.group("langs") if tm and tm.group("langs") else ""
    story, interface, voice = _field(body, r"Язык игры"), _field(body, r"Язык интерфейса"), _field(body, r"Озвучка")
    sz = (re.search(r"Размер:(?:&nbsp;|\s)*<b>([^<]*)</b>", html) or [None, ""])[1]
    seeds = (re.search(r'class="seed">[^<]*<b>(\d+)</b>', html) or [None, "0"])[1]
    reg = (re.search(r"Зарегистрирован:(?:&nbsp;|\s)*<b>([^<]*)</b>", html) or [None, ""])[1]
    dm = re.search(r"^[ \t]*Описание[^:\n]*:[ \t]*(.*?)(?=\n\s*(?:[❈╔╚═]|Особенности|Скриншоты|Системные требования)|\Z)", body, re.S | re.M)
    desc = re.sub(r"\n{2,}", "\n", dm.group(1)).strip()[:1500] if dm else ""      # текст может начинаться на следующей строке
    reqs = re.search(r"Системные требования[^:\n]*:\s*(.*?)(?:\n\s*[╚═]|\Z)", body, re.S)
    imgs = re.findall(r'<var class="postImg[^"]*"[^>]*title="([^"]+)"', html[ps:] if ps >= 0 else html)
    cover = next((u for u in imgs if "static.pornolab.net" not in u), "")
    tor = urljoin(base, f"dl.php?t={tid}") if tid else ""
    cens = tm.group("cens") if tm else ""
    version = (tm.group("ver") if tm else "") or _field(body, "Версия")
    lang_text = ", ".join(dict.fromkeys(x for x in (story, interface) if x))        # без повтора, если текст и интерфейс на тех же языках
    return {"site": "pornolab", "site_name": "PornoLab", "name": names[-1] if names else "", "name_orig": names[0] if len(names) > 1 else "",
            "version": version.strip(), "developer": (tm.group("dev") if tm else "") or _field(body, "Разработчик"), "genres": genres, "engine": eng,
            "os": os_ or _field(body, "Платформа"), "status": "", "release": _field(body, "Дата релиза") or (tm.group("year") if tm else ""), "desc": desc, "cover": cover,
            "language": lang_text, "languages": {"story": story, "interface": interface, "voice": voice, "subtitles": ""},
            "russian": russian_of(interface, story, voice, "", codes), "censor": _field(body, "Цензура") or CENSOR.get(cens, cens), "release_type": "Раздача на трекере",
            "size": _t(sz), "size_bytes": size_bytes(_t(sz)), "seeds": int(seeds), "registered": _t(reg), "torrent": tor, "magnet": "", "needs_login": True,
            "requirements": _t(reqs.group(1)) if reqs else "", "updated": "", "latest": "", "alt": [], "support": [],
            "links": [{"label": "Скачать .torrent (нужен вход на сайт)" + (f", {_t(sz)}" if sz else ""), "host": "pornolab.net", "url": tor, "group": "PornoLab"}] if tor else [],
            "thread": source_key("pornolab", url or base) if tid else (url or "")}


# ---------- Byrutor ----------
def _ver(s: str) -> str:
    return re.sub(r"^v\s*", "", re.sub(r"\s*\[[^\]]*\]\s*", " ", _t(s))).strip()


def parse_byrutor(html: str, url: str = "") -> dict:
    """Страница игры на Byrutor -> сведения об игре и сборке. «Версия» это версия самой раздачи, «latest» самая новая версия на странице."""
    c = _Collector({"h1": ("h1", None), "latest": ("div", "subhnamever"), "status": ("span", "subver"), "li": ("li", None), "a": ("a", None),
                    "info": ("div", "info-basictor__info"), "lbl": ("span", "info-basictor__label"), "val": ("strong", "info-basictor__value"),
                    "tech": ("div", "tech_details-item"), "row": ("div", "tech_details-row"), "tl": ("span", "tech_details-label"), "tv": ("span", "tech_details-value"),
                    "dsize": ("span", "itemdown_size"), "alt": ("button", "list_item"), "at": ("span", "showtitle"), "av": ("span", "show_ver"), "as": ("span", "dist_size"),
                    "tags": ("div", "apptag"), "steam": ("span", "gr_rate"), "upd": ("div", "tquote"), "time": ("time", None)})
    c.feed(html)
    canon = re.search(r'<link rel="canonical" href="([^"]+)"', html)
    page = canon.group(1) if canon else (_meta(c, "og:url") or url)
    li = {t["text"].split(":", 1)[0].strip(): t for t in c.found["li"] if ":" in t["text"]}
    info = {}
    for i in c.found["info"]:
        lb, vl = (i["kids"].get("lbl") or [""])[0], (i["kids"].get("val") or [""])[0]
        if lb:
            info[lb] = vl
    tech = {}
    for t in c.found["tech"]:
        tech[(t["kids"].get("tl") or [""])[0].rstrip(":")] = (t["kids"].get("tv") or [""])[0]
    reqs = "; ".join(f"{(r['kids'].get('tl') or [''])[0]} {(r['kids'].get('tv') or [''])[0]}" for r in c.found["row"])
    tor = mag = ""
    for a in c.found["a"]:
        cl, href = a["attrs"].get("class", ""), urljoin(page, a["attrs"].get("href", ""))
        if "itemdown_games" in cl and not tor:
            tor = href
        elif "itemdown_magnet" in cl and not mag:
            mag = href
    size = (c.found["dsize"][0]["text"] if c.found["dsize"] else "")
    genres = li["Жанр"]["kids"].get("a", []) if "Жанр" in li else []
    tags = c.found["tags"][0]["kids"].get("a", []) if c.found["tags"] else []
    allt = list(dict.fromkeys([*genres, *tags]))
    ver, latest = _ver(info.get("Версия", "")), _ver(c.found["latest"][0]["text"]) if c.found["latest"] else ""
    interface, voice, subs = tech.get("Интерфейс", ""), tech.get("Озвучка", ""), tech.get("Субтитры", "")
    none = lambda s: "" if re.match(r"отсутств|нет", s or "", re.I) else s
    alt = [{"label": (a["kids"].get("at") or [""])[0], "version": _ver((a["kids"].get("av") or [""])[0]), "size": (a["kids"].get("as") or [""])[0]} for a in c.found["alt"]]
    dev = li.get("Разработчик", {}).get("text", "").split(":", 1)[-1].strip()
    title = (c.found["h1"][0]["text"] if c.found["h1"] else "") or re.sub(r"^Скачать\s+|\s*\(.*$", "", _meta(c, "og:title"))
    return {"site": "byrutor", "site_name": "Byrutor", "name": title, "name_orig": "", "version": ver or latest, "latest": latest if latest and latest != ver else "",
            "developer": dev, "genres": allt, "engine": "", "os": "Windows", "status": c.found["status"][0]["text"] if c.found["status"] else "",
            "release": li.get("Дата выхода", {}).get("text", "").split(":", 1)[-1].strip(), "desc": _meta(c, "og:description"), "cover": urljoin(page, _meta(c, "og:image")) if _meta(c, "og:image") else "",
            "language": ", ".join(f"{k}: {v}" for k, v in (("Интерфейс", interface), ("Озвучка", voice), ("Субтитры", subs)) if v),
            "languages": {"story": "", "interface": interface, "voice": voice, "subtitles": subs}, "russian": russian_of(none(interface), "", none(voice), none(subs)),
            "censor": "", "release_type": info.get("Тип релиза", ""), "size": size, "size_bytes": size_bytes(size), "seeds": 0, "registered": "", "torrent": tor, "magnet": mag,
            "needs_login": False, "requirements": reqs, "updated": (c.found["upd"][0]["kids"].get("time", [""])[0] if c.found["upd"] and c.found["upd"][0]["kids"].get("time") else ""),
            "steam_reviews": c.found["steam"][0]["text"] if c.found["steam"] else "", "alt": [dict(t) for t in dict.fromkeys(tuple(a.items()) for a in alt)], "support": [],
            "links": [x for x in ({"label": "Скачать .torrent" + (f", {size}" if size else ""), "host": urlparse(page).hostname or "", "url": tor, "group": "Byrutor"},
                                  {"label": "Magnet-ссылка", "host": urlparse(page).hostname or "", "url": mag, "group": "Byrutor"}) if x["url"]],
            "thread": source_key("byrutor", page)}
