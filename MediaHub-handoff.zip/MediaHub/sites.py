"""Единый список сайтов (sites.json): тип страницы по адресу, ссылка на тайтл манги, разрешённые хосты картинок.
Расширение получает те же данные через tools/gen_sites.py (extension/sites.js, host_permissions в manifest.json)."""
import json
import re
from pathlib import Path
from urllib.parse import urlparse

FILE = Path(__file__).with_name("sites.json")
KINDS = ("manga", "video", "audio", "game")
ENGINES = {"manga": ("senkuro", "mangabuff", "nudemoon"), "game": ("f95", "pornolab", "byrutor")}
KNOWN = {"id", "kind", "hosts", "suffixes", "path", "img_domains", "permission", "engine", "name", "slug_prefix"}


def validate(sites: list) -> list:
    seen = set()
    for s in sites:
        if not isinstance(s, dict) or set(s) - KNOWN:
            raise ValueError(f"профиль сайта: неизвестные поля {sorted(set(s) - KNOWN) if isinstance(s, dict) else s!r}")
        if not s.get("id") or s["id"] in seen:
            raise ValueError(f"профиль сайта: пустой или повторный id {s.get('id')!r}")
        seen.add(s["id"])
        if s.get("kind") not in KINDS:
            raise ValueError(f"{s['id']}: kind должен быть один из {KINDS}")
        if not s.get("hosts") or any(h != h.strip().lower() or "/" in h or h.startswith("www.") for h in s["hosts"]):
            raise ValueError(f"{s['id']}: hosts — домены строчными буквами без www и без путей")
        if any(not x.startswith(".") for x in s.get("suffixes", [])):
            raise ValueError(f"{s['id']}: suffixes начинаются с точки")
        if s.get("path"):
            try:
                n = re.compile(s["path"]).groups
            except re.error as e:
                raise ValueError(f"{s['id']}: path не регулярное выражение: {e}")
            if not s["path"].startswith("^"):
                raise ValueError(f"{s['id']}: path должен начинаться с ^")
            if s["kind"] == "manga" and n != 1:
                raise ValueError(f"{s['id']}: у манги в path ровно одна группа (slug)")
        elif s["kind"] == "manga":
            raise ValueError(f"{s['id']}: у манги нужен path")
        if s.get("engine") and s["engine"] not in ENGINES.get(s["kind"], ()):
            raise ValueError(f"{s['id']}: engine только у манги и игр, допустимо: {ENGINES.get(s['kind'], ())}")
    return sites


def load(path=FILE) -> list:
    return validate(json.loads(Path(path).read_text("utf-8"))["sites"])


def host_of(url_or_host: str) -> str:
    h = (urlparse(url_or_host).hostname if "/" in url_or_host else url_or_host) or ""
    h = h.lower()
    return h[4:] if h.startswith("www.") else h


def match(sites: list, host: str, path: str, kinds=None) -> dict | None:
    """Первый профиль, подходящий по хосту и пути."""
    for s in sites:
        if kinds and s["kind"] not in kinds:
            continue
        if host in s["hosts"] or any(host.endswith(x) for x in s.get("suffixes", [])):
            if not s.get("path") or re.search(s["path"], path):
                return s
    return None


def with_extra_manga(sites: list, hosts) -> list:
    """Добавить хосты из настроек окружения (MEDIAHUB_SITE, MEDIAHUB_MANGA_HOSTS) как зеркала манги.
    Запись «хост» — зеркало первого профиля (senkuro), «хост=mangabuff» — зеркало профиля с таким id или engine."""
    known = {h for s in sites if s["kind"] == "manga" for h in s["hosts"]}
    out = list(sites)
    for raw in dict.fromkeys(x.strip().lower() for x in hosts if x and x.strip()):
        h, _, want = raw.partition("=")
        h = h.strip()
        base = next((s for s in sites if s["kind"] == "manga" and want in ("", s["id"], s.get("engine", "senkuro"))), None)
        if not h or h in known or not base:
            continue
        known.add(h)
        out.append({"id": f"env-{h}", "kind": "manga", "engine": base.get("engine", "senkuro"), "name": base.get("name", base["id"]), "hosts": [h],
                    "path": base["path"], "img_domains": base.get("img_domains", []), **({"slug_prefix": base["slug_prefix"]} if base.get("slug_prefix") else {})})
    return out


def manga_hosts(sites: list) -> tuple:
    return tuple(dict.fromkeys(h for s in sites if s["kind"] == "manga" for h in s["hosts"]))


def manga_title(sites: list, url) -> tuple | None:
    """Ссылка на тайтл → (адрес сайта, slug) или None."""
    u = urlparse(str(url or "").strip())
    if u.scheme not in ("http", "https"):
        return None
    h = host_of(u.hostname or "")
    s = match(sites, h, u.path, ("manga",))
    m = re.search(s["path"], u.path) if s else None
    return ("https://" + h, s.get("slug_prefix", "") + m.group(1).replace("/", "-")) if m else None


def manga_profile(sites: list, url) -> dict | None:
    """Профиль сайта манги, которому принадлежит ссылка (по нему выбирается способ загрузки)."""
    u = urlparse(str(url or "").strip())
    return match(sites, host_of(u.hostname or ""), u.path, ("manga",)) if u.scheme in ("http", "https") else None


def title_url(sites: list, url) -> str | None:
    """Адрес, по которому качается тайтл: «сайт/manga/slug», а у сайтов, где адрес не собрать из номера (nude-moon), исходная ссылка."""
    mt = manga_title(sites, url)
    if not mt:
        return None
    return str(url).strip().split("#")[0] if engine_of(manga_profile(sites, url)) == "nudemoon" else f"{mt[0]}/manga/{mt[1]}"


def engine_of(profile: dict | None) -> str:
    """Способ загрузки/разбора сайта; без поля engine у манги это senkuro, у игр f95."""
    p = profile or {}
    return p.get("engine") or ("f95" if p.get("kind") == "game" else "senkuro")


def manga_img_host_ok(sites: list, host: str) -> bool:
    """Откуда можно брать картинки манги: сам сайт, его родительский домен и CDN из img_domains."""
    h = (host or "").lower()
    for s in sites:
        if s["kind"] != "manga":
            continue
        doms = set(s.get("img_domains", [])) | {".".join(x.split(".")[-2:]) for x in s["hosts"]}
        if h in s["hosts"] or any(h == d or h.endswith("." + d) for d in doms):
            return True
    return False


def render_js(sites: list) -> str:
    return ("// Сгенерировано tools/gen_sites.py из sites.json. Не правьте вручную.\n"
            "globalThis.MH_SITES = " + json.dumps([{k: s[k] for k in ("id", "kind", "hosts", "suffixes", "path") if k in s} for s in sites],
                                                    ensure_ascii=False, indent=1) + ";\n")


def render_manifest(manifest: dict, sites: list, app: str = "http://127.0.0.1:8765/*") -> dict:
    out = dict(manifest)
    perms = [app]
    for s in sites:
        if s.get("permission"):
            perms += [f"https://{h}/*" for h in s["hosts"]] + [f"https://*{x}/*" for x in s.get("suffixes", [])]
    out["host_permissions"] = list(dict.fromkeys(perms))
    return out
