// Режимы вписывания и масштаб читалки: чистые функции и хранение выбора (localStorage['mh.reader']).
export const FITS = ['width', 'height', 'orig'];
const KEY = 'mh.reader', DEFAULTS = { fit: 'width', zoom: 100 };

// Диапазон 50-200 %, шаг 10; всё, что не число, даёт 100.
export function clampZoom(z) {
  const n = z === null || z === '' || typeof z === 'boolean' ? NaN : Number(z);
  if (!Number.isFinite(n)) return DEFAULTS.zoom;
  return Math.min(200, Math.max(50, Math.round(n / 10) * 10));
}

export function loadReaderPrefs() {
  try {
    const o = JSON.parse(localStorage.getItem(KEY));
    if (!o || typeof o !== 'object' || Array.isArray(o)) return { ...DEFAULTS };
    return { fit: FITS.includes(o.fit) ? o.fit : DEFAULTS.fit, zoom: clampZoom(o.zoom) };
  } catch (e) { return { ...DEFAULTS }; }
}

export function saveReaderPrefs(p) {
  try { localStorage.setItem(KEY, JSON.stringify({ fit: FITS.includes(p.fit) ? p.fit : DEFAULTS.fit, zoom: clampZoom(p.zoom) })); } catch (e) { /* хранилище недоступно: выбор живёт до закрытия страницы */ }
}

// Значения CSS-переменных для страниц: --pg-w, --pg-h, --pg-zoom (CSS zoom применяется только в режиме «Исходный размер»).
export function imageStyle(fit, zoom) {
  const z = clampZoom(zoom) / 100;
  if (fit === 'height') return { '--pg-w': 'auto', '--pg-h': `calc((100vh - var(--hdr, 0px)) * ${z})`, '--pg-zoom': '1' };
  if (fit === 'orig') return { '--pg-w': 'auto', '--pg-h': 'auto', '--pg-zoom': String(z) };
  return { '--pg-w': `${Math.round(z * 100)}%`, '--pg-h': 'auto', '--pg-zoom': '1' };
}

const BY_KEY = { n: 'next', p: 'prev', ArrowRight: 'next', ArrowLeft: 'prev', '+': 'zoom+', '=': 'zoom+', '-': 'zoom-', '0': 'zoom0', w: 'fit:width', h: 'fit:height', o: 'fit:orig', '?': 'help' };
const BY_CODE = { KeyN: 'next', KeyP: 'prev', KeyW: 'fit:width', KeyH: 'fit:height', KeyO: 'fit:orig' };

// Действие по нажатию или null. Стрелки отдаются браузеру, пока в режиме «Исходный размер» есть горизонтальная прокрутка (ctx.hScroll).
// Для не-латинской раскладки (русской) работает физическая клавиша.
export function keyAction(e, ctx = {}) {
  if (e.ctrlKey || e.altKey || e.metaKey) return null;
  const key = e.key || '', k = /^[A-Z]$/.test(key) ? key.toLowerCase() : key;
  const a = Object.hasOwn(BY_KEY, k) ? BY_KEY[k] : /^[a-z]$/i.test(key) ? null : (BY_CODE[e.code] ?? null);
  if (ctx.hScroll && (key === 'ArrowLeft' || key === 'ArrowRight')) return null;
  return a;
}
