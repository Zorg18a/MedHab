// Читалка манги /m/<id>. Логика перенесена из reader.html без изменений; inline-обработчики заменены делегированием по data-action.
import { $, esc } from '../core/dom.js';
import { initRadios } from '../ui/tabs.js';
import { announce } from '../a11y/announce.js';
import { loadPrefs } from '../a11y/prefs.js';
import { isTyping } from '../a11y/keys.js';
import { openDialog, closeDialog } from '../ui/dialog.js';
import { keyAction, clampZoom, loadReaderPrefs, saveReaderPrefs, imageStyle } from './modes.js';

const id=location.pathname.split('/')[2];let M,cur=0,tm;
let {fit,zoom}=loadReaderPrefs(),radios;
// Прокрутка так, чтобы элемент оказался сразу под липкой шапкой (--hdr), а не под ней.
function place(el){const h=parseFloat(getComputedStyle(document.documentElement).getPropertyValue('--hdr'))||0;scrollTo(0,Math.max(0,el.getBoundingClientRect().top+scrollY-h))}
function curPage(){const im=[...$('v').querySelectorAll('img')];const k=im.findIndex(x=>x.getBoundingClientRect().bottom>70);return k<0?0:k}
// Режим и масштаб: переменные на #v, радиокнопки, значение в живой области #zv, сохранение; текущая страница остаётся на месте.
function applyMode(keep){const k=keep?curPage():0;for(const[n,v]of Object.entries(imageStyle(fit,zoom)))$('v').style.setProperty(n,v);
document.querySelectorAll('#fit [role=radio]').forEach(r=>r.setAttribute('aria-checked',String(r.dataset.fit===fit)));radios&&radios.sync();$('zn').textContent=zoom+' %';saveReaderPrefs({fit,zoom});
if(keep){const t=$('v').children[k];if(t)place(t)}}
function setFit(f){if(f===fit)return;fit=f;applyMode(true)}function setZoom(z){z=clampZoom(z);if(z===zoom)return;zoom=z;applyMode(true)}

async function load(){M=await(await fetch('/api/manga/'+id)).json();if(M.error){$('t').textContent='Тайтл не найден';$('v').textContent='Тайтл не найден';$('ch').hidden=true;return}
document.title=M.title;$('t').textContent=M.title+` · скачано глав ${M.have} из ${M.total||M.have}`;
$('c').innerHTML=M.chapters.map((c,i)=>`<option value="${i}">${c.files.length?(c.done?'✓ ':'◐ '):'○ '}${esc(c.label)}</option>`).join('');
let i=M.chapters.findIndex(c=>c.files.length),pg=0;if(M.progress){const k=M.chapters.findIndex(c=>c.id==M.progress.cid);if(k>=0){i=k;pg=M.progress.page}}open_(Math.max(0,i),pg)}
// Прокрутка через scrollTo, не scrollIntoView: он сдвигает точку старта Tab с кнопки «Перейти к содержимому» в середину страницы.
async function open_(i,pg=0){if(!M.chapters[i])return;cur=i;$('c').value=i;const c=M.chapters[i];$('ch').textContent=c.label;
if(!c.files.length){$('v').innerHTML=`<p class="mu">Глава «${esc(c.label)}» ещё не скачана. Запустите загрузку тайтла ещё раз: готовые главы пропускаются, докачаются недостающие.</p><p style="text-align:center"><button type="button" data-action="next">Следующая глава <span aria-hidden="true">▶</span></button></p>`;return}
$('v').innerHTML=c.files.map((f,k)=>`<img data-i="${k}" ${k>pg+1?'loading="lazy"':''} src="/mi/${id}/${c.id}/${f}" alt="Страница ${k+1}">`).join('')+`<p class="mu">${c.done?'Конец главы':`Скачано ${c.files.length} из ${c.expected} стр.`}</p><p style="text-align:center"><button type="button" data-action="next">Следующая глава <span aria-hidden="true">▶</span></button></p>`;
await Promise.all([...$('v').querySelectorAll('img')].slice(0,pg+1).map(x=>x.decode().catch(()=>0)));
const t=pg>0?$('v').children[pg]:$('ch');t?place(t):scrollTo(0,0)}
function save(){const im=[...$('v').querySelectorAll('img')];const k=curPage();$('s').textContent=`стр. ${k+1}/${im.length}`;
if(M.chapters[cur].files.length)fetch('/api/progress',{method:'POST',headers:{'X-MH':'1'},body:JSON.stringify({id:+id,cid:M.chapters[cur].id,page:k})})}
addEventListener('scroll',()=>{clearTimeout(tm);tm=setTimeout(save,700)});
// Смена главы пользователем: озвучивание «Глава N из M»; фокус на заголовок главы переносится, только если нажатый элемент исчезает или это клавиша
// (список и верхние кнопки сохраняют фокус, иначе стрелки в списке перестали бы работать).
async function go(i,focus){if(!M||!M.chapters)return;if(!M.chapters[i]){announce(i<0?'Это первая глава':'Это последняя глава');return}
await open_(i);announce(`Глава ${i+1} из ${M.chapters.length}${M.chapters[i].files.length?'':', не скачана'}`);if(focus)$('ch').focus({preventScroll:true})}
$('c').addEventListener('change',e=>go(+e.target.value,false));$('p').addEventListener('click',()=>go(cur-1,false));$('n').addEventListener('click',()=>go(cur+1,false));
$('v').addEventListener('click',e=>{if(e.target.closest('[data-action="next"]'))go(cur+1,true)});
$('skip').addEventListener('click',()=>$('main').focus());
const FITN={width:'По ширине',height:'По высоте',orig:'Исходный размер'},help=()=>openDialog($('helpDlg'));
$('helpBtn').addEventListener('click',help);$('helpClose').addEventListener('click',()=>closeDialog($('helpDlg')));
function stepZoom(d){const z=clampZoom(zoom+d);if(z===zoom)announce(`Масштаб ${zoom} %, предел`);else setZoom(z)}   // речь о масштабе даёт живая область #zv
document.addEventListener('keydown',e=>{if(e.defaultPrevented||loadPrefs().keys===false)return;
const a=keyAction(e,{hScroll:fit==='orig'&&$('v').scrollWidth>$('v').clientWidth});if(!a||isTyping(document.activeElement)||document.querySelector('dialog[open]'))return;e.preventDefault();
if(a==='next')go(cur+1,true);else if(a==='prev')go(cur-1,true);else if(a==='zoom+')stepZoom(10);else if(a==='zoom-')stepZoom(-10);else if(a==='zoom0')setZoom(100);
else if(a.startsWith('fit:')){setFit(a.slice(4));announce(FITN[fit])}else if(a==='help')help()});
radios=initRadios($('fit'),b=>setFit(b.dataset.fit));
$('fit').addEventListener('click',e=>{const b=e.target.closest('[role=radio]');if(b)setFit(b.dataset.fit)});
$('zout').addEventListener('click',()=>setZoom(zoom-10));$('zin').addEventListener('click',()=>setZoom(zoom+10));
const hd=document.querySelector('header');new ResizeObserver(()=>document.documentElement.style.setProperty('--hdr',(getComputedStyle(hd).position==='sticky'?hd.offsetHeight:0)+'px')).observe(hd);
applyMode(false);
load();
