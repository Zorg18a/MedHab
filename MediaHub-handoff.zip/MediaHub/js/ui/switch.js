import { esc } from '../core/dom.js';

export const switchHtml = (id, label, checked) =>
  `<input type="checkbox" role="switch" class="sw" id="${esc(id)}" aria-label="${esc(label)}"${checked ? ' checked' : ''}>`;
