// Диалоги: фокус возвращается на элемент, открывший диалог, при любом способе закрытия.
export function openDialog(dlg, opener = document.activeElement) {
  if (dlg.open) return;
  dlg.addEventListener('close', () => { if (opener && opener.isConnected && opener.focus) opener.focus(); }, { once: true });
  dlg.showModal();
}

export function closeDialog(dlg) { if (dlg.open) dlg.close(); }
