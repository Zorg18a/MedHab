// Вкладки: roving tabindex, стрелки, Home и End; id вкладки берётся из data-tab или id.
export function initTabs(tablist, onSelect) {
  const tabs = () => [...tablist.querySelectorAll('[role=tab]')];
  const idOf = t => t.dataset.tab || t.id;
  tabs().forEach(t => { if (t.dataset.panel) t.setAttribute('aria-controls', t.dataset.panel); });
  const sync = () => tabs().forEach(t => { t.tabIndex = t.getAttribute('aria-selected') === 'true' ? 0 : -1; });
  const select = (t, focus) => {
    tabs().forEach(x => x.setAttribute('aria-selected', String(x === t)));
    sync(); if (focus) t.focus(); onSelect(idOf(t), t);
  };
  tablist.addEventListener('click', e => { const t = e.target.closest('[role=tab]'); if (t) select(t, false); });
  tablist.addEventListener('keydown', e => {
    const ts = tabs(), i = ts.indexOf(document.activeElement); if (i < 0) return;
    const j = e.key === 'ArrowRight' ? (i + 1) % ts.length : e.key === 'ArrowLeft' ? (i - 1 + ts.length) % ts.length
      : e.key === 'Home' ? 0 : e.key === 'End' ? ts.length - 1 : -1;
    if (j < 0) return; e.preventDefault(); select(ts[j], true);
  });
  sync();
  return { sync, select: id => { const t = tabs().find(x => idOf(x) === id); if (t) select(t, false); } };
}

// Группа переключателей (radiogroup): одна остановка Tab, выбор стрелками.
export function initRadios(group, onSelect) {
  const rs = () => [...group.querySelectorAll('[role=radio]')];
  const sync = () => rs().forEach(r => { r.tabIndex = r.getAttribute('aria-checked') === 'true' ? 0 : -1; });
  group.addEventListener('keydown', e => {
    const r = rs(), i = r.indexOf(document.activeElement); if (i < 0) return;
    const j = e.key === 'ArrowRight' || e.key === 'ArrowDown' ? (i + 1) % r.length : e.key === 'ArrowLeft' || e.key === 'ArrowUp' ? (i - 1 + r.length) % r.length : -1;
    if (j < 0) return; e.preventDefault(); r[j].focus(); onSelect(r[j]);
  });
  sync();
  return { sync };
}
