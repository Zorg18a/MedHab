import { esc } from '../core/dom.js';

// Чип-фильтр: состояние выставляется через aria-pressed, обработчик ищется по data-action.
export function chipHtml(label, { pressed, count, action, value, data = {}, extraClass = '', cls = 'chip' }) {
  const extra = Object.entries(data).map(([k, v]) => ` data-${esc(k)}="${esc(v)}"`).join('');
  const on = !!pressed;
  return `<button type="button" class="${cls}${on ? ' on' : ''}${extraClass ? ' ' + esc(extraClass) : ''}" aria-pressed="${on}" data-action="${esc(action)}"${value !== undefined ? ` data-value="${esc(value)}"` : ''}${extra}>${esc(label)}${count !== undefined ? `<span>${esc(count)}</span>` : ''}</button>`;
}
