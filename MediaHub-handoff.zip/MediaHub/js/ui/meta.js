// Личное: избранное, статус, оценка 0–10, теги, своё описание и своя обложка. Один блок для игр, манги, видео и остального.
import { esc } from '../core/dom.js';
import { api } from '../core/api.js';
import { notify } from '../a11y/announce.js';

const ST = { game: ['Не запускал', 'Прохожу', 'Пройдено'], manga: ['Не читал', 'Читаю', 'Прочитано'], site: ['Не открывал', 'Изучаю', 'Изучено'], link: ['Не открывал', 'Изучаю', 'Изучено'] };
const ST_DEF = ['Не смотрел', 'Смотрю', 'Просмотрено'], CODE = ['new', 'doing', 'done'];
export const statusLabels = kind => ST[kind] || ST_DEF;
export const statusText = x => { const i = CODE.indexOf((x.m || {}).status); return i < 0 ? '' : statusLabels(x.kind)[i]; };
export const metaLabel = x => { const m = x.m || {}; return (m.fav ? ', в избранном' : '') + (m.rating != null ? `, оценка ${m.rating} из 10` : '') + (m.status ? ', ' + statusText(x).toLowerCase() : ''); };
export const badgesHtml = x => {
  const m = x.m || {}; if (!m.fav && m.rating == null && !m.status) return '';
  return `<span class="mb" aria-hidden="true">${m.fav ? '<i class="mf">★</i>' : ''}${m.rating != null ? `<i>${m.rating}/10</i>` : ''}${m.status === 'done' ? '<i class="md">✓</i>' : m.status === 'doing' ? '<i>▶</i>' : ''}</span>`;
};
const favText = v => (v ? '★ В избранном' : '☆ В избранное');

export function metaHtml(x) {
  const m = x.m || {}, L = statusLabels(x.kind);
  return `<div class="mblock"><h4>Мои данные</h4>
<div class="mrow"><button type="button" class="btn" data-m="fav" aria-pressed="${!!m.fav}">${favText(m.fav)}</button>
<label class="field"><span>Оценка</span><select data-m="rating"><option value="">Без оценки</option>${[...Array(11).keys()].map(n => `<option value="${n}"${m.rating === n ? ' selected' : ''}>${n} из 10</option>`).join('')}</select></label>
<label class="field"><span>Статус</span><select data-m="status"><option value="">Не указан</option>${CODE.map((c, i) => `<option value="${c}"${m.status === c ? ' selected' : ''}>${L[i]}</option>`).join('')}</select></label></div>
<label class="field"><span>Теги (через запятую)</span><input data-m="tags" value="${esc((m.tags || []).join(', '))}" autocomplete="off"></label>
<label class="field"><span>Описание</span><textarea data-m="descr" style="min-height:90px" placeholder="Своё описание: заменит описание с сайта">${esc(m.descr || '')}</textarea></label>
<div class="mrow"><button type="button" class="btn" data-m="cover">Выбрать свою обложку…</button>${m.cover ? '<button type="button" class="btn" data-m="uncover">Вернуть обычную обложку</button>' : ''}<input type="file" accept="image/*" data-m="file" hidden aria-label="Файл обложки"></div></div>`;
}

async function shrink(file) {   // до 1400 px по большей стороне: быстрее передача и меньше места на диске
  const bmp = await createImageBitmap(file), k = Math.min(1, 1400 / Math.max(bmp.width, bmp.height)), c = document.createElement('canvas');
  c.width = Math.max(1, Math.round(bmp.width * k)); c.height = Math.max(1, Math.round(bmp.height * k));
  c.getContext('2d').drawImage(bmp, 0, 0, c.width, c.height); return c.toDataURL('image/webp', 0.92);
}

// root: контейнер с metaHtml; get(): текущая запись; changed(x, 'cover'|undefined): перерисовать то, что зависит от данных.
export function bindMeta(root, get, changed) {
  const save = async (patch, msg) => {
    const x = get(); if (!x) return null;
    const r = await api('/api/meta/set', { id: x.id, ...patch });
    if (r.error) { notify(r.error, { kind: 'error' }); return null; }
    x.m = r.meta; changed(x); if (msg) notify(msg); return x;
  };
  root.addEventListener('click', async e => {
    const b = e.target.closest('[data-m]'); if (!b || !root.contains(b)) return; const k = b.dataset.m, x = get(); if (!x) return;
    if (k === 'fav') { const v = b.getAttribute('aria-pressed') !== 'true'; if (await save({ fav: v })) { b.setAttribute('aria-pressed', String(v)); b.textContent = favText(v); notify(v ? 'Добавлено в избранное' : 'Убрано из избранного'); } }
    else if (k === 'cover') root.querySelector('[data-m=file]').click();
    else if (k === 'uncover') { const r = await api('/api/cover/clear', { id: x.id }); x.cover = r.cover; x.m.cover = ''; changed(x, 'cover'); notify('Обычная обложка возвращена'); }
  });
  root.addEventListener('change', async e => {
    const t = e.target, k = t.dataset && t.dataset.m, x = get(); if (!k || !x) return;
    if (k === 'rating') save({ rating: t.value === '' ? null : +t.value }, 'Оценка сохранена');
    else if (k === 'status') save({ status: t.value }, 'Статус сохранён');
    else if (k === 'tags') { const r = await save({ tags: t.value }, 'Теги сохранены'); if (r) t.value = r.m.tags.join(', '); }
    else if (k === 'descr') save({ descr: t.value }, 'Описание сохранено');
    else if (k === 'file' && t.files[0]) {
      try {
        const r = await api('/api/cover/set', { id: x.id, data: await shrink(t.files[0]) });
        if (r.error) { notify(r.error, { kind: 'error' }); return; }
        x.cover = r.cover; x.m.cover = 'custom'; changed(x, 'cover'); notify('Своя обложка сохранена');
      } catch { notify('Не удалось прочитать картинку', { kind: 'error' }); }
      t.value = '';
    }
  });
}
