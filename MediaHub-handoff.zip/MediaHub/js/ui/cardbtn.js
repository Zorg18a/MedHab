import { esc } from '../core/dom.js';

export const cardButtonHtml = ({ id, label, inner, cls = '' }) =>
  `<div${cls ? ` class="${esc(cls)}"` : ''} role="button" tabindex="0" data-card data-id="${esc(id)}" aria-label="${esc(label)}">${inner}</div>`;

// Enter и пробел действуют как щелчок по карточке-кнопке.
export function bindCardKeys(root) {
  root.addEventListener('keydown', e => {
    const c = e.target.closest && e.target.closest('[data-card]');
    if (!c || e.target !== c || (e.key !== 'Enter' && e.key !== ' ')) return;
    e.preventDefault(); c.click();
  });
}
