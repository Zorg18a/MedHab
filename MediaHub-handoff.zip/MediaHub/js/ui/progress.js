import { esc } from '../core/dom.js';

export function progressHtml(pct, label) {
  const v = Math.max(0, Math.min(100, Math.round(+pct || 0)));
  return `<div class="bar" role="progressbar" aria-label="${esc(label)}" aria-valuemin="0" aria-valuemax="100" aria-valuenow="${v}"><i style="width:${v}%"></i></div>`;
}

// Какой рубеж (25, 50, 75, 100) пройден между двумя значениями; null, если никакой.
export function milestone(prev, next, step = 25) {
  if (next >= 100 && prev < 100) return 100;
  const a = Math.floor(prev / step), b = Math.floor(next / step);
  return b > a ? b * step : null;
}
