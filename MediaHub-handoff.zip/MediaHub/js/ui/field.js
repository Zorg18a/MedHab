import { announce } from '../a11y/announce.js';

let seq = 0;
const errId = input => (input.id || (input.id = 'f' + ++seq)) + '-err';

export function clearFieldError(input) {
  const e = document.getElementById(errId(input)); if (e) e.remove();
  input.removeAttribute('aria-invalid');
  const prev = input.dataset.prevDesc;
  if (prev) input.setAttribute('aria-describedby', prev); else input.removeAttribute('aria-describedby');
  delete input.dataset.prevDesc;
}

// Ошибка привязана к полю, фокус переходит на поле, текст озвучивается сразу.
export function fieldError(input, message, anchor = input) {
  clearFieldError(input);
  const p = document.createElement('p');
  p.id = errId(input); p.className = 'field-err'; p.textContent = message;
  anchor.insertAdjacentElement('afterend', p);
  const prev = input.getAttribute('aria-describedby') || '';
  input.dataset.prevDesc = prev;
  input.setAttribute('aria-invalid', 'true');
  input.setAttribute('aria-describedby', prev ? prev + ' ' + p.id : p.id);
  input.focus();
  announce(message, 'assertive');
}
