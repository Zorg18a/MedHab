// Диалог «Добавить»: ссылки, тип материала, предпросмотр размера, выбор страниц сайта.
import { $, qa, esc } from '../core/dom.js';
import { api } from '../core/api.js';
import { B, I, IC } from '../core/fmt.js';
import { notify, announce } from '../a11y/announce.js';
import { initRadios } from '../ui/tabs.js';
import { openDialog, closeDialog } from '../ui/dialog.js';
import { fieldError, clearFieldError } from '../ui/field.js';
import { poll } from './downloads.js';

let AK = 'video', P = [], MX = false, picked = false, radios;
const TYPES = [['video', 'Видео'], ['audio', 'Аудио'], ['manga', 'Манга'], ['site', 'Сайт']];
const HINT = { video: 'Видео, плейлисты и каналы с YouTube и сотен других сайтов.', audio: 'Только звук. Формат выбирается в настройках.', manga: 'Ссылка на тайтл манги. Скачаются все главы.', site: 'Страницы, картинки и видео сохранятся для просмотра без интернета.' };
let MANGA_RE = null;   // адреса сайтов манги приходят с сервера (sites.json): так список не дублируется в интерфейсе
const esc_re = s => s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
function loadSites() {
  api('/api/sites').then(r => {
    if (!r.manga?.length) return;
    MANGA_RE = new RegExp('(?:' + r.manga.map(esc_re).join('|') + ')/manga/');
    HINT.manga = 'Ссылка на тайтл на ' + r.manga.join(' или ') + '. Скачаются все главы.';
    if (AK === 'manga') $('hint').textContent = HINT.manga;
  }).catch(() => {});
}
const URL_MSG = 'Вставьте ссылку, она должна начинаться с http';

function setType(k, user) {
  AK = k; if (user) picked = true;
  qa('#addDlg .seg [role=radio]').forEach(b => b.setAttribute('aria-checked', String(b.dataset.k === k)));
  radios.sync();
  $('hint').textContent = HINT[k];
  qa('#more [data-for]').forEach(d => d.classList.toggle('hide', d.dataset.for !== k));
  $('chk').classList.toggle('hide', k === 'site' || k === 'manga');
}

export function openAdd() {
  if (!MANGA_RE) loadSites();
  $('pv').classList.add('hide'); setType(AK);
  openDialog($('addDlg')); $('urls').focus();
}

const needUrl = () => { if (/https?:\/\//.test($('urls').value)) return false; fieldError($('urls'), URL_MSG); return true; };
const opts = () => ({ urls: $('urls').value, kind: AK === 'manga' ? 'mangaurl' : AK, first: $('mf').value, last: $('ml').value, sel: AK === 'site' ? P.filter((_, i) => $('pg' + i)?.checked).map(p => p.url) : [], start_at: $('when').value ? Date.parse($('when').value) / 1000 : 0, daily: $('daily').checked, ...(MX && AK === 'site' ? { maxp: +$('maxp').value } : {}) });

function pickN(n) {
  n = +n; MX = true; $('maxp').value = Math.min(n, 500); $('maxpv').textContent = n >= 500 && P.length ? P.length : n;
  P.forEach((p, i) => { $('pg' + i).checked = i < n; }); cnt();
}
function cnt() {
  const s = P.filter((_, i) => $('pg' + i)?.checked).length;
  $('fcount').textContent = P.length ? `Найдено ${P.length}, выбрано ${s}` : '';
}

export function initAdd() {
  const seg = $('addDlg').querySelector('.seg');
  seg.innerHTML = TYPES.map(([k, n]) => `<button type="button" role="radio" data-k="${k}" aria-checked="false">${I(IC[k], 22)}${n}</button>`).join('');
  radios = initRadios(seg, b => setType(b.dataset.k, true));
  seg.addEventListener('click', e => { const b = e.target.closest('[role=radio]'); if (b) setType(b.dataset.k, true); });
  $('addBtn').addEventListener('click', openAdd);
  $('addX').addEventListener('click', () => closeDialog($('addDlg')));
  $('addC').addEventListener('click', () => closeDialog($('addDlg')));
  $('urls').addEventListener('input', () => {
    clearFieldError($('urls'));
    P = []; $('plist').classList.add('hide'); $('plist').innerHTML = ''; cnt();
    if (!picked && MANGA_RE?.test($('urls').value)) setType('manga');
  });
  $('txtBtn').addEventListener('click', () => $('txt').click());
  $('txt').addEventListener('change', e => e.target.files[0]?.text().then(t => { $('urls').value += ($('urls').value ? '\n' : '') + t; notify('Ссылки из файла добавлены'); }));
  $('go').addEventListener('click', async () => {
    if (needUrl()) return;
    const r = await api('/api/add', opts());
    if (!r.added) { fieldError($('urls'), 'Ссылки не распознаны: проверьте адреса'); return; }
    closeDialog($('addDlg')); $('urls').value = ''; P = []; picked = false;
    const sch = $('when').value; poll();
    notify(sch ? 'Запланировано: ' + r.added : 'Добавлено: ' + r.added, { action: { label: 'Загрузки', fn: () => { location.hash = '#downloads'; } } });
  });
  $('chk').addEventListener('click', async () => {
    if (needUrl()) return;
    const t = (await api('/api/preview', opts())).t;
    $('pv').classList.remove('hide'); $('pv').textContent = 'Считаю…';
    const iv = setInterval(async () => {
      const p = await api('/api/preview?t=' + t), af = p.free - p.size;
      $('pv').innerHTML = `Проверено ${p.done} из ${p.total}. Займёт ≈ <b>${B(p.size)}</b>${p.unknown ? ` (ещё ${p.unknown} без оценки)` : ''}${p.skipped ? `, уже скачано: ${p.skipped}` : ''}.<br>Свободно ${B(p.free)}, после загрузки останется <b class="${af < 0 ? 'bad' : ''}">${B(af)}</b>${af < 0 ? '. Места не хватит' : ''}${p.err.length ? '<br><span class="mu">' + esc(p.err.join('; ')) + '</span>' : ''}`;
      if (p.finished) { clearInterval(iv); announce($('pv').textContent); }
    }, 900);
  });
  $('maxp').addEventListener('input', e => pickN(e.target.value));
  qa('[data-n]').forEach(b => b.addEventListener('click', () => pickN(b.dataset.n)));
  $('find').addEventListener('click', async () => {
    if (needUrl()) return;
    P = []; $('plist').innerHTML = ''; $('plist').classList.remove('hide'); $('fcount').textContent = 'Ищу страницы…';
    const t = (await api('/api/discover', opts())).t; let from = 0;
    const iv = setInterval(async () => {
      const p = await api(`/api/preview?t=${t}&from=${from}`); from += p.pages.length;
      p.pages.forEach(x => {
        const i = P.push(x) - 1;
        $('plist').insertAdjacentHTML('beforeend', `<label style="padding-left:${10 + x.depth * 16}px"><input type="checkbox" id="pg${i}" ${i < +$('maxp').value ? 'checked' : ''}> ${esc(x.title)} <span>${esc(x.url)}</span></label>`);
        $('pg' + i).addEventListener('change', cnt);
      });
      cnt();
      if (p.finished) { clearInterval(iv); announce($('fcount').textContent); }
    }, 800);
  });
}
