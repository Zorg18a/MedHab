// Раздел «Входящие» и подключение расширения браузера.
import { $, esc, delegate } from '../core/dom.js';
import { api } from '../core/api.js';
import { notify } from '../a11y/announce.js';
import { chipHtml } from '../ui/chip.js';
import { poll } from './downloads.js';

let EXTD = '', LASTIB = '', IB = { batches: [] }, CH = {}, FL = {}, CLS = {};
const view = () => location.hash.slice(1) || 'library';
const KN = { manga: 'Манга', video: 'Видео', playlist: 'Плейлист', audio: 'Музыка', podcast: 'Подкаст', game: 'Игра', unknown: 'Неизвестно' };
const AL = { gamecard: 'Добавить игру в библиотеку', download: 'Скачать', track: 'Следить за обновлениями', link: 'Только сохранить ссылку', site: 'Скачать сайт офлайн', skip: 'Пропустить', known: 'Уже в библиотеке' };
const ACTS = { manga: ['download', 'track', 'link', 'skip'], video: ['download', 'link', 'skip'], playlist: ['download', 'track', 'link', 'skip'], audio: ['download', 'link', 'skip'], podcast: ['link', 'track', 'skip'], game: ['gamecard', 'link', 'skip'], unknown: ['link', 'site', 'skip'] };
const DEF = { manga: 'download', video: 'download', playlist: 'download', audio: 'download', podcast: 'link', game: 'link', unknown: 'link' };
const toDownloads = label => ({ action: { label, fn: () => { location.hash = '#downloads'; } } });

export const rowLabel = r => 'Включить в план: ' + r.title;

export async function pollExt() {
  const e = await api('/api/ext'); EXTD = e.ext_dir;
  const nb = $('ib'); nb.textContent = e.inbox_pending; nb.classList.toggle('hide', !e.inbox_pending);
  const p = e.pending[0], bar = $('pairBar');
  if (p) {
    if (bar.dataset.o !== p.origin) {
      bar.dataset.o = p.origin;
      bar.innerHTML = `<span>Расширение браузера (${esc(p.name)}) просит подключиться к MediaHub.</span><button type="button" class="btn primary" data-action="pair" data-o="${esc(p.origin)}" data-a="1">Разрешить</button><button type="button" class="btn" data-action="pair" data-o="${esc(p.origin)}" data-a="0">Отклонить</button>`;
    }
    bar.classList.remove('hide');
  } else { bar.classList.add('hide'); bar.dataset.o = ''; }
  if (view() === 'inbox') loadInbox();
}

export async function loadExt() {
  const e = await api('/api/ext');
  $('extDir').textContent = e.ext_dir; $('extFf').textContent = e.ext_ff;
  $('extSt').textContent = e.paired.length ? 'Подключено расширений: ' + e.paired.length : 'Расширение пока не подключено';
  $('extList').innerHTML = e.paired.map(o => `<button type="button" class="btn" data-action="forget" data-origin="${esc(o)}">Отключить</button>`).join('');
}

export async function loadInbox() {
  const d = await api('/api/inbox'), s = JSON.stringify(d), a = document.activeElement;
  if (s === LASTIB) return;
  if (LASTIB && a && a.closest && a.closest('#v-inbox') && /SELECT|INPUT/.test(a.tagName)) return;
  LASTIB = s; IB = d; drawInbox();
}

const stt = r => CH[r.id] ??= { on: r.action !== 'skip', action: r.action, kind: r.kind };
function sumOf(b) {
  let on = 0, dl = 0, lk = 0, kn = 0, cl = 0; const close = CLS[b.batch] ?? (b.rows[0] && b.rows[0].close);
  b.rows.filter(r => r.status === 'pending').forEach(r => {
    const s = stt(r), a = s.on ? s.action : 'skip'; if (a === 'skip') return; on++;
    if (a === 'download' || a === 'site' || a === 'gamecard') dl++; else if (a === 'known') kn++; else lk++;
    if (close) cl++;
  });
  return { on, dl, lk, kn, cl };
}
const sumText = b => { const m = sumOf(b); return `Выбрано ${m.on} из ${b.rows.length} · скачать ${m.dl} · сохранить ссылками ${m.lk}${m.kn ? ` · уже в библиотеке ${m.kn}` : ''} · закроется вкладок: ${m.cl}`; };

function drawInbox() {
  const el = $('inb');
  if (!IB.batches.length) {
    el.innerHTML = `<div class="empty"><div class="stack"><i></i><i></i><i></i></div><h2>Входящие пусты</h2><p>Сюда приходят вкладки из браузера. Вы выбираете, что сохранить и что скачать, а вкладки закрываются сами, когда материал уже на диске.</p><ol class="mu"><li>Chrome или Edge: откройте <code>chrome://extensions</code>, включите «Режим разработчика» и нажмите «Загрузить распакованное расширение».</li><li>Выберите папку <code>${esc(EXTD)}</code>. Для Firefox инструкция в «Настройки → Расширение для браузера».</li><li>Нажмите значок MediaHub на панели браузера, выберите вкладки и «Показать список в приложении».</li></ol></div>`;
    return;
  }
  el.innerHTML = IB.batches.map(b => {
    const pend = b.pending, f = FL[b.batch] || '', rows = b.rows, k = r => pend && r.status === 'pending' ? stt(r).kind : r.kind;
    const cnt = {}; rows.forEach(r => cnt[k(r)] = (cnt[k(r)] || 0) + 1);
    const fresh = rows.filter(r => r.state === 'new').length, have = rows.filter(r => r.state === 'downloaded' || r.state === 'link' || r.state === 'missing').length;
    const chips = [['', 'Все', rows.length], ...Object.keys(cnt).map(x => [x, KN[x] || x, cnt[x]]), ['s:new', 'Новое', fresh], ['s:have', 'Уже есть', have]].filter(c => c[2] || !c[0]);
    const vis = r => !f || (f === 's:new' ? r.state === 'new' : f === 's:have' ? (r.state !== 'new' && r.state !== 'dup') : k(r) === f);
    const t = new Date(b.created.replace(' ', 'T') + 'Z').toLocaleTimeString('ru', { hour: '2-digit', minute: '2-digit' });
    const row = r => {
      const hide = vis(r) ? '' : ' hide';
      if (r.status !== 'pending') return `<div class="ir done${hide}"><span class="kc">${esc(KN[r.kind] || r.kind)}</span><div class="im"><a class="it" href="${esc(r.url)}" target="_blank" rel="noopener" title="${esc(r.title)}">${esc(r.title)}</a><div class="fate ${r.status === 'kept' ? 'kept' : r.status === 'closed' || r.status === 'done' ? 'ok' : ''}">${esc(r.fate)}</div></div>${r.status === 'closed' ? `<button type="button" class="btn quiet" data-action="reopen" data-id="${r.id}" data-url="${esc(r.url)}">Вернуть вкладку</button>` : '<span></span>'}</div>`;
      const s = stt(r), opts = [...ACTS[s.kind]];
      if (r.state === 'downloaded' || r.state === 'card') opts.unshift('known');
      if (!opts.includes(s.action)) s.action = (r.state === 'downloaded' || r.state === 'card') ? 'known' : DEF[s.kind];
      return `<div class="ir${s.on ? '' : ' off'}${hide}" data-id="${r.id}"><input type="checkbox" class="ick" aria-label="${esc(rowLabel(r))}" ${s.on ? 'checked' : ''}><div class="im"><a class="it" href="${esc(r.url)}" target="_blank" rel="noopener" title="${esc(r.title)}">${esc(r.title)}</a><div class="fate">${esc(r.host)} · ${esc(r.state_text)}</div><div class="fate ${s.on && s.action !== 'skip' ? '' : 'kept'}">${s.on && s.action !== 'skip' && (CLS[b.batch] ?? r.close) ? 'Вкладка закроется после обработки' : 'Вкладка останется открытой'}</div></div>
    <select class="ik" aria-label="${esc('Тип материала: ' + r.title)}">${Object.keys(KN).map(x => `<option value="${x}" ${x === s.kind ? 'selected' : ''}>${KN[x]}</option>`).join('')}</select>
    <select class="ia" aria-label="${esc('Что сделать: ' + r.title)}">${opts.map(a => `<option value="${a}" ${a === s.action ? 'selected' : ''}>${AL[a]}</option>`).join('')}</select></div>`;
    };
    return `<section class="batch" data-b="${b.batch}"><div class="bh"><h2>Разбор: ${rows.length} вкладок, ${t}</h2>${pend ? '' : `<button type="button" class="btn quiet" data-action="dismiss" data-b="${b.batch}">Убрать из списка</button>`}</div>
   <div class="chips" style="margin-bottom:6px">${chips.map(c => chipHtml(c[1], { pressed: f === c[0], count: c[2], action: 'filter', value: c[0], data: { b: b.batch } })).join('')}</div>
   <div class="rows">${rows.map(row).join('')}</div>
   ${pend ? `<div class="bbar"><div class="bsum" aria-live="polite">${sumText(b)}</div><label class="chkrow"><input type="checkbox" class="cls" data-b="${b.batch}" ${(CLS[b.batch] ?? rows[0].close) ? 'checked' : ''}> Закрывать обработанные вкладки</label><button type="button" class="btn" data-action="links" data-b="${b.batch}">Только сохранить ссылки</button><button type="button" class="btn primary" data-action="confirm" data-b="${b.batch}">Добавить в очередь</button></div>` : ''}</section>`;
  }).join('');
}

function updSum(b) {
  const bt = IB.batches.find(x => x.batch == b), s = document.querySelector(`.batch[data-b="${b}"] .bsum`);
  if (s && bt) s.textContent = sumText(bt);
}

async function sendPlan(b, onlyLinks) {
  const bt = IB.batches.find(x => x.batch == b), close = !!(CLS[b] ?? bt.rows[0].close);
  const rows = bt.rows.filter(r => r.status === 'pending').map(r => {
    const s = stt(r); let a = s.on ? s.action : 'skip';
    if (onlyLinks && (a === 'download' || a === 'site')) a = ACTS[s.kind].includes('link') ? 'link' : 'skip';
    return { id: r.id, action: a, kind: s.kind };
  });
  const r = await api('/api/inbox/confirm', { batch: b, close, rows });
  LASTIB = ''; loadInbox(); poll();
  notify(r.download ? `В очереди: ${r.download}. Ссылок сохранено: ${r.links}. Вкладки закроются по мере готовности` : `Ссылок сохранено: ${r.links}`, r.download ? toDownloads('Загрузки') : {});
}

export function initInbox() {
  delegate($('pairBar'), 'click', {
    pair: async b => {
      await api('/api/ext/approve', { origin: b.dataset.o, allow: b.dataset.a === '1' });
      $('pairBar').dataset.o = ''; pollExt();
      notify(b.dataset.a === '1' ? 'Расширение подключено' : 'Подключение отклонено');
    },
  });
  delegate($('extList'), 'click', {
    forget: async b => { await api('/api/ext/forget', { origin: b.dataset.origin }); loadExt(); notify('Расширение отключено'); },
  });
  delegate($('inb'), 'click', {
    filter: b => {
      FL[b.dataset.b] = b.dataset.value; drawInbox();
      const n = document.querySelector(`#inb [data-action="filter"][data-b="${b.dataset.b}"][data-value="${b.dataset.value}"]`); if (n) n.focus();
    },
    confirm: b => sendPlan(b.dataset.b, false),
    links: b => sendPlan(b.dataset.b, true),
    dismiss: async b => { await api('/api/inbox/dismiss', { batch: b.dataset.b }); LASTIB = ''; loadInbox(); },
    reopen: async b => { window.open(b.dataset.url, '_blank'); await api('/api/inbox/reopened', { id: +b.dataset.id }); LASTIB = ''; loadInbox(); notify('Вкладка возвращена'); },
  });
  $('inb').addEventListener('change', e => {
    const row = e.target.closest('.ir[data-id]'), bt = e.target.closest('.batch'); if (!bt) return;
    const b = bt.dataset.b;
    if (e.target.classList.contains('cls')) { CLS[b] = e.target.checked; drawInbox(); return; }
    if (!row) return;
    const r = IB.batches.flatMap(x => x.rows).find(x => x.id == row.dataset.id), s = stt(r);
    const fate = () => {
      const f = row.querySelector('.im .fate:last-child'), will = s.on && s.action !== 'skip' && (CLS[b] ?? r.close);
      f.textContent = will ? 'Вкладка закроется после обработки' : 'Вкладка останется открытой'; f.classList.toggle('kept', !will);
    };
    if (e.target.classList.contains('ick')) { s.on = e.target.checked; row.classList.toggle('off', !s.on); fate(); updSum(b); }
    if (e.target.classList.contains('ia')) { s.action = e.target.value; fate(); updSum(b); }
    if (e.target.classList.contains('ik')) {
      s.kind = e.target.value; s.action = (r.state === 'downloaded' || r.state === 'card') ? 'known' : DEF[s.kind]; drawInbox();
      const n = document.querySelector(`.ir[data-id="${r.id}"] .ik`); if (n) n.focus();
    }
  });
}
