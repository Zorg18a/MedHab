// Блок «Продолжить» в Библиотеке: недосмотренное видео и аудио, начатая манга. Данные с /api/continue.
import { $, esc, delegate } from '../core/dom.js';
import { api } from '../core/api.js';
import { I, IC } from '../core/fmt.js';
import { announce } from '../a11y/announce.js';
import { progressHtml } from '../ui/progress.js';

let items = [], shown = true, last = '';

function card(x) {
  const inner = x.cover ? `<img src="${esc(x.cover)}" alt="" loading="lazy">` : `<span class="ph">${I(IC[x.kind] || IC.video, 38)}</span>`;
  const cover = `<a class="cv" href="${esc(x.open)}"${x.kind === 'manga' ? '' : ' target="_blank" rel="noopener"'} aria-label="Продолжить: ${esc(x.title)}">${inner}</a>`;
  const forget = `<button type="button" aria-label="Убрать из «Продолжить»: ${esc(x.title)}" title="Убрать из «Продолжить»" data-action="forget" data-id="${+x.id}">${I('<path d="M6 6l12 12M18 6L6 18"/>', 16)}</button>`;
  return `<li data-id="${+x.id}"><article class="c">${cover}<div class="act">${forget}</div><h3 class="t" title="${esc(x.title)}">${esc(x.title)}</h3><p class="a">${esc(x.label)}</p>${progressHtml(x.pct, 'Просмотрено')}</article></li>`;
}

export function continueHtml(list) {
  if (!list || !list.length) return '';
  return `<section class="grp" aria-labelledby="contH"><h2 id="contH" tabindex="-1">Продолжить</h2><ul class="grid wide cont-list">${list.map(card).join('')}</ul></section>`;
}

// Показывается только при непустом списке, пустом поиске и фильтре «Все».
export function syncContinue(show) { shown = show; $('cont').classList.toggle('hide', !show); }

export async function loadContinue() {
  let next;
  try { next = await api('/api/continue'); } catch (e) { next = []; }
  if (!Array.isArray(next)) next = [];
  const key = JSON.stringify(next);
  if (key === last) return;                 // без изменений: не перерисовываем, чтобы не терять фокус
  last = key; items = next; $('cont').innerHTML = continueHtml(items); syncContinue(shown);
}

async function forget(el) {
  const id = +el.dataset.id, i = items.findIndex(x => x.id === id), nextId = items[i + 1]?.id;
  try { await api('/api/play/forget', { id }); } catch (e) { announce('Не удалось убрать из «Продолжить»'); return; }
  announce('Убрано из «Продолжить»'); await loadContinue();
  const target = (nextId != null && $('cont').querySelector(`li[data-id="${nextId}"] .cv`)) || $('contH') || document.querySelector('#v-library h1');
  target && target.focus();
}

export function initContinue() {
  delegate($('cont'), 'click', { forget });
  document.addEventListener('visibilitychange', () => { if (!document.hidden && !$('v-library').classList.contains('hide')) loadContinue(); });
}
