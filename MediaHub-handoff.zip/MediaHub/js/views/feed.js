// «Лента»: что нового у игр (версия в теме), манги (новые главы) и видео (новое у канала). Данные с /api/feed.
// Приложение ничего не скачивает само: каждое действие — по кнопке. Состояние «новое» подписано текстом, не только цветом.
import { $, esc, delegate } from '../core/dom.js';
import { api } from '../core/api.js';
import { announce, notify } from '../a11y/announce.js';

const KN = { game: 'Игры', manga: 'Манга', video: 'Видео' };
const S = { kind: '', unseen: false, data: null };
const when = t => t ? new Date(t * 1000).toLocaleString('ru-RU', { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' }) : 'ещё не было';

export async function refreshBadge() {   // число непрочитанного в меню; в имя ссылки добавляется тоже, чтобы его слышали
  let n = 0;
  try { n = (await api('/api/feed/count')).unseen || 0; } catch (e) { return; }
  const b = $('fb'), a = b.closest('a');
  b.textContent = n > 99 ? '99+' : String(n); b.classList.toggle('hide', !n); b.setAttribute('aria-hidden', 'true');
  a.setAttribute('aria-label', n ? `Лента, непрочитанных: ${n}` : 'Лента');
}

function eventHtml(e) {
  const act = e.action === 'download' ? (e.kind === 'manga' ? 'Скачать новые главы' : 'Скачать видео') : 'Открыть страницу';
  return `<li class="fev${e.seen ? ' seen' : ''}" data-id="${e.id}"><div class="fh"><span class="vbadge v-man">${KN[e.kind] || esc(e.kind)}</span>${e.seen ? '' : ' <span class="vbadge v-upd">новое</span>'} <time class="mu">${when(e.at)}</time></div>
    <h3 class="ft">${esc(e.title)}</h3><p class="mu">${esc(e.detail)}</p>
    <div class="glk"><button type="button" class="btn${e.seen ? '' : ' primary'}" data-action="act" data-id="${e.id}" data-url="${esc(e.url)}" data-kind="${esc(e.action)}" aria-label="${act}: ${esc(e.title)}">${act}</button>
    ${e.seen ? '' : `<button type="button" class="btn" data-action="seen" data-id="${e.id}" aria-label="Отметить прочитанным: ${esc(e.title)}">Прочитано</button>`}
    <button type="button" class="btn" data-action="dismiss" data-id="${e.id}" aria-label="Убрать из ленты: ${esc(e.title)}">Убрать</button></div></li>`;
}

function render() {
  const d = S.data; if (!d) return;
  $('f-list').innerHTML = d.events.length ? d.events.map(eventHtml).join('')
    : `<li class="empty">${S.kind || S.unseen ? 'В этом виде ничего нет.' : 'Пока ничего нового. Нажмите «Проверить сейчас» или включите проверку по расписанию в настройках.'}</li>`;
  const st = d.status, u = d.unseen;
  document.querySelectorAll('#f-chips [data-kind]').forEach(c => { const k = c.dataset.kind, n = k ? u[k] : d.total_unseen; c.setAttribute('aria-pressed', String(S.kind === k)); c.textContent = (k ? KN[k] : 'Всё') + (n ? ` (${n})` : ''); });
  $('f-unseen').setAttribute('aria-pressed', String(S.unseen));
  $('f-check').disabled = st.running; $('f-check').textContent = st.running ? 'Проверяется…' : 'Проверить сейчас';
  $('f-seenall').disabled = !d.total_unseen;
  $('f-status').textContent = `Последняя проверка: ${when(st.checked)}${st.last ? '. ' + st.last : ''}.${st.hours ? ` По расписанию: каждые ${st.hours} ч.` : ' Расписание выключено (настройки).'}`;
  const t = d.tracked;
  $('f-tracked').textContent = `Игры: ${t.game} (проверяются через расширение). Манга: ${t.manga}, из них проверяется ${t.manga_supported} (пока только mangabuff). Видео: ${t.video} ${t.video === 1 ? 'источник' : 'источников'}.`;
  $('f-watches').innerHTML = d.watches.length ? d.watches.map(w => `<li class="fev" data-id="${w.id}"><h3 class="ft">${esc(w.title || w.url)}</h3><p class="mu">${esc(w.url)}</p>
    <p class="mu">${w.error ? 'Ошибка проверки: ' + esc(w.error) : w.baselined ? 'Проверено: ' + when(w.checked) : 'Первая проверка только запомнит, что на канале уже есть.'}</p>
    <div class="glk"><button type="button" class="btn" data-action="unwatch" data-id="${w.id}" aria-label="Перестать следить: ${esc(w.title || w.url)}">Перестать следить</button></div></li>`).join('')
    : '<li class="empty">Каналов и плейлистов нет. Добавьте ссылку выше: новые видео появятся в ленте.</li>';
}

export async function loadFeed() {
  S.data = await api('/api/feed?' + new URLSearchParams({ kind: S.kind, unseen: S.unseen ? '1' : '0' }));
  render(); refreshBadge();
  if (S.data.status.running) setTimeout(() => { if (!$('v-feed').classList.contains('hide')) loadFeed(); }, 2000);
}

const focusAfter = (id, fallback) => { const n = document.querySelector(`#f-list [data-id="${id}"] .btn`); (n || $(fallback)).focus(); };

async function check() {
  const r = await api('/api/feed/check', {});
  if (r.error) { notify(r.error, { kind: 'error' }); return; }
  announce('Проверка началась'); await loadFeed();
}

export function initFeed() {
  $('f-check').addEventListener('click', check);
  $('f-seenall').addEventListener('click', async () => { await api('/api/feed/seen', S.kind ? { kind: S.kind } : { all: true }); announce('Всё отмечено прочитанным'); await loadFeed(); $('f-check').focus(); });
  $('f-chips').addEventListener('click', async e => {
    const c = e.target.closest('.chip'); if (!c) return;
    if (c.id === 'f-unseen') S.unseen = !S.unseen; else S.kind = c.dataset.kind;
    await loadFeed(); document.querySelector(c.id ? '#f-unseen' : `#f-chips [data-kind="${c.dataset.kind}"]`).focus();
  });
  delegate($('f-list'), 'click', {
    act: async el => {
      const id = +el.dataset.id;
      if (el.dataset.kind === 'download') { const r = await api('/api/feed/act', { id }); if (r.error) { notify(r.error, { kind: 'error' }); return; } notify('Поставлено в очередь: смотрите «Загрузки»'); }
      else { window.open(el.dataset.url, '_blank', 'noopener'); await api('/api/feed/seen', { ids: [id] }); }
      await loadFeed(); focusAfter(id, 'f-check');
    },
    seen: async el => { const id = +el.dataset.id, next = el.closest('li').nextElementSibling?.dataset.id; await api('/api/feed/seen', { ids: [id] }); announce('Отмечено прочитанным'); await loadFeed(); focusAfter(S.unseen ? next : id, 'f-check'); },
    dismiss: async el => { const next = el.closest('li').nextElementSibling?.dataset.id; await api('/api/feed/dismiss', { ids: [+el.dataset.id] }); announce('Убрано из ленты'); await loadFeed(); focusAfter(next, 'f-wh'); },
  });
  const add = async () => {
    const url = $('f-wurl').value.trim(), er = $('f-werr'), r = await api('/api/feed/watch', { url, title: $('f-wtitle').value });
    if (r.error) { er.textContent = r.error; er.hidden = false; $('f-wurl').setAttribute('aria-invalid', 'true'); $('f-wurl').focus(); return; }
    er.hidden = true; $('f-wurl').removeAttribute('aria-invalid'); $('f-wurl').value = ''; $('f-wtitle').value = ''; announce('Источник добавлен'); await loadFeed(); $('f-wurl').focus();
  };
  $('f-wadd').addEventListener('click', add); $('f-wurl').addEventListener('keydown', e => { if (e.key === 'Enter') add(); });
  delegate($('f-watches'), 'click', { unwatch: async el => { await api('/api/feed/unwatch', { id: +el.dataset.id }); announce('Больше не отслеживается'); await loadFeed(); $('f-wurl').focus(); } });
}
