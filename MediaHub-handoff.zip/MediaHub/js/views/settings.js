// Раздел «Настройки»: серверные параметры (автосохранение) и режимы отображения (localStorage).
import { $, esc } from '../core/dom.js';
import { api } from '../core/api.js';
import { notify, announce } from '../a11y/announce.js';
import { loadPrefs, savePrefs, applyPrefs } from '../a11y/prefs.js';
import { loadExt } from './inbox.js';

const SET = ['feed_hours', 'games_check_hours', 'manga_via', 'folder', 'res', 'afmt', 'subs_on', 'subs_langs', 'thumbs', 'skip', 'workers', 'limit_mb', 'depth', 'maxp', 'videos', 'show_browser', 'cookie_file', 'cookie_browser', 'games_root', 'game_marker', 'lan'];
let timer;
let SM = {};   // качество и формат по сайтам

function drawSites() {
  const hosts = Object.keys(SM).sort(), name = r => r === 'best' ? 'лучшее' : r;
  $('sm_list').innerHTML = hosts.length ? hosts.map(h => {
    const p = SM[h], parts = [p.res && `качество ${name(p.res)}`, p.vfmt && `видео ${p.vfmt}`, p.afmt && `звук ${p.afmt}`].filter(Boolean).join(', ');
    return `<li><span><b>${esc(h)}</b>: ${esc(parts)}</span><button type="button" class="btn" data-sm="${esc(h)}">Убрать ${esc(h)}</button></li>`;
  }).join('') : '<li class="mu">Пока нет: везде общие настройки.</li>';
}

async function saveSites(next, msg, focusAfter) {
  const r = await api('/api/settings', { site_media: next });
  if (r.error) return r;
  SM = r.site_media || {}; drawSites(); notify(msg); if (focusAfter) focusAfter();
  return r;
}

function syncDisplay() {
  const p = loadPrefs();
  $('d_scale').value = String(p.scale); $('d_contrast').value = p.contrast; $('d_theme').value = p.theme;
  $('d_targets').checked = p.targets === 'large'; $('d_keys').checked = p.keys;
}

export async function loadSettings() {
  const c = await api('/api/settings');
  SET.forEach(k => { const e = $('s_' + k); if (!e) return; e.type === 'checkbox' ? e.checked = !!c[k] : e.value = c[k] ?? ''; });
  $('s_subs_langs').disabled = !c.subs_on;
  SM = c.site_media || {}; drawSites();
  syncDisplay();
  loadExt();
  loadLan();
}

async function loadLan() {   // состояние доступа с других устройств: адрес для телефона, нужен ли перезапуск, сколько устройств вошло
  const l = await api('/api/lan'), st = $('lan_status');
  const parts = [];
  if (l.bound) parts.push(l.addresses.length ? `Включено. Откройте на другом устройстве в этой сети: ${l.addresses.join(' или ')}.` : 'Включено, но адрес в сети определить не удалось.');
  else parts.push(l.enabled && l.pin_set ? 'Включено в настройках, но ещё не работает.' : 'Выключено: приложение доступно только на этом компьютере.');
  if (l.restart) parts.push('Перезапустите MediaHub, чтобы изменение вступило в силу.');
  if (l.bound && l.sessions) parts.push(`Вошедших устройств: ${l.sessions}.`);
  if (!l.pin_set) parts.push('PIN ещё не задан.');
  st.textContent = parts.join(' ');
  $('lan_logout').hidden = !l.sessions;
}

function save() {
  clearTimeout(timer);
  timer = setTimeout(async () => {
    const b = {};
    SET.forEach(k => { const e = $('s_' + k); b[k] = e.type === 'checkbox' ? e.checked : e.type === 'number' ? +e.value || 0 : e.value.trim(); });
    if (!b.workers) b.workers = 3;
    const r = await api('/api/settings', b);
    if (r.error) { notify(r.error, { kind: 'error' }); loadSettings(); return; }   // например, режим сети без PIN: возвращаем прежнее состояние
    $('s_subs_langs').disabled = !b.subs_on;
    loadLan();
    notify('Сохранено');
  }, 500);
}

const THEMES = { dark: 'тёмная', light: 'светлая', system: 'как в системе' };

export function initSettings() {
  SET.forEach(k => {
    const e = $('s_' + k);
    e.addEventListener('change', save);
    if (e.type !== 'checkbox' && e.tagName === 'INPUT') e.addEventListener('input', save);
  });
  $('sm_add').addEventListener('click', async () => {
    const h = $('sm_host'), err = $('sm_err'), entry = {}, fail = m => { err.textContent = m; h.setAttribute('aria-invalid', 'true'); h.focus(); };
    err.textContent = ''; h.removeAttribute('aria-invalid');
    ['res', 'vfmt', 'afmt'].forEach(k => { const v = $('sm_' + k).value; if (v) entry[k] = v; });
    if (!h.value.trim()) return fail('Введите сайт, например youtube.com');
    if (!Object.keys(entry).length) return fail('Выберите качество или формат: иначе настройка ничего не меняет');
    const r = await saveSites({ ...SM, [h.value.trim()]: entry }, `Сохранено для сайта ${h.value.trim()}`, () => { h.value = ''; h.focus(); });
    if (r.error) fail(r.error);
  });
  $('sm_list').addEventListener('click', async e => {
    const b = e.target.closest('[data-sm]'); if (!b) return;
    const host = b.dataset.sm, next = { ...SM }; delete next[host];
    await saveSites(next, `Настройка сайта ${host} убрана`, () => { const n = $('sm_list').querySelector('[data-sm]'); (n || $('sm_host')).focus(); });
  });
  $('lan_pin_save').addEventListener('click', async () => {
    const e = $('lan_pin'), r = await api('/api/settings', { lan_pin: e.value });
    if (r.error) { notify(r.error, { kind: 'error' }); e.setAttribute('aria-invalid', 'true'); e.focus(); return; }
    e.value = ''; e.removeAttribute('aria-invalid'); notify('PIN сохранён'); loadLan();
  });
  $('lan_logout').addEventListener('click', async () => { await api('/api/lan/logout', {}); notify('Все устройства вышли'); loadLan(); });
  const apply = (patch, msg) => { applyPrefs(savePrefs(patch)); announce(msg); };
  $('d_scale').addEventListener('change', e => apply({ scale: +e.target.value }, `Размер текста: ${e.target.value} %`));
  $('d_contrast').addEventListener('change', e => apply({ contrast: e.target.value }, `Контраст: ${e.target.value === 'high' ? 'высокий' : 'обычный'}`));
  $('d_theme').addEventListener('change', e => apply({ theme: e.target.value }, `Тема: ${THEMES[e.target.value]}`));
  $('d_targets').addEventListener('change', e => apply({ targets: e.target.checked ? 'large' : 'normal' }, `Крупные цели нажатия: ${e.target.checked ? 'включены' : 'выключены'}`));
  $('d_keys').addEventListener('change', e => apply({ keys: e.target.checked }, `Горячие клавиши: ${e.target.checked ? 'включены' : 'выключены'}`));
}
