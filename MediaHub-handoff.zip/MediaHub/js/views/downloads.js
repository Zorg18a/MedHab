// Раздел «Загрузки», нижняя полоса и опрос очереди. Скринридеру сообщаются только смены состояния.
import { $, esc, delegate } from '../core/dom.js';
import { api } from '../core/api.js';
import { B, ETA, I, IC } from '../core/fmt.js';
import { announce, notify } from '../a11y/announce.js';
import { progressHtml, milestone } from '../ui/progress.js';
import { loadLibrary } from './library.js';
import { pollExt } from './inbox.js';
import { disk } from '../core/disk.js';

let J = [], prev = null, lastAct = 0;
const view = () => location.hash.slice(1) || 'library';
const isA = j => /^(качается|в очереди|запл)/.test(j.status);

const cat = s => /^качается/.test(s) ? 'run' : /^в очереди/.test(s) ? 'queue' : /^запл/.test(s) ? 'plan' : /^(готово|сохранено)/.test(s) ? 'done' : /^ошибка/.test(s) ? 'err' : /^частично/.test(s) ? 'part' : 'other';

// Что изменилось между двумя опросами: [{text, kind}], kind = 'info' | 'error'.
export function diff(before, after) {
  const out = [], old = new Map(before.map(x => [x.id, x]));
  for (const x of after) {
    const o = old.get(x.id), c = cat(x.status), oc = o ? cat(o.status) : null, t = x.title;
    if (c !== oc) {
      if (c === 'run') out.push({ text: `${t}: началась загрузка`, kind: 'info' });
      else if (c === 'queue' && !o) out.push({ text: `${t}: в очереди`, kind: 'info' });
      else if (c === 'done') out.push({ text: `${t}: готово`, kind: 'info' });
      else if (c === 'err') out.push({ text: `${t}: ${x.status}`, kind: 'error' });
      else if (c === 'part') out.push({ text: `${t}: ${x.status}`, kind: 'info' });
    } else if (c === 'run' && o) {
      const m = milestone(o.pct, x.pct);
      if (m !== null && m < 100) out.push({ text: `${t}: ${m} %`, kind: 'info' });
    }
  }
  return out;
}
export const jobAnnouncements = (before, after) => diff(before, after).map(d => d.text);

export function drawBar(jobs = J) {
  const act = jobs.filter(isA), run = act.filter(j => j.status.startsWith('качается')), b = $('bar');
  if (!act.length || view() === 'downloads' || (!run.length && act.every(j => j.status.startsWith('запл')))) { b.classList.add('hide'); return; }
  const j = run[0] || act[0], sp = jobs.reduce((a, x) => a + (x.speed || 0), 0), pc = Math.round(act.reduce((a, x) => a + x.pct, 0) / act.length);
  b.classList.remove('hide');
  $('bt').textContent = j.title;
  $('bs').textContent = act.length > 1 ? `и ещё ${act.length - 1} в очереди` : (j.eta ? 'осталось ' + ETA(j.eta) : '');
  $('bp').textContent = (sp ? B(sp) + '/с' : '') + ' · ' + pc + '%';
  $('bf').style.width = pc + '%';
}

export function drawJobs(jobs = J) {
  const sp = jobs.reduce((a, x) => a + (x.speed || 0), 0);
  $('tsp').textContent = sp ? B(sp) + '/с' : '';
  $('jobs').innerHTML = jobs.length ? [...jobs].reverse().map(x => {
    const a = isA(x), c = x.status.startsWith('ошибка') ? 'err' : x.status.startsWith('готово') || x.status.startsWith('сохранено') ? 'ok' : x.status.startsWith('частично') ? 'part' : '';
    return `<div class="job${a ? '' : ' done'}"><div class="ji">${I(IC[x.kind] || IC.video, 20)}</div><div style="min-width:0"><div class="jt" title="${esc(x.title)}">${esc(x.title)}</div><div class="js ${c}">${esc(x.status)}${x.speed ? ' · ' + B(x.speed) + '/с' : ''}${x.eta ? ' · осталось ' + ETA(x.eta) : ''}${x.daily ? ' · каждый день' : ''}</div>${progressHtml(x.pct, x.title)}</div>${a ? `<button type="button" class="x" aria-label="Отменить: ${esc(x.title)}" data-action="cancel" data-id="${x.id}">${I('<path d="M6 6l12 12M18 6 6 18"/>', 18)}</button>` : '<span></span>'}</div>`;
  }).join('') : '<div class="empty" style="margin-top:8vh"><h2>Загрузок нет</h2><p>Нажмите «Добавить», вставьте ссылку — здесь появятся ход и скорость.</p></div>';
}

export async function poll() {
  J = await api('/api/jobs');
  const act = J.filter(isA);
  $('nb').textContent = act.length; $('nb').classList.toggle('hide', !act.length);
  if (lastAct > act.length) { if (view() === 'library') loadLibrary(); disk(); }
  lastAct = act.length;
  if (prev) diff(prev, J).forEach(d => d.kind === 'error' ? notify(d.text, { kind: 'error' }) : announce(d.text));
  prev = J;
  if (view() === 'downloads') drawJobs(J);
  drawBar(J);
  pollExt();
}

export function initDownloads() {
  delegate($('jobs'), 'click', { cancel: async el => { await api('/api/cancel', { id: +el.dataset.id }); poll(); } });
  $('clr').addEventListener('click', async () => { await api('/api/clear', {}); poll(); });
  $('cxl').addEventListener('click', async () => { await api('/api/cancel', { all: 1 }); poll(); });
}
