// Раздел «Библиотека»: фильтры-чипы, группы, карточки, правка и удаление.
import { $, esc, delegate } from '../core/dom.js';
import { api } from '../core/api.js';
import { B, I, IC } from '../core/fmt.js';
import { notify } from '../a11y/announce.js';
import { chipHtml } from '../ui/chip.js';
import { openDialog, closeDialog } from '../ui/dialog.js';
import { openAdd } from './add.js';
import { initContinue, loadContinue, syncContinue } from './continue.js';
import { poll } from './downloads.js';
import { metaHtml, bindMeta, badgesHtml, metaLabel } from '../ui/meta.js';

let ALL = [], FK = '', L = [], EI = null, timer;
const KINDS = [['', 'Все'], ['video', 'Видео'], ['audio', 'Аудио'], ['manga', 'Манга'], ['site', 'Сайты'], ['game', 'Игры'], ['link', 'Ссылки'], ['fav', '★ Избранное']];
const toDownloads = () => ({ action: { label: 'Загрузки', fn: () => { location.hash = '#downloads'; } } });

export async function loadLibrary() {
  ALL = await api('/api/library?q=' + encodeURIComponent($('q').value));
  draw();
  loadContinue();
}

function card(x, g) {
  const sub = g === 'author' ? (['Разное', 'Игры', 'Ссылки'].includes(x.topic) ? '' : x.topic) : x.author;
  const inner = `${x.cover ? `<img src="${esc(x.cover)}" alt="" loading="lazy">` : `<span class="ph">${I(IC[x.kind] || IC.video, 38)}</span>`}${x.kind === 'link' ? '<span class="b l">Только ссылка</span>' : x.missing ? '<span class="b l">Файл не найден</span>' : x.extra ? `<span class="b l">${esc(x.extra)}</span>` : ''}${x.kind === 'link' ? '' : `<span class="b r">${B(x.size)}</span>`}${badgesHtml(x)}`;
  const cover = x.kind === 'game'
    ? `<button type="button" class="cv"${x.cover ? ` style="--cov:url('${esc(x.cover)}')"` : ''} data-action="reveal" data-i="${x.i}" aria-label="Показать в папке: ${esc(x.title)}${metaLabel(x)}">${inner}</button>`
    : `<a class="cv"${x.cover ? ` style="--cov:url('${esc(x.cover)}')"` : ''} href="${esc(x.open)}"${x.kind === 'manga' ? '' : ' target="_blank" rel="noopener"'} aria-label="Открыть: ${esc(x.title)}${metaLabel(x)}">${inner}</a>`;
  const btn = (act, label, icon) => `<button type="button" aria-label="${label}" title="${label}" data-action="${act}" data-i="${x.i}">${I(icon, 16)}</button>`;
  const acts = (x.kind !== 'link' ? btn('reveal', 'Показать в папке', '<path d="M3 7a2 2 0 0 1 2-2h4l2 2h8a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/>') : '')
    + (x.kind === 'link' ? btn('download', 'Скачать', '<path d="M12 4v11m0 0-4-4m4 4 4-4M5 20h14"/>') : '')
    + btn('edit', 'Изменить', '<path d="M4 20h4L19 9l-4-4L4 16v4zM13.5 6.5l4 4"/>')
    + btn('delete', 'Удалить', '<path d="M5 7h14M10 7V4h4v3M7 7l1 13h8l1-13M10 11v6M14 11v6"/>');
  return `<article class="c">${cover}<div class="act">${acts}</div><h3 class="t" title="${esc(x.title)}">${esc(x.title)}</h3>${sub || x.missing ? `<p class="a">${esc(sub || '')}${x.missing ? (sub ? ' · ' : '') + 'файл не найден' : ''}</p>` : ''}</article>`;
}

function draw() {
  syncContinue(!$('q').value && !FK);
  const cn = {}; ALL.forEach(x => cn[x.kind] = (cn[x.kind] || 0) + 1); cn.fav = ALL.filter(x => x.m && x.m.fav).length;
  if (FK && !cn[FK]) FK = '';
  $('chips').innerHTML = KINDS.filter(([k]) => !k || cn[k]).map(([k, n]) => chipHtml(n, { pressed: FK === k, count: k ? cn[k] : ALL.length, action: 'kind', value: k })).join('');
  const s = $('so').value, g = $('gb').value;
  L = ALL.filter(x => !FK || (FK === 'fav' ? x.m && x.m.fav : x.kind === FK));
  const ru = (a, b) => (a || '').localeCompare(b || '', 'ru');
  const SORT = { title: (a, b) => ru(a.title, b.title), size: (a, b) => b.size - a.size, small: (a, b) => a.size - b.size, old: (a, b) => a.id - b.id, author: (a, b) => ru(a.author, b.author) || ru(a.title, b.title) };
  L.sort(SORT[s] || ((a, b) => b.id - a.id));
  if (!L.length) {
    $('lib').innerHTML = $('q').value
      ? `<div class="empty"><h2>Ничего не нашлось</h2><p>По запросу «${esc($('q').value)}» в библиотеке ничего нет.</p></div>`
      : '<div class="empty"><div class="stack"><i></i><i></i><i></i></div><h2>Пока пусто</h2><p>Добавьте ссылку на видео, музыку, мангу или сайт — всё появится здесь с обложками.</p><div class="row"><button type="button" class="btn primary" data-action="open-add">Добавить ссылку</button><button type="button" class="btn quiet" data-action="scan">Найти файлы в папке</button></div></div>';
    return;
  }
  const m = {}; L.forEach((x, i) => { x.i = i; (m[g ? (x[g] || (g === 'playlist' ? 'Без плейлиста' : 'Без названия')) : ''] ??= []).push(x); });
  const wide = x => x.kind === 'video' || x.kind === 'audio' || x.kind === 'game';
  $('lib').innerHTML = Object.keys(m).sort((a, b) => a.localeCompare(b, 'ru')).map(k => {
    const w = m[k].filter(wide), p = m[k].filter(x => !wide(x));
    return `<section class="grp">${g ? `<h2>${esc(k)}<span>${m[k].length}</span></h2>` : ''}${w.length ? `<div class="grid wide">${w.map(x => card(x, g)).join('')}</div>` : ''}${p.length ? `<div class="grid">${p.map(x => card(x, g)).join('')}</div>` : ''}</section>`;
  }).join('');
}

async function scan() { await api('/api/scan', {}); notify('Папка просмотрена'); loadLibrary(); }

async function remove(files) {
  await api('/api/delete', { id: EI.id, files });
  closeDialog($('delDlg')); loadLibrary();
  notify(files ? 'Удалено вместе с файлами' : 'Убрано из библиотеки');
}

export function initLibrary() {
  delegate($('v-library'), 'click', {
    kind: el => { FK = el.dataset.value; draw(); const c = $('chips').querySelector(`[data-value="${FK}"]`); if (c) c.focus(); },
    'open-add': () => openAdd(),
    scan,
    reveal: async el => { const r = await api('/api/reveal', { id: L[+el.dataset.i].id }); notify(r.ok ? 'Открываю в проводнике' : 'Не удалось открыть: файла нет на месте', r.ok ? {} : { kind: 'error' }); },
    download: async el => { const r = await api('/api/item/download', { id: L[+el.dataset.i].id }); notify(r.error || 'Добавлено в очередь', r.error ? { kind: 'error' } : toDownloads()); poll(); },
    edit: el => { EI = L[+el.dataset.i]; $('editT').textContent = EI.title; $('eAuthor').value = EI.author || ''; $('eTopic').value = EI.topic || ''; $('eMeta').innerHTML = metaHtml(EI); openDialog($('editDlg')); },
    delete: el => {
      EI = L[+el.dataset.i]; const keep = EI.kind === 'game' || EI.kind === 'link';
      $('delT').textContent = '«' + EI.title + '»' + (EI.kind === 'game' ? '. Файлы игры не удаляются: игра только пропадёт из библиотеки до следующего сканирования.' : '');
      $('delF').classList.toggle('hide', keep); openDialog($('delDlg'));
    },
  });
  ['gb', 'so'].forEach(i => $(i).addEventListener('change', draw));
  initContinue();
  $('q').addEventListener('input', () => { syncContinue(!$('q').value && !FK); clearTimeout(timer); timer = setTimeout(loadLibrary, 250); });
  $('scan').addEventListener('click', scan);
  $('editC').addEventListener('click', () => closeDialog($('editDlg')));
  bindMeta($('editDlg'), () => EI, (x, what) => { draw(); if (what === 'cover') { $('eMeta').innerHTML = metaHtml(x); const b = $('eMeta').querySelector('[data-m=cover]'); if (b) b.focus(); } });
  $('editS').addEventListener('click', async () => {
    await api('/api/edit', { id: EI.id, author: $('eAuthor').value, topic: $('eTopic').value });
    closeDialog($('editDlg')); loadLibrary(); notify('Сохранено');
  });
  $('delC').addEventListener('click', () => closeDialog($('delDlg')));
  $('delL').addEventListener('click', () => remove(false));
  $('delF').addEventListener('click', () => remove(true));
}
