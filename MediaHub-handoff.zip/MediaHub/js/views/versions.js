// «Версии и чистка» (старые версии игр → Корзина) и «Вкладки браузера» (сверка вкладок с играми на ПК).
// Раньше это был отдельный GameSweep в iframe со своим сервером и токеном; теперь родной раздел на /api/versions/*.
import { $, esc, delegate } from '../core/dom.js';
import { api } from '../core/api.js';
import { B } from '../core/fmt.js';
import { notify } from '../a11y/announce.js';
import { initTabs } from '../ui/tabs.js';
import { openDialog, closeDialog } from '../ui/dialog.js';
import { parseQuery, accepts, highlight } from '../core/search.js';

const S = { groups: [], sel: new Set(), cur: '', closed: new Set(), chips: { old: false, sure: false, keep: false }, running: false };
const TS = { tabs: [], sum: null, cur: '', chips: { close: false, update: false, missing: false, unsure: false, other: false } };
const OLD = m => m.status === 'старая' || m.status === 'дубль';
const dt = t => t ? new Date(t * 1000).toLocaleDateString('ru-RU') : '—';
const last = p => String(p).split(/[\\/]/).pop();
const rowText = (g, m) => [g.title, m.name, m.path, m.version, m.status, dt(m.mtime)].join(' ');
const members = () => S.groups.flatMap(g => g.members.map(m => ({ g, m })));
const showErr = msg => { const e = $('v-err'); e.textContent = msg || ''; e.hidden = !msg; };
const plural = (n, f) => n % 10 === 1 && n % 100 !== 11 ? f[0] : 2 <= n % 10 && n % 10 <= 4 && !(12 <= n % 100 && n % 100 <= 14) ? f[1] : f[2];

let timer = 0, ttimer = 0, loaded = false, wasRunning = false;

// ---------- старые версии ----------
function visible() {
  const pq = parseQuery($('v-q').value), out = [];
  for (const g of S.groups) {
    if (S.chips.sure && !g.sure) continue;
    const ms = g.members.filter(m => !(S.chips.old && !OLD(m)) && !(S.chips.keep && m.status === 'оставить'));
    if (!ms.length || (pq.any && !ms.some(m => accepts(pq, rowText(g, m), m.size)))) continue;
    out.push({ g, ms });
  }
  const by = $('v-sort').value, newest = v => Math.max(...v.g.members.map(m => m.mtime || 0));
  out.sort((a, b) => by === 'free' ? b.g.free - a.g.free : by === 'new' ? newest(b) - newest(a)
    : by === 'sure' ? (b.g.sure - a.g.sure) || a.g.title.localeCompare(b.g.title, 'ru') : a.g.title.localeCompare(b.g.title, 'ru'));
  return { pq, out };
}

function render() {
  const { pq, out } = visible();
  $('v-count').textContent = S.groups.length ? `Групп: ${out.length} из ${S.groups.length}` : '';
  if (!out.length) {
    $('v-list').innerHTML = `<p class="empty">${S.groups.length ? 'Ничего не найдено: измените запрос или снимите фильтры. Слова через пробел, «-слово» исключает, «>500мб» ищет по размеру.' : 'Групп с несколькими версиями нет, или папка ещё не просканирована.'}</p>`;
    return footer();
  }
  $('v-list').innerHTML = out.map(({ g, ms }, gi) => {
    const closed = S.closed.has(g.key), hid = `vg${gi}`;
    return `<section class="vgrp" aria-labelledby="${hid}"><h3 id="${hid}"><button type="button" class="vgh" aria-expanded="${!closed}" data-action="fold" data-key="${esc(g.key)}"><span aria-hidden="true">${closed ? '▸' : '▾'}</span>${highlight(g.title, pq)}</button>
      ${g.sure ? '' : '<span class="vtag">проверьте вручную</span>'}<span class="mu">${g.members.length} ${plural(g.members.length, ['версия', 'версии', 'версий'])} · освободится ${B(g.free)}</span></h3>` +
      (closed ? '' : `<ul class="vrows">${ms.map((m, i) => `<li class="vrow" ${S.cur === m.path ? 'aria-current="true"' : ''}>
        <input type="checkbox" id="vc${gi}-${i}" data-action="pick" data-path="${esc(m.path)}" ${S.sel.has(m.path) ? 'checked' : ''} aria-label="Выбрать для Корзины: ${esc(m.name)}${OLD(m) ? '' : '. Актуальная версия: удаление потребует отдельного подтверждения'}">
        <button type="button" class="vmain" data-action="open" data-path="${esc(m.path)}"><span><span class="vbadge s-${esc(m.status)}">${esc(m.status)}</span></span><span>${esc(m.version)}</span><span class="mu">${dt(m.mtime)}</span><span>${B(m.size)}</span>
        <span class="nm">${highlight(m.name, pq)}<span class="p">${highlight(m.path, pq)}</span></span></button></li>`).join('')}</ul>`) + '</section>';
  }).join('');
  footer();
}

function footer() {
  const chosen = members().filter(x => S.sel.has(x.m.path)), size = chosen.reduce((s, x) => s + x.m.size, 0), keep = chosen.filter(x => !OLD(x.m)).length;
  $('v-selinfo').textContent = chosen.length ? `Выбрано ${chosen.length} · освободится ${B(size)}${keep ? ` · актуальных: ${keep}` : ''}` : 'Ничего не выбрано';
  $('v-trash').disabled = !chosen.length;
}

function detail(path) {
  const x = members().find(y => y.m.path === path); S.cur = path;
  if (!x) return;
  const { g, m } = x;
  $('v-detail').innerHTML = `<h3>${esc(g.title)}</h3><span class="vbadge s-${esc(m.status)}">${esc(m.status)}</span> <span class="mu">${esc(m.reason)}</span>
    <dl><dt>Версия</dt><dd>${esc(m.version)}</dd><dt>Тип</dt><dd>${m.type === 'folder' ? 'папка' : 'архив'}</dd><dt>Размер</dt><dd>${B(m.size)}</dd><dt>Изменено</dt><dd>${dt(m.mtime)}</dd><dt>Имя</dt><dd>${esc(m.name)}</dd><dt>Путь</dt><dd>${esc(m.path)}</dd></dl>`
    + (g.notes.length ? `<p class="mu">Внимание: ${g.notes.map(esc).join('; ')}</p>` : '')
    + `<p><button type="button" class="btn" data-action="reveal" data-path="${esc(m.path)}">Показать в папке</button></p>`;
}

function setState(st) {
  const prog = $('v-prog');
  S.running = !!st.running; prog.hidden = !st.running; if (st.running) prog.value = st.total ? Math.round(100 * st.done / st.total) : 0;
  showErr(st.error); $('v-scan').disabled = !!st.running;
  if (st.running) return;
  if (st.scanned) {
    S.groups = st.groups || []; const live = new Set(members().map(x => x.m.path)); S.sel = new Set([...S.sel].filter(p => live.has(p)));
    const s = st.summary || {}; $('v-c1').textContent = s.games ?? '—'; $('v-c2').textContent = s.groups ?? '—'; $('v-c3').textContent = s.old ?? '—'; $('v-c4').textContent = B(s.free || 0);
    render();
    if (wasRunning) notify(`Просмотр закончен: игр ${s.games}, старых версий ${s.old}`);
  }
  wasRunning = false;
}

async function poll() {
  const st = await api('/api/versions/state'); setState(st);
  if (st.running) { wasRunning = true; setTimeout(poll, 400); }
}

async function scan() {
  const root = $('v-root').value.trim(); localStorage.setItem('mh.vLayout', $('v-layout').value);
  const r = await api('/api/versions/scan', { root, layout: $('v-layout').value });
  if (r.error) { showErr(r.error); $('v-root').focus(); return; }
  showErr(''); S.sel.clear(); wasRunning = true; $('v-prog').hidden = false; $('v-prog').value = 2; poll();
}

async function reveal(p) { const r = await api('/api/versions/reveal', { path: p }); showErr(r.ok ? '' : 'Не удалось открыть проводник: папки уже нет или она не из этого списка'); }

const pick = pred => { S.sel = new Set(members().filter(x => OLD(x.m) && pred(x.g)).map(x => x.m.path)); render(); };

async function openTrash(opener) {
  const paths = [...S.sel], saves = await api('/api/versions/saves', { paths }), withSaves = Object.keys(saves);
  const chosen = members().filter(x => S.sel.has(x.m.path)), total = chosen.reduce((s, x) => s + x.m.size, 0), keepSel = chosen.filter(x => !OLD(x.m));
  const emptied = S.groups.filter(g => g.members.every(m => S.sel.has(m.path)));
  let h = `<p><b>${paths.length} шт. · ${B(total)}</b></p><pre class="vpre">${esc(paths.slice(0, 8).join('\n'))}${paths.length > 8 ? '\n… и ещё ' + (paths.length - 8) : ''}</pre>
    <p class="mu">${keepSel.length ? '' : 'Новейшие версии остаются. '}Корзина восстановима. Сохранения внутри архивов не проверяются.</p>`;
  if (keepSel.length) h += `<div class="vwarn" role="group" aria-labelledby="vWarnH"><p id="vWarnH"><b>Вы выбрали актуальные версии (${keepSel.length}):</b></p><pre class="vpre">${esc(keepSel.slice(0, 6).map(x => x.g.title + ' · ' + x.m.version).join('\n'))}${keepSel.length > 6 ? '\n… и ещё ' + (keepSel.length - 6) : ''}</pre>
    ${emptied.length ? `<p><b>У ${emptied.length} ${plural(emptied.length, ['игры', 'игр', 'игр'])} не останется ни одной версии.</b></p>` : ''}<label class="vradio"><input type="checkbox" id="vForce"><span>Понимаю, это актуальные версии, всё равно удалить</span></label></div>`;
  if (withSaves.length) h += `<fieldset class="vwarn"><legend><b>Найдены сохранения (версий: ${withSaves.length})</b></legend><pre class="vpre">${esc(withSaves.slice(0, 5).map(p => last(p) + ': ' + saves[p].slice(0, 2).join(', ')).join('\n'))}</pre>
    <label class="vradio"><input type="radio" name="vsv" value="copy" checked><span>Скопировать сохранения в оставшуюся версию, затем удалить</span></label>
    <label class="vradio"><input type="radio" name="vsv" value="skip"><span>Пропустить версии с сохранениями</span></label>
    <label class="vradio"><input type="radio" name="vsv" value="ignore"><span>Удалить вместе с сохранениями</span></label></fieldset>`;
  $('vTrashBody').innerHTML = h; $('vTrashYes').disabled = keepSel.length > 0;
  if (keepSel.length) $('vForce').addEventListener('change', () => { $('vTrashYes').disabled = !$('vForce').checked; });
  $('vTrashYes').onclick = async () => {
    const mode = (document.querySelector('input[name=vsv]:checked') || {}).value || 'skip'; closeDialog($('vTrashDlg'));
    const r = await api('/api/versions/trash', { paths, saves: mode, force: keepSel.length > 0 }), bad = r.results.filter(x => !x.ok);
    S.sel.clear(); setState(r.state);
    const done = r.results.length - bad.length;
    if (bad.length) showErr(`Не тронуто: ${bad.length}. ` + bad.slice(0, 3).map(x => last(x.path) + ' (' + x.msg + ')').join('; ')); else showErr('');
    notify(done ? `В Корзину отправлено: ${done}` : 'Ничего не удалено', done ? {} : { kind: 'error' }); $('v-selinfo').focus();
  };
  openDialog($('vTrashDlg'), opener);
}

// ---------- вкладки браузера ----------
const VL = { same: ['есть · та же версия', 'v-ok'], newer_pc: ['на ПК новее', 'v-ok'], update: ['обновить', 'v-upd'], unknown_ver: ['есть · версию не сравнить', 'v-man'], missing: ['нет на ПК', 'v-none'], unparsed: ['не разобрано', 'v-man'] };
const VORD = { update: 0, unknown_ver: 1, unparsed: 2, missing: 3, newer_pc: 4, same: 5 };
const isClose = (t, sureOnly) => (t.verdict === 'same' || t.verdict === 'newer_pc') && (!sureOnly || t.sure);
const tabText = t => [t.name, t.title, t.host, t.url, t.version, (t.local || {}).name, (t.local || {}).path, (VL[t.verdict] || [''])[0]].join(' ');

function tabsVisible() {
  const pq = parseQuery($('v-tq').value), c = TS.chips, vOn = c.close || c.update || c.missing;
  const out = TS.tabs.filter(t => {
    if (t.kind !== 'game') return c.other && (!pq.any || accepts(pq, tabText(t), null));
    if (vOn && !((c.close && isClose(t, false)) || (c.update && t.verdict === 'update') || (c.missing && t.verdict === 'missing'))) return false;
    if (c.unsure && t.sure) return false;
    return !pq.any || accepts(pq, tabText(t), null);
  });
  const by = $('v-tsort').value, nm = (a, b) => a.name.localeCompare(b.name, 'ru');
  out.sort((a, b) => by === 'name' ? nm(a, b) : by === 'site' ? a.host.localeCompare(b.host) || nm(a, b) : ((VORD[a.verdict] ?? 9) - (VORD[b.verdict] ?? 9)) || nm(a, b));
  return { pq, out };
}

function renderTabs() {
  const { pq, out } = tabsVisible();
  $('v-ttools').hidden = !TS.tabs.length;
  $('v-tcount').textContent = TS.tabs.length ? `Показано ${out.length} из ${TS.tabs.length}` : '';
  $('v-tlist').innerHTML = !out.length ? `<p class="empty">${TS.tabs.length ? 'Ничего не найдено: измените запрос или снимите фильтры.' : 'Выберите файл со вкладками: здесь появится сравнение с играми на ПК.'}</p>`
    : `<section class="vgrp" aria-label="Вкладки">` + out.map(t => {
      const v = VL[t.verdict] || ['прочее', 'v-man'], loc = t.local, sure = t.kind === 'game' && t.verdict && t.verdict !== 'missing' && t.verdict !== 'unparsed';
      return `<button type="button" class="vtrow" data-action="tab" data-i="${TS.tabs.indexOf(t)}" ${TS.cur === t.url ? 'aria-current="true"' : ''}><span><span class="vbadge ${v[1]}">${v[0]}</span></span>
        <span>${highlight(t.name || t.title, pq)} <b>${esc(t.version)}</b><span class="site">${esc(t.host || '—')}</span><span class="p">${highlight(t.url, pq)}</span></span>
        <span>${loc ? `${highlight(loc.name, pq)} <b>${esc(loc.version)}</b><span class="p">${highlight(loc.path, pq)}</span>` : '<span class="mu">нет на ПК</span>'}</span>
        <span aria-label="${sure ? (t.sure ? 'уверенно' : 'не уверен') : ''}">${sure ? (t.sure ? '✓' : '?') : ''}</span></button>`;
    }).join('') + '</section>';
  const s = TS.sum;
  if (s) { $('v-t1').textContent = s.total; $('v-t2').textContent = s.games; $('v-t3').textContent = s.have; $('v-t4').textContent = s.update; }
  const closeN = TS.tabs.filter(t => isClose(t, true)).length, updN = TS.tabs.filter(t => t.verdict === 'update').length;
  $('v-eclose').textContent = `Ссылки для закрытия (${closeN})`; $('v-eupd').textContent = `Список на обновление (${updN})`; $('v-ekeep').textContent = `Вкладки, которые остаются (${TS.tabs.length - closeN})`;
  ['v-eclose', 'v-eupd', 'v-ekeep'].forEach(id => { $(id).disabled = !TS.tabs.length; });
}

async function loadTabs(text, name) {
  const r = await api('/api/versions/tabs', { text });
  if (r.error) { $('v-tname').textContent = r.error; notify(r.error, { kind: 'error' }); return; }
  TS.tabs = r.tabs; TS.sum = r.summary; TS.cur = '';
  const s = r.summary; $('v-tname').textContent = `${name || 'Вставленный текст'}: ${s.total} вкладок` + (s.dups ? `, дублей убрано ${s.dups}` : '') + `, игровых ${s.games}, прочих ${s.other + s.service}`;
  renderTabs();
}

function tabDetail(t) {
  TS.cur = t.url; const v = VL[t.verdict] || ['прочее', 'v-man'], l = t.local;
  $('v-tdetail').innerHTML = `<h3>${esc(t.name || t.title)}</h3><span class="vbadge ${v[1]}">${v[0]}</span> <span class="mu">${esc(t.why)}</span>
    <dl><dt>Версия в теме</dt><dd>${esc(t.version || '—')}</dd><dt>Сайт</dt><dd>${esc(t.host || '—')}</dd><dt>Название взято</dt><dd>${esc(t.source || '—')}</dd>
    <dt>Адрес</dt><dd><a href="${esc(t.url)}" target="_blank" rel="noopener noreferrer">${esc(t.url)}</a></dd>`
    + (l ? `<dt>На ПК</dt><dd>${esc(l.name)} ${esc(l.version)}${l.count > 1 ? ' (всего версий: ' + l.count + ')' : ''}</dd><dt>Путь</dt><dd>${esc(l.path)}</dd>` : '') + '</dl>';
  renderTabs();
}

function exportText(name, text, what) {
  const n = text ? text.split('\n').length : 0, done = ok => { $('v-tmsg').textContent = `${what}: ${n} строк, ${ok ? 'скопировано и сохранено в файл' : 'сохранено в файл'}`; };
  const a = document.createElement('a'); a.href = URL.createObjectURL(new Blob(['\ufeff' + text], { type: 'text/plain;charset=utf-8' })); a.download = name; a.click();
  setTimeout(() => URL.revokeObjectURL(a.href), 4000);
  if (navigator.clipboard) navigator.clipboard.writeText(text).then(() => done(true), () => done(false)); else done(false);
}
const closeList = () => TS.tabs.filter(t => isClose(t, true));

// ---------- запуск ----------
export function showVersions() {
  if (loaded) { poll(); return; }
  loaded = true;
  $('v-layout').value = localStorage.getItem('mh.vLayout') || 'auto';
  api('/api/versions/state').then(st => { if (!$('v-root').value && st.root) $('v-root').value = st.root; setState(st); if (st.running) { wasRunning = true; poll(); } });
}

export function initVersions() {
  initTabs($('vtabs'), id => { $('vp-v').classList.toggle('hide', id !== 'v'); $('vp-t').classList.toggle('hide', id !== 't'); });
  api('/api/settings').then(c => { if (!$('v-root').value) $('v-root').value = c.games_root || ''; }).catch(() => {});
  $('v-scan').addEventListener('click', scan);
  $('v-root').addEventListener('keydown', e => { if (e.key === 'Enter') scan(); });
  delegate($('v-list'), 'click', {
    fold: el => { const k = el.dataset.key; S.closed.has(k) ? S.closed.delete(k) : S.closed.add(k); render(); const n = document.querySelector(`#v-list [data-action=fold][data-key="${CSS.escape(k)}"]`); if (n) n.focus(); },
    open: el => { detail(el.dataset.path); render(); const n = document.querySelector(`#v-list [data-action=open][data-path="${CSS.escape(el.dataset.path)}"]`); if (n) n.focus(); },
  });
  $('v-list').addEventListener('change', e => { const c = e.target.closest('[data-action=pick]'); if (!c) return; c.checked ? S.sel.add(c.dataset.path) : S.sel.delete(c.dataset.path); footer(); });
  $('v-list').addEventListener('dblclick', e => { const b = e.target.closest('[data-action=open]'); if (b) reveal(b.dataset.path); });
  delegate($('v-detail'), 'click', { reveal: el => reveal(el.dataset.path) });
  $('v-q').addEventListener('input', () => { clearTimeout(timer); timer = setTimeout(render, 120); });
  $('v-sort').addEventListener('change', render);
  $('v-chips').addEventListener('click', e => { const c = e.target.closest('[data-chip]'); if (!c) return; const k = c.dataset.chip; S.chips[k] = !S.chips[k]; c.setAttribute('aria-pressed', String(S.chips[k])); c.classList.toggle('on', S.chips[k]); render(); });
  $('v-selold').addEventListener('click', () => pick(() => true)); $('v-selsure').addEventListener('click', () => pick(g => g.sure)); $('v-selnone').addEventListener('click', () => { S.sel.clear(); render(); });
  $('v-trash').addEventListener('click', e => openTrash(e.currentTarget)); $('vTrashNo').addEventListener('click', () => closeDialog($('vTrashDlg')));
  // вкладки браузера
  $('v-tfile').addEventListener('change', e => { const f = e.target.files[0]; if (!f) return; const rd = new FileReader(); rd.onload = () => loadTabs(String(rd.result).replace(/^\ufeff/, ''), f.name); rd.readAsText(f, 'utf-8'); e.target.value = ''; });
  $('v-tpaste').addEventListener('click', e => openDialog($('vPasteDlg'), e.currentTarget)); $('vPasteNo').addEventListener('click', () => closeDialog($('vPasteDlg')));
  $('vPasteYes').addEventListener('click', () => { closeDialog($('vPasteDlg')); loadTabs($('v-ptext').value, ''); });
  $('v-tq').addEventListener('input', () => { clearTimeout(ttimer); ttimer = setTimeout(renderTabs, 120); }); $('v-tsort').addEventListener('change', renderTabs);
  $('v-tchips').addEventListener('click', e => { const c = e.target.closest('[data-chip]'); if (!c) return; const k = c.dataset.chip; TS.chips[k] = !TS.chips[k]; c.setAttribute('aria-pressed', String(TS.chips[k])); c.classList.toggle('on', TS.chips[k]); renderTabs(); });
  $('v-tlist').addEventListener('click', e => { const b = e.target.closest('[data-action=tab]'); if (!b) return; tabDetail(TS.tabs[+b.dataset.i]); const n = document.querySelector(`#v-tlist [data-i="${b.dataset.i}"]`); if (n) n.focus(); });
  $('v-eclose').addEventListener('click', () => exportText('tabs_to_close.txt', closeList().map(t => t.url).join('\n'), 'Ссылки для закрытия'));
  $('v-eupd').addEventListener('click', () => exportText('tabs_to_update.txt', TS.tabs.filter(t => t.verdict === 'update').map(t => `${t.name}: на ПК ${t.local.version || '?'} → в теме ${t.version} — ${t.url}`).join('\n'), 'Список на обновление'));
  $('v-ekeep').addEventListener('click', () => { const closed = new Set(closeList().map(t => t.url)); exportText('tabs_keep.txt', TS.tabs.filter(t => !closed.has(t.url)).map(t => t.line).join('\n'), 'Вкладки, которые остаются'); });
  document.addEventListener('keydown', e => {   // «/» переходит к поиску, если раздел открыт
    if (e.key !== '/' || e.ctrlKey || e.metaKey || e.altKey || $('gtab-ver').classList.contains('hide') || /^(INPUT|TEXTAREA|SELECT)$/.test(document.activeElement.tagName)) return;
    const q = $('vp-t').classList.contains('hide') ? $('v-q') : $('v-tq'); if (q.offsetParent) { e.preventDefault(); q.focus(); }
  });
}
