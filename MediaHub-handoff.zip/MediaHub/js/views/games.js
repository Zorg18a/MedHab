// Раздел «Игры»: библиотека как в Playnite, карточка игры в диалоге, вкладка «Версии и чистка».
import { $, qa, esc, delegate } from '../core/dom.js';
import { api } from '../core/api.js';
import { B, I } from '../core/fmt.js';
import { notify } from '../a11y/announce.js';
import { chipHtml } from '../ui/chip.js';
import { cardButtonHtml, bindCardKeys } from '../ui/cardbtn.js';
import { initTabs } from '../ui/tabs.js';
import { openDialog, closeDialog } from '../ui/dialog.js';
import { fieldError, clearFieldError } from '../ui/field.js';
import { poll } from './downloads.js';
import { initVersions, showVersions } from './versions.js';
import { metaHtml, bindMeta, badgesHtml, metaLabel } from '../ui/meta.js';

let GA = [], GF = 'all', GGEN = new Set(), GOPEN = 0, TAB = 'lib', tabs, LOC = [];
const GFILT = { all: 'Все', dl: 'Скачано', nodl: 'Не скачано', upd: 'Есть обновление', old: 'Старые версии', fav: 'Избранное', doing: 'Прохожу', done: 'Пройдено' };
const hue = s => { let x = 0; for (const c of String(s)) x = (x * 31 + c.charCodeAt(0)) % 360; return x; };
const initials = t => String(t).split(/\s+/).filter(Boolean).slice(0, 2).map(w => w[0]).join('').toUpperCase();
const ago = t => t ? new Date(t * 1000).toLocaleDateString('ru') : 'никогда';
const toDl = () => ({ action: { label: 'Загрузки', fn: () => { location.hash = '#downloads'; } } });
const cur = () => GA.find(y => y.id == GOPEN);
const ph = (x, extra = '') => `<div class="gph" style="${extra}background:linear-gradient(155deg,hsl(${hue(x.title)} 45% 32%),hsl(${(hue(x.title) + 50) % 360} 40% 14%))">${esc(initials(x.title))}</div>`;

export async function loadGames() {
  GA = (await api('/api/library?q=')).filter(x => x.kind === 'game');
  drawGames();
  if (GOPEN) { const x = cur(); if (x) fillPanel(x); }
}

function gdraw(x) {
  const g = x.g;
  return cardButtonHtml({
    cls: 'gcard', id: x.id, label: `${x.title}: ${g.downloaded ? 'скачано' : 'не скачано'}${g.update ? ', есть обновление' : ''}${metaLabel(x)}`,
    inner: `<div class="gart"${x.cover ? ` style="--cov:url('${esc(x.cover)}')"` : ''}>${x.cover ? `<img src="${esc(x.cover)}" alt="" loading="lazy">` : ph(x)}${badgesHtml(x)}${g.update ? '<span class="gup">Обновление</span>' : ''}<span class="gdot ${g.downloaded ? 'on' : 'off'}" aria-hidden="true">${g.downloaded ? I('<path d="M5 12.5l4.5 4.5L19 7.5"/>', 16).replace('stroke-width="1.8"', 'stroke-width="3"') : ''}</span></div><h3 class="gname" title="${esc(x.title)}">${esc(x.title)}</h3><p class="gsub">${esc(g.downloaded ? (g.version || 'скачано') : (g.latest || 'не скачано'))}${g.developer ? ' · ' + esc(g.developer) : ''}</p>`,
  });
}

function drawGames() {
  const q = $('gq').value.trim().toLowerCase(), cnt = { all: GA.length, dl: 0, nodl: 0, upd: 0, old: 0, fav: 0, doing: 0, done: 0 };
  GA.forEach(x => { x.g.downloaded ? cnt.dl++ : cnt.nodl++; if (x.g.update) cnt.upd++; if (x.g.old) cnt.old++; if (x.m.fav) cnt.fav++; if (x.m.status === 'doing') cnt.doing++; if (x.m.status === 'done') cnt.done++; });
  $('grep').classList.toggle('hide', !cnt.old); $('grep').textContent = `Заменить старые версии (${cnt.old})`;
  $('gchips').innerHTML = Object.keys(GFILT).filter(k => k === 'all' || cnt[k] || GF === k).map(k => chipHtml(GFILT[k], { pressed: GF === k, count: cnt[k], action: 'gf', value: k })).join('');
  const gc = {}; GA.forEach(x => x.g.genres.forEach(t => { const k = t.toLowerCase(); gc[k] = (gc[k] || [t, 0]); gc[k][1]++; }));
  $('genl').innerHTML = Object.keys(gc).sort((a, b) => gc[b][1] - gc[a][1] || a.localeCompare(b)).map(k => chipHtml(`${gc[k][0]} ${gc[k][1]}`, { pressed: GGEN.has(k), action: 'gen', value: k, cls: 'gchip' })).join('') || '<span class="mu">Жанры появятся, когда вы добавите игры из тем форума</span>';
  $('gens').textContent = GGEN.size ? `Жанры (${GGEN.size})` : 'Жанры';
  const L2 = GA.filter(x => GF === 'all' || (GF === 'dl' && x.g.downloaded) || (GF === 'nodl' && !x.g.downloaded) || (GF === 'upd' && x.g.update) || (GF === 'old' && x.g.old) || (GF === 'fav' && x.m.fav) || (GF === 'doing' && x.m.status === 'doing') || (GF === 'done' && x.m.status === 'done'))
    .filter(x => !q || (x.title + ' ' + x.g.developer + ' ' + x.g.genres.join(' ') + ' ' + x.m.tags.join(' ')).toLowerCase().includes(q))
    .filter(x => [...GGEN].every(k => x.g.genres.some(t => t.toLowerCase() === k)));
  const s = $('gso').value;
  L2.sort((a, b) => s === 'added' ? b.g.added - a.g.added : s === 'size' ? b.size - a.size : s === 'rating' ? (b.m.rating ?? -1) - (a.m.rating ?? -1) || a.title.localeCompare(b.title, 'ru') : s === 'release' ? String(b.g.release).localeCompare(String(a.g.release)) : s === 'upd' ? (b.g.update - a.g.update) || a.title.localeCompare(b.title, 'ru') : a.title.localeCompare(b.title, 'ru'));
  $('ggrid').innerHTML = L2.length ? L2.map(gdraw).join('')
    : GA.length ? '<div class="empty" style="margin:6vh 0"><h2>Ничего не найдено</h2><p>Измените поиск или фильтры.</p></div>'
      : '<div class="empty"><div class="stack"><i></i><i></i><i></i></div><h2>Игр пока нет</h2><p>Отправьте вкладку с темой игры из браузера (в «Входящих» выберите «Добавить игру в библиотеку») или вставьте ссылку на тему выше. Установленные игры из папки, указанной в настройках, тоже появятся здесь.</p></div>';
}

const RUS = { yes: 'Русский есть', voice: 'Русская озвучка', sub: 'Русские субтитры', no: 'Без русского', '?': 'Язык не указан' };
function srcHtml(g) {   // сборки с разных сайтов: у каждой своя версия, размер и язык, поэтому показываем их рядом
  if (!(g.sources || []).length) return '';
  const b = (u, label) => u ? `<button type="button" class="btn" data-action="sp" data-url="${esc(u)}">${esc(label)}</button>` : '';
  return `<h4 id="gsrch">Сборки и источники</h4><ul class="gsrc" aria-labelledby="gsrch" style="list-style:none;margin:0;padding:0;display:grid;gap:10px">${g.sources.map(s => `<li style="border:1px solid var(--line);border-radius:10px;padding:10px 12px">
 <div><b>${esc(s.name)}</b>${s.version ? ` · версия ${esc(s.version)}` : ''}${s.latest ? ` (на странице есть новее: ${esc(s.latest)})` : ''}</div>
 <div class="mu" style="font-size:.84rem;margin:4px 0 8px">${[s.size && 'размер ' + s.size, RUS[s.russian] || RUS['?'], s.language && 'язык: ' + s.language, s.censor && 'цензура: ' + s.censor, s.release_type, s.seeds ? 'сидов: ' + s.seeds : '', s.needs_login ? 'для скачивания нужен вход на сайт' : '', s.updated && 'обновлено ' + s.updated].filter(Boolean).map(esc).join(' · ')}</div>
 <div class="glk">${b(s.url, 'Открыть страницу')}${b(s.torrent, 'Скачать .torrent')}${b(s.magnet, 'Magnet')}</div></li>`).join('')}</ul>`;
}

function fillPanel(x) {
  const g = x.g, row = (k, v) => v ? `<dt>${k}</dt><dd>${esc(v)}</dd>` : '';
  const btn = (act, label, cls = 'btn') => `<button type="button" class="${cls}" data-action="${act}">${label}</button>`;
  $('gpanel').removeAttribute('aria-label'); $('gpanel').setAttribute('aria-labelledby', 'gpt');
  $('gpanel').innerHTML = `<div class="gtop">${x.cover ? `<img src="${esc(x.cover)}" alt="">` : ''}<button type="button" class="x gx" aria-label="Закрыть" data-action="close">${I('<path d="M6 6l12 12M18 6 6 18"/>', 18)}</button><div class="gmain">${x.cover ? `<img src="${esc(x.cover)}" alt="">` : ph(x, 'position:static;width:112px;height:168px;border-radius:8px;font-size:34px;')}<div><h2 id="gpt">${esc(x.title)}</h2><div class="mu">${esc(g.developer || '')}</div></div></div></div>
 <div class="gb"><div><span class="gpill ${g.downloaded ? 'ok' : ''}">${g.downloaded ? '✓ Скачано' : '○ Не скачано'}</span>${g.update ? `<span class="gpill up">Есть обновление: ${esc(g.latest)}</span>` : ''}${g.status ? `<span class="gpill">${esc(g.status)}</span>` : ''}${['yes', 'voice', 'sub'].includes(g.russian) ? `<span class="gpill ok">${RUS[g.russian]}</span>` : ''}</div>
 <div class="row" style="margin:10px 0 0">${g.downloaded ? btn('play', 'Играть', 'btn primary') + btn('exech', g.exe ? 'Сменить файл запуска' : 'Выбрать файл запуска') + btn('reveal', 'Показать в папке') : (g.links.length ? btn('links', 'Скачать', 'btn primary') : '')}${g.update && g.links.length ? btn('links', 'Обновить', 'btn primary') : ''}${g.thread ? btn('thread', 'Открыть тему') : ''}${g.thread ? btn('check', 'Проверить обновление') : ''}${g.downloaded ? '' : btn('locate', 'Проверить, скачана ли')}${g.old ? btn('repl', `Заменить старые версии (${g.old})`) : ''}</div><div id="glocate" role="status"></div><div id="gexe"></div>
 <h4>Сведения</h4><dl class="ginf">${row('У вас', g.downloaded ? g.version || 'версия не определена' : '')}${row('Последняя', g.latest)}${row('Версий на диске', g.downloaded ? String(g.versions) + (g.old ? ` (старых: ${g.old})` : '') : '')}${row('Размер', g.downloaded ? B(x.size) : '')}${row('Движок', g.engine)}${row('Система', g.os)}${row('Язык', g.language)}${row('Дата выхода', g.release)}${row('Добавлена', ago(g.added))}${row('Проверена', g.thread ? ago(g.checked) : '')}</dl>
 ${g.genres.length ? `<h4>Жанры</h4><div>${g.genres.map(t => chipHtml(t, { pressed: GGEN.has(t.toLowerCase()), action: 'pg', value: t.toLowerCase(), cls: 'gchip' })).join(' ')}</div>` : ''}
 ${(x.m.descr || g.desc) ? `<h4>Описание</h4><p style="margin:0;white-space:pre-line">${esc(x.m.descr || g.desc)}</p>` : ''}${x.m.tags.length ? `<h4>Мои теги</h4><div>${x.m.tags.map(t => `<span class="gchip">${esc(t)}</span>`).join(' ')}</div>` : ''}
 ${srcHtml(g)}
${g.links.length ? `<h4 id="glh">Скачать из</h4>${(() => { const gr = {}; g.links.forEach((l, i) => (gr[l.group || ''] ??= []).push([l, i])); return Object.keys(gr).map(k => `<div style="margin:0 0 10px">${k ? `<div class="mu" style="font-size:.78rem;margin:0 0 5px">${esc(k)}</div>` : ''}<div class="glk">${gr[k].map(([l, i]) => `<button type="button" class="btn" data-action="gl" data-i="${i}">${esc(l.label || l.host)}</button>`).join('')}</div></div>`).join(''); })()}<p class="mu" style="margin:6px 0 0;font-size:.78rem">Ссылка откроется в вашем браузере: вход, ожидание и капчу проходите сами. Адреса персональные и со временем устаревают: обновите карточку, чтобы получить свежие.</p>` : ''}
 ${(g.support || []).length ? `<h4>Автор</h4><div class="glk">${g.support.map(s => `<button type="button" class="btn" data-action="sp" data-url="${esc(s.url)}">${esc(s.label)}</button>`).join('')}</div>` : ''}
 ${metaHtml(x)}
<h4>Настройки</h4><label class="chkrow" style="color:var(--text)"><input type="checkbox" role="switch" class="sw" id="gauto" ${g.auto ? 'checked' : ''}> Следить за новыми версиями</label>
 <label class="field" style="margin-top:12px"><span>Заметка</span><textarea id="gnote" style="min-height:70px">${esc(g.note)}</textarea></label>
 ${g.path ? `<p class="mu" style="font-size:.78rem;margin:0 0 10px;overflow-wrap:anywhere">${esc(g.path)}</p>` : ''}${btn('drop', 'Убрать из библиотеки', 'btn danger')}</div>`;
}

function openPanel(id, opener) {
  const x = GA.find(y => y.id == id); if (!x) return;
  GOPEN = x.id; fillPanel(x); openDialog($('gpanel'), opener);
}
const closePanel = () => closeDialog($('gpanel'));

function gtab(t) {
  TAB = t;
  $('gtab-lib').classList.toggle('hide', t !== 'lib'); $('gtab-ver').classList.toggle('hide', t !== 'ver');
  if (t === 'ver') showVersions(); else loadGames();
}

export function openGames() { closePanel(); tabs.select(TAB); }

const refocus = (root, action, value) => { const n = document.querySelector(`${root} [data-action="${action}"][data-value="${value}"]`); if (n) n.focus(); };
const toggleGenre = k => { GGEN.has(k) ? GGEN.delete(k) : GGEN.add(k); };

const waitScan = async () => { for (let i = 0; i < 750; i++) { await new Promise(r => setTimeout(r, 800)); const s = await api('/api/game/scanstate'); if (!s.running) return s; } };

async function openRepl(only, opener) {   // окно подтверждения: что переедет, что уйдёт в Корзину
  const r = await api('/api/game/plans'), items = r.items.filter(p => !only || only.includes(p.id));
  if (!items.length) { notify(r.running ? 'Идёт просмотр папки, повторите через минуту' : 'Старых версий не найдено'); return; }
  $('repList').innerHTML = items.map(p => {
    const sv = p.olds.reduce((n, o) => n + o.saves, 0), tl = p.olds.some(o => o.tl.length);
    return `<li class="gu"><input type="checkbox" id="rp${p.id}" data-id="${p.id}" ${p.can && p.sure ? 'checked' : ''} ${p.can ? '' : 'disabled'}><div><h3><label for="rp${p.id}">${esc(p.title)}</label></h3><p>Остаётся: <b>${esc(p.keeper.name)}</b> (${esc(p.keeper.version)})</p><p>Уйдут в Корзину: ${p.olds.map(o => esc(o.name)).join(', ')}</p><p>Сохранений перенесётся: ${sv}${tl ? (p.tl_in_keeper ? '. Русский перевод в новой версии уже есть, его не трогаю' : '. Русский перевод найден и будет перенесён') : ''}</p>${p.why ? `<p class="warn">${esc(p.why)}</p>` : ''}${p.notes.map(n => `<p class="warn">${esc(n)}</p>`).join('')}</div></li>`;
  }).join('');
  openDialog($('repDlg'), opener);
}

async function runGame(x, btnEl) {   // запуск только по нажатию; ошибка текстом и уведомлением
  const r = await api('/api/game/play', { id: x.id });
  if (r.error) { notify(r.error, { kind: 'error' }); await showExe(false, r.error); return; }
  notify(`Запускаю: ${r.name}`); if (btnEl) btnEl.focus();
}

async function showExe(play, err) {   // список файлов запуска: выбрать и запомнить на карточке
  const x = cur(), box = $('gexe'); box.dataset.play = play ? '1' : '0'; box.textContent = 'Ищу файлы запуска…'; box.setAttribute('role', 'status');
  const r = await api('/api/game/exes', { id: x.id });
  if (r.error) { box.removeAttribute('role'); box.innerHTML = `<p class="mu" role="alert">${esc(r.error)}</p>`; return; }
  if (!r.found.length) { box.removeAttribute('role'); box.innerHTML = '<p class="mu" role="alert">В папке игры нет файлов .exe или .bat (глубже трёх уровней не ищу).</p>'; return; }
  box.removeAttribute('role');
  box.innerHTML = `<div class="gexe"><label for="gexesel">Файл запуска</label><select id="gexesel" aria-describedby="gexeerr">${r.found.map(e => `<option value="${esc(e.rel)}" ${e.rel === r.exe ? 'selected' : ''}>${esc(e.rel)}</option>`).join('')}</select><button type="button" class="btn primary" data-action="exego">${play ? 'Запомнить и играть' : 'Запомнить'}</button><p class="mu" id="gexeerr" role="alert">${err ? esc(err) : ''}</p></div>`;
  $('gexesel').focus();
}

export function initGames() {
  tabs = initTabs($('v-games').querySelector('[role=tablist]'), id => gtab(id)); initVersions();
  $('gpanel').addEventListener('close', () => { GOPEN = 0; });
  $('gq').addEventListener('input', drawGames); $('gso').addEventListener('change', drawGames);
  delegate($('gchips'), 'click', { gf: el => { GF = el.dataset.value; drawGames(); refocus('#gchips', 'gf', GF); } });
  delegate($('genl'), 'click', { gen: el => { const k = el.dataset.value; toggleGenre(k); drawGames(); refocus('#genl', 'gen', k); } });
  $('ggrid').addEventListener('click', e => { const c = e.target.closest('[data-card]'); if (c) openPanel(c.dataset.id, c); });
  bindCardKeys($('ggrid'));
  $('gadd').addEventListener('input', () => { clearFieldError($('gadd')); $('gadd').style.height = 'auto'; $('gadd').style.height = Math.min($('gadd').scrollHeight + 2, 160) + 'px'; });
  $('gaddb').addEventListener('click', async () => {
    const urls = [...new Set(($('gadd').value.match(/https?:\/\/\S+/g) || []).map(u => u.replace(/[),.;]+$/, '')))], anchor = $('gadd').parentElement.parentElement;
    if (!urls.length) { fieldError($('gadd'), 'Вставьте ссылку на тему игры (можно несколько, каждую с новой строки)', anchor); return; }
    const r = await api('/api/game/add', { urls });
    if (r.error) { fieldError($('gadd'), r.error, anchor); return; }
    $('gadd').value = ''; $('gadd').style.height = ''; poll();
    notify(r.count > 1 ? `Добавляю игры: ${r.count}. Читаю страницы по одной в вашем браузере…` : 'Читаю страницу в вашем браузере…', toDl());
  });
  $('gscan').addEventListener('click', async () => {
    const r = await api('/api/game/rescan', {}); if (r.error) { notify(r.error, { kind: 'error' }); return; }
    notify('Смотрю папку игр…'); await waitScan(); await loadGames(); notify('Готово: список скачанных игр обновлён');
  });
  $('grep').addEventListener('click', e => openRepl(null, e.currentTarget));
  $('repC').addEventListener('click', () => closeDialog($('repDlg')));
  $('repGo').addEventListener('click', async () => {
    const ids = qa('#repList input:checked').map(i => +i.dataset.id); if (!ids.length) { notify('Ничего не выбрано', { kind: 'error' }); return; }
    const r = await api('/api/game/replace', { ids, confirm: true, delete_old: $('repDel').checked });
    closeDialog($('repDlg')); if (r.error) { notify(r.error, { kind: 'error' }); return; }
    poll(); notify(`Заменяю версии: ${r.count}. Ход работы в «Загрузках»`, toDl());
  });
  bindMeta($('gpanel'), () => cur(), (x, what) => { drawGames(); if (what === 'cover') { fillPanel(x); const b = $('gpanel').querySelector('[data-m=cover]'); if (b) b.focus(); } });
  $('gchk').addEventListener('click', async () => { await api('/api/game/check', {}); poll(); notify('Проверка запущена: по одной теме с паузой', toDl()); });
  const dlg = $('gpanel');
  dlg.addEventListener('click', e => {
    if (e.target !== dlg) return;
    const r = dlg.getBoundingClientRect();
    if (e.clientX < r.left || e.clientX > r.right || e.clientY < r.top || e.clientY > r.bottom) closePanel();
  });
  delegate(dlg, 'click', {
    close: closePanel,
    play: async el => { const x = cur(); if (!x.g.exe) { await showExe(true); return; } await runGame(x, el); },
    exech: () => showExe(false),
    exego: async () => {
      const x = cur(), sel = $('gexesel'), box = $('gexe'); if (!sel || !sel.value) return;
      const r = await api('/api/game/exe', { id: x.id, exe: sel.value });
      if (r.error) { $('gexeerr').textContent = r.error; sel.setAttribute('aria-invalid', 'true'); sel.focus(); return; }
      x.g.exe = r.exe; const go = box.dataset.play === '1'; box.innerHTML = ''; fillPanel(x);
      const b = dlg.querySelector('[data-action="play"]'); if (b) b.focus();
      if (go) await runGame(x, b); else notify('Файл запуска запомнен');
    },
    reveal: async () => { const r = await api('/api/reveal', { id: cur().id }); notify(r.ok ? 'Открываю в проводнике' : 'Не удалось открыть: папки нет на месте', r.ok ? {} : { kind: 'error' }); },
    thread: () => window.open(cur().g.thread, '_blank', 'noopener'),
    check: async () => { await api('/api/game/check', { id: cur().id }); poll(); notify('Проверяю тему в вашем браузере…', toDl()); },
    locate: async () => {
      const x = cur(), box = $('glocate'); box.textContent = 'Ищу в папке игр…';
      const r = await api('/api/game/locate', { id: x.id }); if (r.error) { box.textContent = r.error; return; }
      LOC = r.found; waitScan().then(async () => { await loadGames(); const y = cur(); if (y && y.g.downloaded) { fillPanel(y); notify('Игра найдена: скачана'); } });
      const why = (r.why || []).map(w => `<p class="mu" style="margin:8px 0 0">${esc(w)}</p>`).join('');
      box.innerHTML = (r.found.length
        ? `<p class="mu" style="margin:10px 0 0">Нашёл в папке игр похожие. Если это нужная, привяжите её:</p><ul class="gfound">${r.found.map((c, i) => `<li><span><b>${esc(c.name)}</b>${c.version ? ' · ' + esc(c.version) : ''}<br><small class="mu">совпадение ${Math.round(c.score * 100)}%</small></span><button type="button" class="btn" data-action="link" data-i="${i}">Это она</button></li>`).join('')}</ul>`
        : '<p class="mu" style="margin:10px 0 0">Ничего похожего не нашёл. Игра должна лежать в папке, указанной в «Настройках» (или в её подпапке new1, new2…).</p>') + why;
    },
    link: async el => {
      const x = cur(), c = LOC[+el.dataset.i], r = await api('/api/game/link', { id: x.id, path: c.path }); if (r.error) { notify(r.error, { kind: 'error' }); return; }
      notify('Привязано, обновляю список…'); await waitScan(); await loadGames(); const y = cur(); if (y) { fillPanel(y); const b = $('gpanel').querySelector('h2'); if (b) b.focus && b.setAttribute('tabindex', '-1'), b.focus(); }
    },
    repl: el => openRepl([cur().id], el),
    links: () => { const t = $('glh'); if (t) t.scrollIntoView({ behavior: 'smooth' }); },
    drop: async () => { const x = cur(); await api('/api/delete', { id: x.id, files: false }); closePanel(); loadGames(); notify('Убрано из библиотеки'); },
    gl: el => window.open(cur().g.links[+el.dataset.i].url, '_blank', 'noopener'),
    sp: el => window.open(el.dataset.url, '_blank', 'noopener'),
    pg: el => { toggleGenre(el.dataset.value); closePanel(); drawGames(); },
  });
  dlg.addEventListener('change', async e => {
    const x = cur();
    if (x && e.target.id === 'gauto') { await api('/api/game/set', { id: x.id, auto: e.target.checked }); x.g.auto = e.target.checked; notify('Сохранено'); }
  });
  dlg.addEventListener('focusout', async e => {
    const x = cur();
    if (x && e.target.id === 'gnote' && e.target.value !== x.g.note) { await api('/api/game/set', { id: x.id, note: e.target.value }); x.g.note = e.target.value; notify('Заметка сохранена'); }
  });
}
