// Поиск по списку: слова через пробел, «-слово» исключает, «>500мб» и «<2гб» по размеру. Находит слитное написание (slaveofpassion),
// чужую раскладку (ыдфму), опечатки в словах от 4 букв; числа и версии сравниваются только точно. Без DOM: проверяется в Node.
export const norm = s => String(s).toLowerCase().replace(/[^\p{L}\p{N}]+/gu, ' ').trim();
const RU = 'йцукенгшщзфывапролдячсмить', EN = 'qwertyuiopasdfghjklzxcvbnm', LAY = {};
for (let i = 0; i < RU.length; i++) { LAY[RU[i]] = EN[i]; LAY[EN[i]] = RU[i]; }
const UNIT = { 'б': 1, b: 1, 'кб': 1024, kb: 1024, k: 1024, 'мб': 1048576, mb: 1048576, m: 1048576, 'гб': 1073741824, gb: 1073741824, g: 1073741824 };
const esc = s => String(s).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));

export function parseQuery(q) {
  const pq = { terms: [], raw: [], nots: [], sizes: [], any: false };
  for (const tok of String(q).trim().split(/\s+/).filter(Boolean)) {
    const m = tok.match(/^([<>])(\d+(?:[.,]\d+)?)\s*(б|кб|мб|гб|b|kb|mb|gb|k|m|g)?$/i);
    if (m) pq.sizes.push([m[1], parseFloat(m[2].replace(',', '.')) * UNIT[(m[3] || 'мб').toLowerCase()]]);
    else if (tok[0] === '-' && tok.length > 1) { const n = norm(tok.slice(1)); if (n) pq.nots.push(n); }
    else if (norm(tok)) { pq.terms.push(norm(tok)); pq.raw.push(tok.toLowerCase()); }
  }
  pq.any = !!(pq.terms.length || pq.nots.length || pq.sizes.length);
  return pq;
}

function lev(a, b) {
  if (a === b) return 0; if (!a.length) return b.length; if (!b.length) return a.length;
  let prev = Array.from({ length: b.length + 1 }, (_, i) => i);
  for (let i = 1; i <= a.length; i++) {
    const cur = [i];
    for (let j = 1; j <= b.length; j++) cur[j] = Math.min(cur[j - 1] + 1, prev[j] + 1, prev[j - 1] + (a[i - 1] !== b[j - 1] ? 1 : 0));
    prev = cur;
  }
  return prev[b.length];
}

function termIn(t, text, compact, words) {
  if (text.includes(t) || compact.includes(t.replace(/ /g, ''))) return true;      // слитно: slaveofpassion
  const sw = [...t].map(c => LAY[c] || c).join('');                                  // чужая раскладка: ыдфму
  if (sw !== t && text.includes(sw)) return true;
  if (/^\p{L}{4,}$/u.test(t)) {                                                      // опечатка; цифры только точно
    const tol = t.length <= 6 ? 1 : 2;
    return words.some(w => Math.abs(w.length - t.length) <= tol && lev(t, w) <= tol);
  }
  return false;
}

export function accepts(pq, text, size) {
  const n = norm(text), compact = n.replace(/ /g, ''), words = n.split(' ');
  if (pq.nots.some(x => n.includes(x))) return false;
  if (!pq.terms.every(t => termIn(t, n, compact, words))) return false;
  return pq.sizes.every(([op, v]) => size != null && (op === '>' ? size > v : size < v));
}

// Подсвечиваем только прямые вхождения слов запроса; весь текст экранируется.
export function highlight(text, pq) {
  const src = String(text), low = src.toLowerCase(), r = [];
  for (const t of pq.raw) { let i = low.indexOf(t); while (t && i >= 0) { r.push([i, i + t.length]); i = low.indexOf(t, i + t.length); } }
  r.sort((a, b) => a[0] - b[0]);
  let out = '', pos = 0;
  for (const [s, e] of r) { if (e <= pos) continue; const st = Math.max(s, pos); out += esc(src.slice(pos, st)) + '<mark>' + esc(src.slice(st, e)) + '</mark>'; pos = e; }
  return out + esc(src.slice(pos));
}
