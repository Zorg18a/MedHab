export const $ = id => document.getElementById(id);
export const qa = sel => [...document.querySelectorAll(sel)];
export const esc = s => String(s ?? '').replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));

// Делегирование: обработчики ищутся по ближайшему элементу с data-action.
export function delegate(root, event, handlers) {
  root.addEventListener(event, e => {
    const el = e.target.closest && e.target.closest('[data-action]');
    if (!el || !root.contains(el)) return;
    const fn = handlers[el.dataset.action];
    if (fn) fn(el, e);
  });
}
