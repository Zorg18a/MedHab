import { $ } from './dom.js';
import { api } from './api.js';
import { B } from './fmt.js';

export async function disk() {
  const d = await api('/api/disk');
  $('disk').innerHTML = `Свободно ${B(d.free)}<div class="meter"><i style="width:${Math.round(d.used * 100 / d.total)}%"></i></div>`;
}
