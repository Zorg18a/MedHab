// Запросы к серверу MediaHub. Сбой сети переводит приложение в офлайн и сообщает слушателям.
let online = true;
const listeners = [];

export function onConnection(fn) { listeners.push(fn); }

function setOnline(v) {
  if (v === online) return;
  online = v;
  if (window.MH) window.MH.__online = v;
  listeners.forEach(f => f(v));
}

export async function api(url, body) {
  let r;
  try { r = await fetch(url, body && { method: 'POST', body: JSON.stringify(body), headers: { 'X-MH': '1' } }); }
  catch { setOnline(false); throw new Error('offline'); }
  setOnline(true);
  return r.json();
}

// Опрос раз в секунду, в офлайне раз в 5 секунд; ошибки внутри fn не прерывают цикл.
export function startPolling(fn) {
  const tick = async () => {
    try { await fn(); } catch { /* офлайн: повторим позже */ }
    setTimeout(tick, online ? 1000 : 5000);
  };
  tick();
}
