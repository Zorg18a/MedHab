// Горячие клавиши плеера. Читаются на каждое нажатие, не срабатывают при вводе текста, модификаторах и открытом диалоге.
import { isTyping } from '../a11y/keys.js';

const BY_KEY = { k: 'toggle', j: 'back', l: 'fwd', '[': 'slower', ']': 'faster', c: 'subs', m: 'mute', f: 'full', '?': 'help' };
const BY_CODE = { KeyK: 'toggle', KeyJ: 'back', KeyL: 'fwd', BracketLeft: 'slower', BracketRight: 'faster', KeyC: 'subs', KeyM: 'mute', KeyF: 'full' };

// Для не-латинской раскладки (русской) работает физическая клавиша; для латинских раскладок только символ.
export function keyAction(e) {
  if (e.ctrlKey || e.altKey || e.metaKey) return null;
  const key = e.key || '';
  if (/^[a-z]$/i.test(key) || key in BY_KEY) return BY_KEY[key.toLowerCase()] ?? null;
  return BY_CODE[e.code] ?? null;
}

export function nextSpeed(cur, dir) { return Math.min(2, Math.max(0.5, Math.round((cur + dir * 0.25) * 4) / 4)); }
// -1 означает «субтитры выключены»: выкл → 0 → … → count-1 → выкл
export function nextTrack(count, cur) { const n = cur + 1; return n >= count ? -1 : n; }

export function initPlayerKeys(d) {
  const m = d.media;
  document.addEventListener('fullscreenchange', () => d.announce(document.fullscreenElement ? 'Полный экран' : 'Обычный размер'));
  document.addEventListener('keydown', e => {
    if (e.defaultPrevented || !d.enabled()) return;
    const a = keyAction(e);
    if (!a || isTyping(document.activeElement) || document.querySelector('dialog[open]')) return;
    if (a === 'full' && m.tagName !== 'VIDEO') return;
    e.preventDefault();   // иначе встроенные клавиши элемента (k, m, f) сработают второй раз
    if (a === 'toggle') {
      if (m.paused) m.play().then(() => d.announce('Воспроизведение'), () => {});
      else { m.pause(); d.announce('Пауза'); }
    } else if (a === 'back' || a === 'fwd') {
      const dur = Number.isFinite(m.duration) ? m.duration : Infinity;
      m.currentTime = Math.min(Math.max(m.currentTime + (a === 'fwd' ? 10 : -10), 0), dur);
      d.announce(`${a === 'fwd' ? 'Вперёд' : 'Назад'} на 10 секунд, ${d.fmt(m.currentTime)}`);
    } else if (a === 'slower' || a === 'faster') {
      m.playbackRate = nextSpeed(m.playbackRate, a === 'faster' ? 1 : -1); d.announce(`Скорость ${m.playbackRate}`);
    } else if (a === 'subs') {
      const tr = [...m.textTracks];
      if (!tr.length) return d.announce('Субтитров нет');
      const next = nextTrack(tr.length, tr.findIndex(t => t.mode === 'showing'));
      tr.forEach((t, k) => { t.mode = k === next ? 'showing' : 'disabled'; });
      d.announce(next < 0 ? 'Субтитры выключены' : `Субтитры: ${tr[next].label}`);
    } else if (a === 'mute') {
      m.muted = !m.muted; d.announce(m.muted ? 'Звук выключен' : 'Звук включён');
    } else if (a === 'full') {
      if (document.fullscreenElement) document.exitFullscreen(); else if (document.fullscreenEnabled) m.requestFullscreen().catch(() => {});
    } else if (a === 'help') d.openHelp();
  });
}
