// Страница плеера /p/<id>: данные с /api/play/<id>, элемент video|audio, дорожки субтитров, сообщения об ошибках.
import { $, esc } from '../core/dom.js';
import { announce } from '../a11y/announce.js';
import { loadPrefs } from '../a11y/prefs.js';
import { openDialog, closeDialog } from '../ui/dialog.js';
import { initPlayerKeys } from './keys.js';

export function fmtTime(sec) {
  sec = Number.isFinite(sec) && sec > 0 ? Math.floor(sec) : 0;
  const h = Math.floor(sec / 3600), m = Math.floor(sec % 3600 / 60), s = sec % 60;
  return h ? `${h}:${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}` : `${m}:${String(s).padStart(2, '0')}`;
}

const LANG = /^[a-z]{2,3}(-[A-Za-z0-9]+)*$/;
export function trackHtml(subs) {
  return (subs || []).map(s => `<track kind="subtitles" src="${esc(s.url)}" label="${esc(s.label)}"${LANG.test(s.lang || '') ? ` srclang="${esc(s.lang)}"` : ''}>`).join('');
}

export function shouldResume(pos, finished) { return pos >= 5 && !finished; }

const SAVE_MS = 5000, MIN_POS = 5, MIN_MOVE = 1;
function defaultSend(body) {
  fetch('/api/play/pos', { method: 'POST', keepalive: true, headers: { 'X-MH': '1', 'Content-Type': 'application/json' }, body: JSON.stringify(body) }).catch(() => {});
}
// Сохранение позиции: раз в 5 с во время воспроизведения (если сдвиг не меньше секунды), на паузе, в конце и при закрытии страницы.
export function startSaver(media, id, send = defaultSend) {
  let last = -1;
  const push = force => {
    const t = media.currentTime;
    if (!Number.isFinite(t) || t < MIN_POS) return;
    if (force ? t === last : Math.abs(t - last) < MIN_MOVE) return;
    last = t; send({ id: Number(id), pos: t, dur: Number.isFinite(media.duration) ? media.duration : 0 });
  };
  const tick = () => { if (!media.paused && !media.ended) push(false); };
  const flush = () => push(true);
  const timer = setInterval(tick, SAVE_MS);
  media.addEventListener('pause', flush); media.addEventListener('ended', flush); addEventListener('pagehide', flush);
  return { flush, stop() { clearInterval(timer); media.removeEventListener('pause', flush); media.removeEventListener('ended', flush); removeEventListener('pagehide', flush); } };
}

function showError(html) { const e = $('err'); e.innerHTML = html; }

export async function initPlayer() {
  const id = location.pathname.split('/')[2];
  $('skip').addEventListener('click', () => $('main').focus());
  let play = null;
  try { const r = await fetch('/api/play/' + id); if (r.ok) play = await r.json(); } catch (e) { /* ниже покажем «не найден» */ }
  if (!play) {
    document.title = 'Материал не найден — MediaHub'; $('t').textContent = 'Материал не найден';
    showError('Материал не найден'); return;
  }
  document.title = `${play.title} — MediaHub`; $('t').textContent = play.title;
  const m = document.createElement(play.kind === 'video' ? 'video' : 'audio');
  m.id = 'm'; m.className = 'pl-media'; m.controls = true; m.preload = 'metadata';
  m.setAttribute('aria-label', play.title);
  m.addEventListener('error', () => showError(`Не удалось воспроизвести файл. <a href="${esc(play.src)}">Открыть файл напрямую</a>`));
  m.insertAdjacentHTML('beforeend', trackHtml(play.subs));
  const restart = $('restart');
  m.addEventListener('loadedmetadata', () => {
    if (shouldResume(play.pos, play.finished)) {
      m.currentTime = play.pos; restart.hidden = false; announce(`Продолжаю с ${fmtTime(play.pos)}`);
    }
    m.dataset.ready = '1';
  }, { once: true });
  restart.addEventListener('click', () => {
    m.currentTime = 0; restart.hidden = true; announce('С начала'); m.focus();
    fetch('/api/play/forget', { method: 'POST', headers: { 'X-MH': '1', 'Content-Type': 'application/json' }, body: JSON.stringify({ id: Number(id) }) }).catch(() => {});
  });
  startSaver(m, id);
  const help = () => openDialog($('helpDlg'));
  $('helpBtn').addEventListener('click', help); $('helpClose').addEventListener('click', () => closeDialog($('helpDlg')));
  initPlayerKeys({ media: m, enabled: () => loadPrefs().keys !== false, announce, fmt: fmtTime, openHelp: help });
  m.src = play.src;
  const stage = $('stage');
  if (play.kind === 'audio' && play.cover) stage.insertAdjacentHTML('beforeend', `<img class="pl-cover" alt="" src="${esc(play.cover)}">`);
  stage.append(m);
}

if ($('stage')) initPlayer();
