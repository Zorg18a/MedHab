// Горячие клавиши: последовательности g+буква, j/k по карточкам, / поиск, ? справка.
const NAV = { l: 'nav:library', i: 'nav:inbox', d: 'nav:downloads', g: 'nav:games', s: 'nav:settings', n: 'log' };

export function createSequencer(timeoutMs = 1500) {
  let pending = false, at = 0;
  return {
    feed(key, now) {
      if (pending && now - at > timeoutMs) pending = false;
      if (pending) { pending = false; return NAV[key] ?? null; }
      if (key === 'g') { pending = true; at = now; }
      return null;
    },
  };
}

export const isTyping = el => !!el && (/^(INPUT|TEXTAREA|SELECT)$/.test(el.tagName) || el.isContentEditable);

export function initKeys({ enabled, go, focusSearch, openLog, openHelp }) {
  const seq = createSequencer();
  addEventListener('keydown', e => {
    if (!enabled() || e.ctrlKey || e.altKey || e.metaKey || e.defaultPrevented) return;
    if (isTyping(document.activeElement) || document.querySelector('dialog[open]')) return;
    if (e.key === '/') { e.preventDefault(); focusSearch(); return; }
    if (e.key === '?') { e.preventDefault(); openHelp(); return; }
    if (e.key === 'j' || e.key === 'k') {
      const cards = [...document.querySelectorAll('#main [data-card], #main .cv, #main .gcard')].filter(c => c.offsetParent);
      if (!cards.length) return;
      const i = cards.indexOf(document.activeElement);
      const next = e.key === 'j' ? (i < 0 ? 0 : Math.min(i + 1, cards.length - 1)) : (i < 0 ? 0 : Math.max(i - 1, 0));
      e.preventDefault(); cards[next].focus(); return;
    }
    const r = seq.feed(e.key, performance.now());
    if (!r) return;
    e.preventDefault();
    if (r === 'log') openLog(); else go(r.slice(4));
  });
}
