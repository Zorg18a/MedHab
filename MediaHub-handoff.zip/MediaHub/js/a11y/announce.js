// Центр уведомлений: одна точка входа для сообщений (живые области, тосты, журнал).
import { $, esc } from '../core/dom.js';

const MAX_LOG = 50, MAX_TOASTS = 3, TOAST_MS = 8000;
const log = [];
const toasts = new Map(); // id -> {el, timer}
let nextId = 1, unread = 0;

export function announce(text, kind = 'polite') {
  const el = $(kind === 'assertive' ? 'mh-live-assertive' : 'mh-live-polite');
  if (!el) return;
  el.textContent = el.textContent === text ? text + '\u00A0' : text; // повтор того же текста тоже озвучивается
}

export function dismiss(id) {
  const t = toasts.get(id);
  if (!t) return;
  clearTimeout(t.timer); t.el.remove(); toasts.delete(id);
}

function arm(id, sticky) {
  const t = toasts.get(id);
  if (!t || sticky) return;
  clearTimeout(t.timer);
  t.timer = setTimeout(() => dismiss(id), TOAST_MS);
}

export function notify(text, opts = {}) {
  const kind = opts.kind === 'error' ? 'error' : 'info', sticky = !!opts.sticky || kind === 'error', id = nextId++;
  log.push({ id, text: String(text), kind, ts: Date.now(), action: opts.action ? { label: opts.action.label } : undefined, fn: opts.action && opts.action.fn });
  if (log.length > MAX_LOG) log.shift();
  unread++; badge();
  announce(String(text), kind === 'error' ? 'assertive' : 'polite');

  const box = $('toastBox'); if (!box) return id;
  const el = document.createElement('div');
  el.className = 'toast' + (kind === 'error' ? ' err' : '');
  const span = document.createElement('span'); span.textContent = String(text); el.append(span);
  if (opts.action) {
    const b = document.createElement('button'); b.type = 'button'; b.textContent = opts.action.label;
    b.addEventListener('click', () => { opts.action.fn(); dismiss(id); });
    el.append(b);
  }
  if (sticky) {
    const x = document.createElement('button'); x.type = 'button'; x.className = 'tx'; x.setAttribute('aria-label', 'Закрыть уведомление'); x.textContent = '×';
    x.addEventListener('click', () => dismiss(id)); el.append(x);
  }
  const pause = () => { const t = toasts.get(id); if (t) clearTimeout(t.timer); };
  el.addEventListener('mouseenter', pause); el.addEventListener('focusin', pause);
  el.addEventListener('mouseleave', () => arm(id, sticky)); el.addEventListener('focusout', () => arm(id, sticky));
  box.append(el); toasts.set(id, { el, timer: 0 }); arm(id, sticky);
  while (toasts.size > MAX_TOASTS) dismiss(toasts.keys().next().value);
  return id;
}

export const getLog = () => log.map(({ fn, ...e }) => ({ ...e }));

function badge() {
  const n = $('bellN'); if (!n) return;
  n.textContent = unread > 99 ? '99+' : String(unread); n.classList.toggle('hide', !unread);
  const b = $('bellBtn'); if (b) b.setAttribute('aria-label', unread ? `Уведомления: новых ${unread}` : 'Уведомления');
}

export function openLog() {
  const dlg = $('logDlg'); if (!dlg) return;
  const t = ts => new Date(ts).toLocaleTimeString('ru', { hour: '2-digit', minute: '2-digit' });
  $('logList').innerHTML = log.length
    ? [...log].reverse().map(e => `<li class="le${e.kind === 'error' ? ' err' : ''}"><span class="lt">${t(e.ts)}</span><span class="lm">${esc(e.text)}</span>${e.action ? `<button type="button" class="btn quiet" data-lid="${e.id}">${esc(e.action.label)}</button>` : ''}</li>`).join('')
    : '<li class="mu">Пока ничего</li>';
  unread = 0; badge();
  if (!dlg.open) dlg.showModal();
}

export function initNotifications() {
  $('bellBtn').addEventListener('click', openLog);
  $('logX').addEventListener('click', () => $('logDlg').close());
  $('logList').addEventListener('click', e => {
    const b = e.target.closest('[data-lid]'); if (!b) return;
    const en = log.find(x => x.id === +b.dataset.lid);
    $('logDlg').close(); if (en && en.fn) en.fn();
  });
  addEventListener('keydown', e => {
    if (e.key !== 'Escape' || document.querySelector('dialog[open]') || !toasts.size) return;
    dismiss([...toasts.keys()].pop());
  });
}
