// Режимы отображения: хранятся в localStorage под ключом mh.prefs, применяются через data-* на <html>.
const KEY = 'mh.prefs';
export const DEFAULTS = { scale: 100, contrast: 'normal', theme: 'dark', targets: 'normal', keys: true };
const OK = {
  scale: v => [100, 125, 150].includes(v),
  contrast: v => v === 'normal' || v === 'high',
  theme: v => v === 'dark' || v === 'light' || v === 'system',
  targets: v => v === 'normal' || v === 'large',
  keys: v => typeof v === 'boolean',
};

function clean(src) {
  const out = { ...DEFAULTS };
  if (src && typeof src === 'object') for (const k of Object.keys(DEFAULTS)) if (OK[k](src[k])) out[k] = src[k];
  return out;
}

export function loadPrefs() {
  try { return clean(JSON.parse(localStorage.getItem(KEY))); } catch { return { ...DEFAULTS }; }
}

export function savePrefs(patch) {
  const next = clean({ ...loadPrefs(), ...patch });
  try { localStorage.setItem(KEY, JSON.stringify(next)); } catch { /* хранилище недоступно: режим действует до перезагрузки */ }
  return next;
}

export function applyPrefs(p, root = document.documentElement) {
  const theme = p.theme === 'system' ? (matchMedia('(prefers-color-scheme: light)').matches ? 'light' : 'dark') : p.theme;
  root.dataset.theme = theme; root.dataset.scale = String(p.scale);
  root.dataset.contrast = p.contrast; root.dataset.targets = p.targets;
}
