import * as prefs from './a11y/prefs.js';
import { api, onConnection, startPolling } from './core/api.js';
import { $, esc } from './core/dom.js';
import { initLibrary, loadLibrary } from './views/library.js';
import { initAdd } from './views/add.js';
import { initGames, openGames } from './views/games.js';
import { disk } from './core/disk.js';
import { initInbox, loadInbox } from './views/inbox.js';
import { initFeed, loadFeed, refreshBadge } from './views/feed.js';
import { initDownloads, poll, drawJobs, drawBar } from './views/downloads.js';
import { initSettings, loadSettings } from './views/settings.js';
import { initKeys } from './a11y/keys.js';
import { openDialog } from './ui/dialog.js';
import { announce, notify, dismiss, getLog, openLog, initNotifications } from './a11y/announce.js';

const TITLES = { library: 'Библиотека', inbox: 'Входящие', feed: 'Лента', downloads: 'Загрузки', games: 'Игры', settings: 'Настройки' };
let first = true;

// Вызывается после смены раздела: заголовок вкладки и фокус на h1 (кроме первой загрузки).
function afterRoute(view) {
  document.title = `${TITLES[view]} — MediaHub`;
  if (first) { first = false; return; }
  const h = document.querySelector(`#v-${view} h1`);
  if (h) h.focus();
}

// Потеря связи не должна давать необработанных исключений в консоли.
addEventListener('unhandledrejection', e => { if (e.reason && e.reason.message === 'offline') e.preventDefault(); });

$('skip').addEventListener('click', () => $('main').focus());
initNotifications();
initSettings();
initAdd();
initDownloads();
initInbox();
initGames();
initLibrary();

// Потеря связи: один постоянный статус, при восстановлении он заменяется обычным сообщением.
let lostId = 0;
onConnection(online => {
  if (!online) lostId = notify('Связь с MediaHub потеряна', { kind: 'error', sticky: true });
  else { dismiss(lostId); notify('Связь восстановлена'); }
});

const cur = () => (location.hash.slice(1) in TITLES ? location.hash.slice(1) : 'library');
initKeys({
  enabled: () => prefs.loadPrefs().keys,
  go: v => { location.hash = '#' + v; },
  focusSearch: () => {
    const id = cur() === 'games' ? 'gq' : 'q';
    if (cur() === 'games' || cur() === 'library') { $(id).focus(); return; }
    addEventListener('hashchange', () => $('q').focus(), { once: true });
    location.hash = '#library';
  },
  openLog,
  openHelp: () => openDialog($('helpDlg')),
});
['helpX', 'helpC'].forEach(id => $(id).addEventListener('click', () => $('helpDlg').close()));
$('keysOff').addEventListener('click', () => {
  prefs.savePrefs({ keys: false });
  $('helpDlg').close();
  notify('Горячие клавиши отключены. Включить: Настройки, Отображение.');
});

window.MH = Object.assign(window.MH || {}, { prefs, api, onConnection, startPolling, afterRoute, esc, __online: true, notify, announce, dismiss, getLog, openLog, loadSettings, loadLibrary, loadInbox, poll, drawJobs, drawBar });

const VIEWS = Object.keys(TITLES);
function route() {
  const v = cur();
  VIEWS.forEach(x => $('v-' + x).classList.toggle('hide', x !== v));
  document.querySelectorAll('nav a').forEach(a => a.getAttribute('href') === '#' + v ? a.setAttribute('aria-current', 'page') : a.removeAttribute('aria-current'));
  if (v === 'library') loadLibrary();
  if (v === 'inbox') loadInbox();
  if (v === 'feed') loadFeed();
  if (v === 'settings') loadSettings();
  if (v === 'games') openGames();
  if (v === 'downloads') drawJobs();
  drawBar();
  afterRoute(v);
}
initFeed();
addEventListener('hashchange', route);
route();
refreshBadge(); setInterval(refreshBadge, 60000); addEventListener('focus', refreshBadge);
startPolling(poll);
disk().catch(() => {}); setInterval(() => disk().catch(() => {}), 30000);
