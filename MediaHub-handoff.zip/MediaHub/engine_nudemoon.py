"""Движок манги для Nude-Moon: весь комикс это одна «глава» (глав у сайта нет). Разбор HTML без сети и без app.py.

Две вёрстки (сайт живёт на зеркалах, домены меняются):
  новая   https://{зеркало}/view/{id}-{slug}/        все страницы на одной странице: <div class="page__player"> <img data-src=".../storage/screens/{группа}/{id}/{N}.webp">
          метаданные: .page__subinfo-item (Переводчики, Автор, Категории), .page__text, .page__meta-item (страниц, просмотры, дата)
  старая  https://{зеркало}/{id}-{slug}.html         страница комикса: теги, автор, перевод, ссылка «Читать онлайн» (/{id}-online--{slug}.html)
          страница просмотра: все страницы в скрипте images[N].src = '/manga/ГГГГ/ММ/{n}-{slug}/N.jpg'
Старая вёрстка отдаёт windows-1251 (см. enginekit.decode_html)."""
import re
from urllib.parse import urljoin, urlparse

from enginekit import EngineError, _Collector, _meta, looks_blocked

NEW_PAGE = re.compile(r"/storage/screens/\d+/(\d+)/(\d+)\.(?:webp|jpe?g|png|avif)(?:\?.*)?$", re.I)
OLD_IMG = re.compile(r"images\[\d+\]\.src\s*=\s*(['\"])(.*?)\1")


def comic_id(url: str) -> str:
    """Номер комикса из адреса: «view-14324» (новая вёрстка) или «34608» (старая); номера двух вёрстток не связаны, поэтому различаются."""
    p = urlparse(url).path
    m = re.match(r"^/view/(\d+)-", p)
    if m:
        return "view-" + m.group(1)
    m = re.match(r"^/(\d+)-", p)
    return m.group(1) if m else ""


def layout_of(html: str) -> str:
    if "page__player" in html:
        return "new"
    if OLD_IMG.search(html):
        return "viewer"
    if "tag-links" in html or "class='tbl2'" in html or 'class="tbl2"' in html:
        return "old"
    return ""


def _txt(s: str) -> str:
    return re.sub(r"\s+", " ", s or "").strip()


def _clean_title(t: str) -> str:
    t = re.split(r"\.\s+(?:Онлайн|Хентай|Смотреть)", _txt(t))[0]
    return re.sub(r"\s*[—-]\s*хентай манга.*$", "", t, flags=re.I).strip()


def _names(s: str) -> list:
    return [x.strip() for x in re.split(r"[,;]", s or "") if x.strip()]


def parse_new(html: str, base: str) -> dict:
    c = _Collector({"h1": ("h1", None), "player": ("div", "page__player"), "meta": ("div", "page__meta-item"),
                    "sub": ("div", "page__subinfo-item"), "cat": ("a", "item_cat"), "desc": ("div", "page__text")})
    c.feed(html)
    cover = urljoin(base, _meta(c, "og:image")) if _meta(c, "og:image") else ""
    cid = (re.search(r"/storage/screens/\d+/(\d+)/", cover) or re.search(r"/view/(\d+)-", base) or [None, ""])[1]
    pages = []
    for p in c.found["player"]:
        for im in p["imgs"]:
            u = urljoin(base, (im.get("data-src") or im.get("src") or "").strip())
            m = NEW_PAGE.search(urlparse(u).path)
            if m and (not cid or m.group(1) == cid):
                pages.append((int(m.group(2)), u))
    out, seen = [], set()
    for _, u in sorted(pages):
        if u not in seen:
            seen.add(u); out.append(u)
    info = {"translators": [], "authors": [], "tags": []}
    for s in c.found["sub"]:
        key = "translators" if s["text"].startswith("Переводчик") else "authors" if s["text"].startswith("Автор") else "tags" if s["text"].startswith("Категор") else ""
        if key:
            info[key] = s["kids"].get("cat", [])
    if not info["tags"]:
        info["tags"] = [v for k, v in c.metas if k == "video:tag" and v]
    mt = {}
    for m in c.found["meta"]:
        cl = m["attrs"].get("class", "")
        for k in ("time", "views", "date"):
            if f"page__meta-item--{k}" in cl and m["text"] and k not in mt:
                mt[k] = m["text"]
    return {"layout": "new", "id": "view-" + cid if cid else comic_id(base), "title": _txt(c.found["h1"][0]["text"]) if c.found["h1"] else _clean_title(_meta(c, "og:title")),
            "cover": cover, "description": c.found["desc"][0]["text"] if c.found["desc"] else "", **info,
            "date": mt.get("date", ""), "views": mt.get("views", ""), "expected": int(mt["time"]) if mt.get("time", "").isdigit() else 0, "pages": out, "viewer_url": ""}


def parse_old_title(html: str, base: str) -> dict:
    c = _Collector({"h1": ("h1", None), "tags": ("span", "tag-links"), "a": ("a", None), "tbl": ("div", "tbl2")})
    c.feed(html)
    info = next((t["text"] for t in c.found["tbl"] if "Автор:" in t["text"] or "Страниц:" in t["text"]), "")
    g = lambda pat: (re.search(pat, info, re.S) or [None, ""])[1].strip()
    viewer = next((urljoin(base, a["attrs"].get("href", "")) for a in c.found["a"] if "-online--" in (a["attrs"].get("href") or "")), "")
    cover = urljoin(base, _meta(c, "og:image")) if _meta(c, "og:image") else ""
    pages = g(r"Страниц:\s*(\d+)")
    return {"layout": "old", "id": comic_id(base), "title": _txt(c.found["h1"][0]["text"]) if c.found["h1"] else _clean_title(_meta(c, "og:title")),
            "cover": cover, "description": "", "tags": c.found["tags"][0]["kids"].get("a", []) if c.found["tags"] else [],
            "authors": _names(g(r"Автор:\s*(.*?)\s*(?:Перевод:|Дата:|$)")), "translators": _names(g(r"Перевод:\s*(.*?)\s*(?:Дата:|$)")),
            "date": g(r"Дата:\s*(.*?)\s*(?:Просмотров:|Загрузок:|Страниц:|$)"), "views": g(r"Просмотров:\s*(.*?)\s*(?:Загрузок:|Страниц:|$)"),
            "expected": int(pages) if pages.isdigit() else 0, "pages": [], "viewer_url": viewer}


def parse_viewer(html: str, base: str) -> dict:
    c = _Collector({})
    c.feed(html)
    t = re.search(r"<title>(.*?)</title>", html, re.S)
    pages = list(dict.fromkeys(urljoin(base, m.group(2).strip()) for m in OLD_IMG.finditer(html)))
    return {"layout": "viewer", "id": comic_id(base), "title": _clean_title(t.group(1) if t else _meta(c, "og:title")),
            "cover": urljoin(base, _meta(c, "og:image")) if _meta(c, "og:image") else "", "description": "", "tags": [], "authors": [], "translators": [],
            "date": "", "views": "", "expected": len(pages), "pages": pages, "viewer_url": ""}


def load_comic(get_html, url: str) -> dict:
    """Скачать и разобрать комикс по ссылке (любая из страниц: новая, старая, просмотр). get_html(url) -> строка HTML."""
    html = get_html(url)
    if looks_blocked(html):
        raise EngineError("сайт отдал страницу проверки браузера вместо комикса: откройте его в браузере с расширением MediaHub и повторите")
    lay = layout_of(html)
    if lay == "new":
        r = parse_new(html, url)
    elif lay == "viewer":
        r = parse_viewer(html, url)
    elif lay == "old":
        r = parse_old_title(html, url)
        if not r["viewer_url"]:
            raise EngineError("на странице комикса нет ссылки «Читать онлайн» (комикс закрыт или изменилась разметка)")
        vh = get_html(r["viewer_url"])
        if looks_blocked(vh):
            raise EngineError("страница просмотра не открылась (проверка браузера или блокировка)")
        v = parse_viewer(vh, r["viewer_url"]); r["pages"] = v["pages"]
        r["id"] = comic_id(r["viewer_url"]) or r["id"]
    else:
        raise EngineError("не удалось узнать вёрстку страницы: это не страница комикса или сайт изменился")
    if not r["pages"]:
        raise EngineError("на странице не нашлось ни одной страницы комикса")
    r["title"] = r["title"] or "Nude-Moon " + r["id"]
    r["warn"] = f"страниц найдено {len(r['pages'])}, а сайт указывает {r['expected']}" if r["expected"] and r["expected"] != len(r["pages"]) else ""
    r["source"] = url
    return r
