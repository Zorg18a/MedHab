"""Запуск игры: поиск исполняемых файлов в папке игры, проверка пути и команда запуска. Сеть и БД не нужны.

Разрешены только `.exe` и `.bat`. Путь всегда хранится ОТНОСИТЕЛЬНО папки игры и перед запуском проверяется заново:
файл должен лежать внутри этой папки (без `..`, без ссылок наружу), а сама папка внутри каталога игр."""
import os
import subprocess

EXTS = (".exe", ".bat")
MAX_DEPTH = 3
MAX_FOUND = 40
SKIP = ("unins", "uninstall", "unitycrashhandler", "crashreport", "crashpad", "vc_redist", "vcredist", "dxsetup", "dxwebsetup",
        "dotnet", "ndp", "oalinst", "directx", "notification_helper", "cefsharp", "setup")


class PlayError(Exception):
    """Понятная пользователю причина, почему запуск невозможен."""


def _inside(path: str, base: str) -> bool:
    try:
        a, b = os.path.realpath(path), os.path.realpath(base)
        return a != b and os.path.commonpath([a, b]) == b
    except ValueError:
        return False


def _skipped(name: str) -> bool:
    n = name.lower()
    return any(s in n for s in SKIP)


def find_executables(folder: str) -> list:
    """Список [{rel, name, size, depth}] запускаемых файлов; ближние к корню первыми, служебные (удаление, redist) отброшены."""
    out = []
    if not folder or not os.path.isdir(folder):
        return out
    base = os.path.realpath(folder)
    for cur, dirs, files in os.walk(base):
        depth = os.path.relpath(cur, base).count(os.sep) + (0 if cur == base else 1)
        if depth >= MAX_DEPTH:
            dirs[:] = []
        dirs[:] = [d for d in dirs if not os.path.islink(os.path.join(cur, d))]
        for f in files:
            if not f.lower().endswith(EXTS) or _skipped(f):
                continue
            p = os.path.join(cur, f)
            if os.path.islink(p):
                continue
            try:
                size = os.path.getsize(p)
            except OSError:
                continue
            out.append({"rel": os.path.relpath(p, base).replace(os.sep, "/"), "name": f, "size": size, "depth": depth})
    out.sort(key=lambda e: (e["depth"], e["name"].lower().endswith(".bat"), -e["size"], e["name"].lower()))
    return out[:MAX_FOUND]


def resolve(folder: str, rel: str, root: str) -> str:
    """Полный путь к файлу запуска или PlayError. folder — папка игры, rel — путь внутри неё, root — каталог игр из настроек."""
    if not folder or not os.path.isdir(folder):
        raise PlayError("Папка игры не найдена: проверьте, что диск подключён")
    if not root or not _inside(folder, root):
        raise PlayError("Папка игры не в каталоге игр")
    rel = str(rel or "")
    if not rel or os.path.isabs(rel) or rel.startswith(("/", "\\")) or ".." in rel.replace("\\", "/").split("/"):
        raise PlayError("Файл запуска не выбран или путь недопустим")
    if not rel.lower().endswith(EXTS):
        raise PlayError("Запускать можно только .exe и .bat")
    full = os.path.join(folder, *rel.replace("\\", "/").split("/"))
    if not os.path.isfile(full):
        raise PlayError("Файла запуска нет на месте: выберите его заново")
    if not _inside(full, folder):
        raise PlayError("Файл запуска вне папки игры")
    return os.path.abspath(full)


def command(path: str) -> tuple:
    """(аргументы, рабочая папка). `.bat` запускается через cmd, `.exe` напрямую; рабочая папка = папка файла."""
    cwd = os.path.dirname(path)
    if path.lower().endswith(".bat"):
        return ["cmd", "/c", path], cwd
    return [path], cwd


def launch(folder: str, rel: str, root: str, popen=subprocess.Popen, windows: bool | None = None) -> str:
    """Проверить и запустить. Возвращает имя файла. popen и windows подменяются в тестах."""
    path = resolve(folder, rel, root)
    if (os.name == "nt") if windows is None else windows:
        args, cwd = command(path)
        try:
            popen(args, cwd=cwd, close_fds=True, creationflags=getattr(subprocess, "DETACHED_PROCESS", 0) | getattr(subprocess, "CREATE_NEW_PROCESS_GROUP", 0))
        except OSError as e:
            raise PlayError(f"Не удалось запустить: {e.strerror or e}")
        return os.path.basename(path)
    raise PlayError("Запуск игр работает только в Windows")


def pick_default(found: list) -> str:
    """Что предложить по умолчанию: единственный .exe, иначе единственный файл, иначе ничего (пусть выберет человек)."""
    exes = [e for e in found if e["name"].lower().endswith(".exe")]
    if len(exes) == 1:
        return exes[0]["rel"]
    if not exes and len(found) == 1:
        return found[0]["rel"]
    return ""
